-- AlterEnum
ALTER TYPE "MediaType" ADD VALUE 'IMAGE';
