-- AlterEnum
ALTER TYPE "EnrollmentStatus" ADD VALUE 'WAITLISTED';
