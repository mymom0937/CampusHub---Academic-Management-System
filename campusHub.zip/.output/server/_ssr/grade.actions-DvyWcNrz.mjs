import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { i as instructorMiddleware, t as toAppError, s as studentMiddleware, d as staffMiddleware, A as AppError, p as prisma } from "./middleware-DiEMT5y4.mjs";
import { G as GRADE_POINTS } from "./constants-DoiYt0dc.mjs";
import { g as getCourseEnrollments, f as findEnrollmentById, s as submitGrade$1 } from "./enrollment.repository-787va9JM.mjs";
import { f as findCourseById } from "./course.repository-DNbUwZlZ.mjs";
import { g as getTranscript, a as getStudentTranscriptForStaff, b as getGpaSummary } from "./gpa.service-DlC-2Gr6.mjs";
import { s as submitGradeSchema, b as bulkGradeSchema } from "./enrollment.schema-YQ3WLO4x.mjs";
import { s as saveAssessmentsSchema, a as saveScoresSchema } from "./assessment.schema-DvXBy4tg.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
async function getCourseAssessments(courseId) {
  return prisma.courseAssessment.findMany({
    where: { courseId },
    orderBy: { sortOrder: "asc" }
  });
}
async function upsertCourseAssessments(courseId, assessments) {
  await prisma.$transaction(async (tx) => {
    await tx.enrollmentAssessmentScore.deleteMany({
      where: {
        assessment: { courseId }
      }
    });
    await tx.courseAssessment.deleteMany({
      where: { courseId }
    });
    if (assessments.length > 0) {
      await tx.courseAssessment.createMany({
        data: assessments.map((a, i) => ({
          courseId,
          name: a.name,
          weight: a.weight,
          maxScore: a.maxScore ?? 100,
          sortOrder: i
        }))
      });
    }
  });
  return getCourseAssessments(courseId);
}
async function getEnrollmentScores(enrollmentIds) {
  const scores = await prisma.enrollmentAssessmentScore.findMany({
    where: { enrollmentId: { in: enrollmentIds } },
    include: {
      assessment: true
    }
  });
  return scores;
}
async function upsertAssessmentScore(enrollmentId, assessmentId, score, maxScore) {
  return prisma.enrollmentAssessmentScore.upsert({
    where: {
      enrollmentId_assessmentId: { enrollmentId, assessmentId }
    },
    create: {
      enrollmentId,
      assessmentId,
      score,
      maxScore: maxScore ?? void 0
    },
    update: {
      score,
      ...maxScore !== void 0 && { maxScore }
    }
  });
}
async function upsertEnrollmentScores(enrollmentId, scores) {
  for (const s of scores) {
    await upsertAssessmentScore(
      enrollmentId,
      s.assessmentId,
      s.score,
      s.maxScore
    );
  }
}
async function submitGrade(instructorId, enrollmentId, gradeValue) {
  const enrollment = await findEnrollmentById(enrollmentId);
  if (!enrollment) {
    throw new AppError("NOT_FOUND", "Enrollment not found");
  }
  if (enrollment.status !== "ENROLLED" && enrollment.status !== "COMPLETED") {
    throw new AppError(
      "VALIDATION_ERROR",
      "Can only grade students with ENROLLED or COMPLETED status"
    );
  }
  const course = await findCourseById(enrollment.courseId);
  if (!course) {
    throw new AppError("NOT_FOUND", "Course not found");
  }
  const isAssigned = course.instructorAssignments.some(
    (a) => a.instructorId === instructorId
  );
  if (!isAssigned) {
    throw new AppError(
      "FORBIDDEN",
      "You are not assigned to this course"
    );
  }
  const now = /* @__PURE__ */ new Date();
  const semesterEnd = new Date(course.semester.endDate);
  const gradeDeadline = new Date(semesterEnd);
  gradeDeadline.setDate(gradeDeadline.getDate() + 30);
  if (now > gradeDeadline) {
    throw new AppError(
      "VALIDATION_ERROR",
      "The grading period has closed for this semester"
    );
  }
  const gradePoints = GRADE_POINTS[gradeValue];
  const calculatedGradePoints = gradePoints !== null ? gradePoints * enrollment.course.credits : null;
  await submitGrade$1(enrollmentId, {
    grade: gradeValue,
    gradePoints: calculatedGradePoints,
    gradedBy: instructorId
  });
}
async function updateGrade(instructorId, enrollmentId, gradeValue) {
  const enrollment = await findEnrollmentById(enrollmentId);
  if (!enrollment) {
    throw new AppError("NOT_FOUND", "Enrollment not found");
  }
  if (enrollment.status !== "COMPLETED") {
    throw new AppError(
      "VALIDATION_ERROR",
      "Can only update grades for completed enrollments"
    );
  }
  const course = await findCourseById(enrollment.courseId);
  if (!course) {
    throw new AppError("NOT_FOUND", "Course not found");
  }
  const isAssigned = course.instructorAssignments.some(
    (a) => a.instructorId === instructorId
  );
  if (!isAssigned) {
    throw new AppError(
      "FORBIDDEN",
      "You are not assigned to this course"
    );
  }
  const now = /* @__PURE__ */ new Date();
  const semesterEnd = new Date(course.semester.endDate);
  const gradeDeadline = new Date(semesterEnd);
  gradeDeadline.setDate(gradeDeadline.getDate() + 30);
  if (now > gradeDeadline) {
    throw new AppError(
      "VALIDATION_ERROR",
      "The grading period has closed for this semester"
    );
  }
  const gradePoints = GRADE_POINTS[gradeValue];
  const calculatedGradePoints = gradePoints !== null ? gradePoints * enrollment.course.credits : null;
  await submitGrade$1(enrollmentId, {
    grade: gradeValue,
    gradePoints: calculatedGradePoints,
    gradedBy: instructorId
  });
}
async function getCourseStudentGrades(instructorId, courseId) {
  const data = await getCourseGradingData(instructorId, courseId);
  return data.students;
}
async function getCourseGradingData(instructorId, courseId) {
  const course = await findCourseById(courseId);
  if (!course) {
    throw new AppError("NOT_FOUND", "Course not found");
  }
  const isAssigned = course.instructorAssignments.some(
    (a) => a.instructorId === instructorId
  );
  if (!isAssigned) {
    throw new AppError("FORBIDDEN", "You are not assigned to this course");
  }
  const enrollments = await getCourseEnrollments(courseId);
  const assessmentList = await getCourseAssessments(courseId);
  const enrollmentIds = enrollments.map((e) => e.id);
  const allScores = await getEnrollmentScores(enrollmentIds);
  const graderIds = [...new Set(enrollments.map((e) => e.gradedBy).filter(Boolean))];
  const graders = graderIds.length > 0 ? await prisma.user.findMany({
    where: { id: { in: graderIds } },
    select: { id: true, firstName: true, lastName: true }
  }) : [];
  const graderNameMap = new Map(graders.map((g) => [g.id, `${g.firstName} ${g.lastName}`]));
  const scoreMap = /* @__PURE__ */ new Map();
  for (const s of allScores) {
    if (!scoreMap.has(s.enrollmentId)) {
      scoreMap.set(s.enrollmentId, {});
    }
    const entry = scoreMap.get(s.enrollmentId);
    entry[s.assessmentId] = {
      score: s.score,
      maxScore: s.assessment.maxScore
    };
  }
  const assessments = assessmentList.map((a) => ({
    id: a.id,
    name: a.name,
    weight: a.weight,
    maxScore: a.maxScore,
    sortOrder: a.sortOrder
  }));
  const students = enrollments.map((e) => ({
    enrollmentId: e.id,
    studentId: e.student.id,
    firstName: e.student.firstName,
    lastName: e.student.lastName,
    email: e.student.email,
    status: e.status,
    grade: e.grade,
    gradePoints: e.gradePoints,
    gradedAt: e.gradedAt?.toISOString() || null,
    gradedByName: e.gradedBy ? graderNameMap.get(e.gradedBy) ?? null : null,
    assessmentScores: scoreMap.get(e.id) ?? {}
  }));
  return { assessments, students };
}
async function saveCourseAssessments(instructorId, courseId, assessments) {
  const course = await findCourseById(courseId);
  if (!course) throw new AppError("NOT_FOUND", "Course not found");
  const isAssigned = course.instructorAssignments.some((a) => a.instructorId === instructorId);
  if (!isAssigned) throw new AppError("FORBIDDEN", "You are not assigned to this course");
  const total = assessments.reduce((s, a) => s + a.weight, 0);
  if (total !== 100) {
    throw new AppError("VALIDATION_ERROR", "Assessment weights must total 100%");
  }
  const result = await upsertCourseAssessments(courseId, assessments);
  return result.map((a) => ({
    id: a.id,
    name: a.name,
    weight: a.weight,
    maxScore: a.maxScore,
    sortOrder: a.sortOrder
  }));
}
async function saveAssessmentScores(instructorId, enrollmentId, scores) {
  const enrollment = await findEnrollmentById(enrollmentId);
  if (!enrollment) throw new AppError("NOT_FOUND", "Enrollment not found");
  const course = await findCourseById(enrollment.courseId);
  if (!course) throw new AppError("NOT_FOUND", "Course not found");
  const isAssigned = course.instructorAssignments.some((a) => a.instructorId === instructorId);
  if (!isAssigned) throw new AppError("FORBIDDEN", "You are not assigned to this course");
  await upsertEnrollmentScores(enrollmentId, scores);
}
async function getInstructorStudents(instructorId) {
  const enrollments = await prisma.enrollment.findMany({
    where: {
      course: {
        instructorAssignments: {
          some: { instructorId }
        }
      }
    },
    include: {
      student: {
        select: { id: true, firstName: true, lastName: true, email: true }
      }
    }
  });
  const seen = /* @__PURE__ */ new Set();
  const students = [];
  for (const e of enrollments) {
    if (!seen.has(e.studentId)) {
      seen.add(e.studentId);
      students.push({ ...e.student });
    }
  }
  students.sort((a, b) => a.lastName.localeCompare(b.lastName) || a.firstName.localeCompare(b.firstName));
  return students;
}
const getCourseGradingDataAction_createServerFn_handler = createServerRpc({
  id: "b28c5a3ebc7c9e496a37f2a62e6012faf1afe8d1767c0cf4b29dfab21fc10c70",
  name: "getCourseGradingDataAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => getCourseGradingDataAction.__executeServer(opts));
const getCourseGradingDataAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseId) throw new Error("Course ID is required");
  return parsed;
}).handler(getCourseGradingDataAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  return getCourseGradingData(user.id, data.courseId);
});
const saveCourseAssessmentsAction_createServerFn_handler = createServerRpc({
  id: "c68c971d8fcc272b6656f1fbbf9c3fbc3ceb181d3a2aa6d04c04b25a631e9953",
  name: "saveCourseAssessmentsAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => saveCourseAssessmentsAction.__executeServer(opts));
const saveCourseAssessmentsAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => saveAssessmentsSchema.parse(data)).handler(saveCourseAssessmentsAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  const assessments = await saveCourseAssessments(user.id, data.courseId, data.assessments.map((a) => ({
    name: a.name,
    weight: a.weight,
    maxScore: a.maxScore
  })));
  return {
    success: true,
    data: {
      assessments
    }
  };
});
const saveAssessmentScoresAction_createServerFn_handler = createServerRpc({
  id: "21825f7f80042905195ed1bb495d9e99efa35ecdb7007b5708e6bbe3ae59f3ea",
  name: "saveAssessmentScoresAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => saveAssessmentScoresAction.__executeServer(opts));
const saveAssessmentScoresAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => saveScoresSchema.parse(data)).handler(saveAssessmentScoresAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  await saveAssessmentScores(user.id, data.enrollmentId, data.scores);
  return {
    success: true
  };
});
const submitGradeAction_createServerFn_handler = createServerRpc({
  id: "bf6397dbe815c826e566b801c62b3a94d1fc23f43ea938195e22a37ccf113758",
  name: "submitGradeAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => submitGradeAction.__executeServer(opts));
const submitGradeAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => submitGradeSchema.parse(data)).handler(submitGradeAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    await submitGrade(user.id, data.enrollmentId, data.grade);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const updateGradeAction_createServerFn_handler = createServerRpc({
  id: "21a1038707fb64906b3a6492dc2bf5667f816e1c96007ae1a1da13da315596e8",
  name: "updateGradeAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => updateGradeAction.__executeServer(opts));
const updateGradeAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => submitGradeSchema.parse(data)).handler(updateGradeAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    await updateGrade(user.id, data.enrollmentId, data.grade);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const getCourseGradesAction_createServerFn_handler = createServerRpc({
  id: "2705d8a5439a8e8f3e28eed689a67a4db9ace9333cdf0671a9c1d5327d06ba99",
  name: "getCourseGradesAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => getCourseGradesAction.__executeServer(opts));
const getCourseGradesAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseId) throw new Error("Course ID is required");
  return parsed;
}).handler(getCourseGradesAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  return getCourseStudentGrades(user.id, data.courseId);
});
const getInstructorStudentsAction_createServerFn_handler = createServerRpc({
  id: "d65d611ed28452d83db16c898e9257d6c08376a12cfa0678fbf896d474b3f986",
  name: "getInstructorStudentsAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => getInstructorStudentsAction.__executeServer(opts));
const getInstructorStudentsAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).handler(getInstructorStudentsAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getInstructorStudents(user.id);
});
const getTranscriptAction_createServerFn_handler = createServerRpc({
  id: "270693b94f64ace4ee2d5a973c0d6d31ad358e74d9d07045324b756196a2aa59",
  name: "getTranscriptAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => getTranscriptAction.__executeServer(opts));
const getTranscriptAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(getTranscriptAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getTranscript(user.id);
});
const getStudentTranscriptAction_createServerFn_handler = createServerRpc({
  id: "0cf4315e6281c9e10980f98ce9f055acb8ac51b0affaa4f5443f983d7b4b8e80",
  name: "getStudentTranscriptAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => getStudentTranscriptAction.__executeServer(opts));
const getStudentTranscriptAction = createServerFn({
  method: "POST"
}).middleware([staffMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed?.studentId) throw new Error("Student ID is required");
  return parsed;
}).handler(getStudentTranscriptAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  return getStudentTranscriptForStaff(user.id, user.role, data.studentId);
});
const bulkSubmitGradesAction_createServerFn_handler = createServerRpc({
  id: "0c3d12901aa4cecc3831709234039c4298b00e0c4de75957090cb22865074e1f",
  name: "bulkSubmitGradesAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => bulkSubmitGradesAction.__executeServer(opts));
const bulkSubmitGradesAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => bulkGradeSchema.parse(data)).handler(bulkSubmitGradesAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  const results = [];
  for (const entry of data.grades) {
    try {
      await submitGrade(user.id, entry.enrollmentId, entry.grade);
      results.push({
        enrollmentId: entry.enrollmentId,
        success: true
      });
    } catch (error) {
      const appError = toAppError(error);
      results.push({
        enrollmentId: entry.enrollmentId,
        success: false,
        error: appError.message
      });
    }
  }
  const successCount = results.filter((r) => r.success).length;
  const failCount = results.filter((r) => !r.success).length;
  return {
    success: true,
    data: {
      results,
      successCount,
      failCount
    }
  };
});
const getGpaSummaryAction_createServerFn_handler = createServerRpc({
  id: "86378e06d26d8880920ab7690beeb3ed37ce09f334a7df1a8a8914b22ea57c53",
  name: "getGpaSummaryAction",
  filename: "src/server/actions/grade.actions.ts"
}, (opts) => getGpaSummaryAction.__executeServer(opts));
const getGpaSummaryAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(getGpaSummaryAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getGpaSummary(user.id);
});
export {
  bulkSubmitGradesAction_createServerFn_handler,
  getCourseGradesAction_createServerFn_handler,
  getCourseGradingDataAction_createServerFn_handler,
  getGpaSummaryAction_createServerFn_handler,
  getInstructorStudentsAction_createServerFn_handler,
  getStudentTranscriptAction_createServerFn_handler,
  getTranscriptAction_createServerFn_handler,
  saveAssessmentScoresAction_createServerFn_handler,
  saveCourseAssessmentsAction_createServerFn_handler,
  submitGradeAction_createServerFn_handler,
  updateGradeAction_createServerFn_handler
};
