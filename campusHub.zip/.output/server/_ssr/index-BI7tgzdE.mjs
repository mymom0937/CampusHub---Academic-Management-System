import { j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { _ as Route$t, B as Button } from "./router-DhCkpF2X.mjs";
import { C as Card, a as CardHeader, b as CardTitle, e as CardContent, c as CardDescription } from "./card-QCkASOp1.mjs";
import { B as BookOpen, m as ClipboardList, G as GraduationCap, n as TrendingUp, f as ChartColumn, o as FileText, T as TriangleAlert } from "../_libs/lucide-react.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "./constants-DoiYt0dc.mjs";
import "../_libs/sonner.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "../_libs/zod.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./course.schema-DAXkVW6U.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
function AcademicStandingAlert({ gpa, firstName }) {
  if (gpa === null) return null;
  if (gpa >= 2) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-destructive bg-destructive/5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "flex items-start gap-4 py-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-6 w-6 text-destructive shrink-0 mt-0.5" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-destructive", children: "Academic Probation Warning" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground mt-1", children: [
        firstName,
        ", your cumulative GPA (",
        gpa.toFixed(2),
        ") is below the 2.0 minimum required for good academic standing. You are currently on ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "academic probation" }),
        "."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-sm text-muted-foreground mt-2 space-y-1 list-disc list-inside", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Meet with your academic advisor to create an improvement plan" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Consider reducing your course load next semester" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Take advantage of tutoring and academic support services" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "A GPA of 2.0 or higher is required to return to good standing" })
      ] })
    ] })
  ] }) });
}
function StudentDashboard() {
  const {
    stats
  } = Route$t.useLoaderData();
  const {
    user
  } = Route$t.useRouteContext();
  const statCards = [{
    title: "Enrolled Courses",
    value: stats.enrolledCourses,
    description: "This semester",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-5 w-5 text-muted-foreground" })
  }, {
    title: "Completed Courses",
    value: stats.completedCourses,
    description: "All time",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ClipboardList, { className: "h-5 w-5 text-muted-foreground" })
  }, {
    title: "Current Credits",
    value: stats.totalCredits,
    description: "This semester",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-5 w-5 text-muted-foreground" })
  }, {
    title: "Cumulative GPA",
    value: stats.currentGpa !== null ? stats.currentGpa.toFixed(2) : "N/A",
    description: stats.currentGpa !== null ? stats.currentGpa >= 3.5 ? "Dean's List" : stats.currentGpa >= 2 ? "Good Standing" : "Academic Probation" : "No grades yet",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "h-5 w-5 text-muted-foreground" })
  }];
  const GPA_MAX = 4;
  const CHART_HEIGHT = 160;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Student",
      href: "/student"
    }, {
      label: "Dashboard"
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: "Student Dashboard" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-muted-foreground mt-1", children: [
          "Welcome back, ",
          user.firstName,
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AcademicStandingAlert, { gpa: stats.currentGpa, firstName: user.firstName }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4", children: statCards.map((card, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "flex flex-row items-center justify-between space-y-0 pb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-sm font-medium", children: card.title }),
          card.icon
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-bold", children: card.value }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: card.description })
        ] })
      ] }, idx)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 grid-cols-1 min-w-0 lg:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "lg:col-span-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-base flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-4 w-4" }),
              "GPA Trend"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Your semester-by-semester GPA performance" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: stats.gpaTrend.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", style: {
              height: CHART_HEIGHT
            }, children: [
              [0, 1, 2, 3, 4].map((val) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-8 right-0 border-t border-dashed border-muted", style: {
                bottom: `${val / GPA_MAX * 100}%`
              }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -left-8 -top-2.5 text-xs text-muted-foreground w-6 text-right", children: val.toFixed(1) }) }, val)),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-8 right-0 border-t-2 border-emerald-500/40", style: {
                bottom: `${3.5 / GPA_MAX * 100}%`
              }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute right-0 -top-4 text-[10px] text-emerald-600 font-medium", children: "Dean's List (3.5)" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-8 right-0 bottom-0 top-0 flex items-end justify-around gap-2 px-2", children: stats.gpaTrend.map((point, idx) => {
                const heightPct = point.gpa / GPA_MAX * 100;
                const isGood = point.gpa >= 3.5;
                const isWarning = point.gpa < 2;
                return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center flex-1 max-w-20", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold mb-1", children: point.gpa.toFixed(2) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-full rounded-t-md transition-all ${isGood ? "bg-emerald-500" : isWarning ? "bg-red-500" : "bg-blue-500"}`, style: {
                    height: `${heightPct}%`,
                    minHeight: 4
                  } })
                ] }, idx);
              }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-around pl-8 gap-2", children: stats.gpaTrend.map((point, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center flex-1 max-w-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground font-mono", children: point.semesterCode }) }, idx)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-xs text-muted-foreground pt-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-2.5 rounded-sm bg-emerald-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Dean's List (3.5+)" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-2.5 rounded-sm bg-blue-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Good Standing" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-2.5 rounded-sm bg-red-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Probation (<2.0)" })
              ] })
            ] })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center py-8 text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-10 w-10 mb-3 opacity-40" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", children: "GPA trend will appear once you have graded courses." })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Quick Links" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Navigate to common pages" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", className: "w-full justify-start", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/student/courses", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-4 w-4 mr-2" }),
              "Browse Courses"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", className: "w-full justify-start", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/student/enrollment", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ClipboardList, { className: "h-4 w-4 mr-2" }),
              "My Enrollments"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", className: "w-full justify-start", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/student/grades", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-4 w-4 mr-2" }),
              "View Grades"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", className: "w-full justify-start", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/student/transcript", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-4 w-4 mr-2" }),
              "Transcript"
            ] }) }),
            stats.currentGpa !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-3 border-t", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mb-2", children: "Academic Standing" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: stats.currentGpa >= 3.5 ? "success" : stats.currentGpa >= 2 ? "secondary" : "destructive", className: "text-sm", children: stats.currentGpa >= 3.5 ? "Dean's List" : stats.currentGpa >= 2 ? "Good Standing" : "Academic Probation" })
            ] })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  StudentDashboard as component
};
