import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { a as adminMiddleware, t as toAppError } from "./middleware-DiEMT5y4.mjs";
import { l as listAllPrerequisites, g as getPrerequisites, a as addPrerequisite, r as removePrerequisite } from "./prerequisite.service-C4RHxalx.mjs";
import { a as addPrerequisiteSchema } from "./notification.schema-BWgQdqns.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
const listPrerequisitesAction_createServerFn_handler = createServerRpc({
  id: "d6e6583fcf51ef9f009b45f504c53c7e4fdef7db96ca75b5a5357197719bb165",
  name: "listPrerequisitesAction",
  filename: "src/server/actions/prerequisite.actions.ts"
}, (opts) => listPrerequisitesAction.__executeServer(opts));
const listPrerequisitesAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(listPrerequisitesAction_createServerFn_handler, async () => {
  return listAllPrerequisites();
});
const getCoursePrerequisitesAction_createServerFn_handler = createServerRpc({
  id: "bbf0f5869f50e6e558ed92c1beb5003785691452a4a538307db481cf537fd925",
  name: "getCoursePrerequisitesAction",
  filename: "src/server/actions/prerequisite.actions.ts"
}, (opts) => getCoursePrerequisitesAction.__executeServer(opts));
const getCoursePrerequisitesAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseCode) throw new Error("Course code is required");
  return parsed;
}).handler(getCoursePrerequisitesAction_createServerFn_handler, async ({
  data
}) => {
  return getPrerequisites(data.courseCode);
});
const addPrerequisiteAction_createServerFn_handler = createServerRpc({
  id: "17a47d1b958d7c69e487d5a096b75f8d7104dde9c2974a6fa14b8705905977d5",
  name: "addPrerequisiteAction",
  filename: "src/server/actions/prerequisite.actions.ts"
}, (opts) => addPrerequisiteAction.__executeServer(opts));
const addPrerequisiteAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => addPrerequisiteSchema.parse(data)).handler(addPrerequisiteAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await addPrerequisite(data.courseCode, data.prerequisiteCode);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const removePrerequisiteAction_createServerFn_handler = createServerRpc({
  id: "5155cf2b656faf6d7b2694bdfe93afbeae8a055afec5d2b2e8c72b6c05e9864e",
  name: "removePrerequisiteAction",
  filename: "src/server/actions/prerequisite.actions.ts"
}, (opts) => removePrerequisiteAction.__executeServer(opts));
const removePrerequisiteAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Prerequisite ID is required");
  return parsed;
}).handler(removePrerequisiteAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await removePrerequisite(data.id);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
export {
  addPrerequisiteAction_createServerFn_handler,
  getCoursePrerequisitesAction_createServerFn_handler,
  listPrerequisitesAction_createServerFn_handler,
  removePrerequisiteAction_createServerFn_handler
};
