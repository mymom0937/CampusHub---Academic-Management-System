import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a5 as Route$6, B as Button, a6 as bulkSubmitGradesAction, a7 as saveCourseAssessmentsAction, a8 as saveAssessmentScoresAction, a9 as updateGradeAction, aa as submitGradeAction, ab as getCourseGradingDataAction } from "./router-DhCkpF2X.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { C as Card, a as CardHeader, b as CardTitle, c as CardDescription, e as CardContent } from "./card-QCkASOp1.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BlCW8AsE.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-D5Fm91vy.mjs";
import { I as Input } from "./input-9b2Tum0N.mjs";
import { A as AlertDialog, a as AlertDialogContent, b as AlertDialogHeader, c as AlertDialogTitle, d as AlertDialogDescription, e as AlertDialogFooter, f as AlertDialogCancel, g as AlertDialogAction } from "./alert-dialog-DTkhQAha.mjs";
import { E as EmptyState } from "./empty-state-D-g1-il0.mjs";
import { D as DEFAULT_ASSESSMENT_WEIGHTS, b as GRADE_LABELS, p as percentageToGrade } from "./constants-DoiYt0dc.mjs";
import { Y as Upload, a1 as Settings2, R as Trash2, W as Plus, m as ClipboardList } from "../_libs/lucide-react.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/isbot.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "../_libs/zod.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./course.schema-DAXkVW6U.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "../_chunks/_libs/@radix-ui/react-select.mjs";
import "../_chunks/_libs/@radix-ui/number.mjs";
import "../_chunks/_libs/@radix-ui/react-use-previous.mjs";
import "../_chunks/_libs/@radix-ui/react-visually-hidden.mjs";
import "../_chunks/_libs/@radix-ui/react-alert-dialog.mjs";
import "../_chunks/_libs/@radix-ui/react-dialog.mjs";
function calculateWeightedPercentage(assessments, scores) {
  let totalWeighted = 0;
  let totalWeight = 0;
  for (const a of assessments) {
    const s = scores[a.id];
    if (!s || s.score === null) return null;
    let max = s.maxScore || a.maxScore;
    if (max === 100) max = a.weight;
    if (max <= 0) continue;
    totalWeighted += s.score / max * a.weight;
    totalWeight += a.weight;
  }
  if (totalWeight === 0) return null;
  return Math.round(totalWeighted / totalWeight * 100);
}
function InstructorGradingPage() {
  const {
    assessments: initialAssessments,
    students: initialStudents,
    courseId
  } = Route$6.useLoaderData();
  const {
    user
  } = Route$6.useRouteContext();
  const [assessments, setAssessments] = reactExports.useState(initialAssessments);
  const [students, setStudents] = reactExports.useState(initialStudents);
  const [pendingGrades, setPendingGrades] = reactExports.useState({});
  const [pendingScores, setPendingScores] = reactExports.useState({});
  const [assessmentForm, setAssessmentForm] = reactExports.useState(initialAssessments.length > 0 ? initialAssessments.map((a) => ({
    id: a.id,
    name: a.name,
    weight: a.weight,
    maxScore: a.maxScore
  })) : DEFAULT_ASSESSMENT_WEIGHTS.map((a) => ({
    name: a.name,
    weight: a.weight,
    maxScore: a.maxScore
  })));
  const [savingAssessments, setSavingAssessments] = reactExports.useState(false);
  const [assessmentOpen, setAssessmentOpen] = reactExports.useState(initialAssessments.length === 0);
  const toggleAssessmentOpen = () => {
    if (!assessmentOpen) {
      setAssessmentForm(assessments.length > 0 ? assessments.map((a) => ({
        id: a.id,
        name: a.name,
        weight: a.weight,
        maxScore: a.maxScore
      })) : DEFAULT_ASSESSMENT_WEIGHTS.map((a) => ({
        name: a.name,
        weight: a.weight,
        maxScore: a.maxScore
      })));
    }
    setAssessmentOpen((o) => !o);
  };
  const [submitting, setSubmitting] = reactExports.useState(null);
  const [confirmGrade, setConfirmGrade] = reactExports.useState(null);
  const [bulkImporting, setBulkImporting] = reactExports.useState(false);
  const fileInputRef = reactExports.useRef(null);
  const refreshData = async () => {
    const data = await getCourseGradingDataAction({
      data: {
        courseId
      }
    });
    setAssessments(data.assessments);
    setStudents(data.students);
  };
  const handleGradeChange = (enrollmentId, grade) => {
    setPendingGrades((prev) => ({
      ...prev,
      [enrollmentId]: grade
    }));
  };
  const handleScoreChange = (enrollmentId, assessmentId, value) => {
    setPendingScores((prev) => ({
      ...prev,
      [enrollmentId]: {
        ...prev[enrollmentId] ?? {},
        [assessmentId]: value
      }
    }));
  };
  const getEffectiveScores = (s) => {
    const base = s.assessmentScores ?? {};
    const pending = pendingScores[s.enrollmentId] ?? {};
    const result = {};
    for (const a of assessments) {
      const p = pending[a.id];
      const b = base[a.id];
      result[a.id] = {
        score: p !== void 0 && p !== "" ? p : b?.score ?? null,
        maxScore: b?.maxScore ?? a.maxScore
      };
    }
    return result;
  };
  const calculatedPercentage = (s) => {
    const scores = getEffectiveScores(s);
    return calculateWeightedPercentage(assessments, scores);
  };
  const suggestedGrade = (s) => {
    const pct = calculatedPercentage(s);
    return pct !== null ? percentageToGrade(pct) : null;
  };
  const handleSaveAssessments = async () => {
    const total = assessmentForm.reduce((s, a) => s + a.weight, 0);
    if (total !== 100) {
      toast.error("Assessment weights must total 100%");
      return;
    }
    setSavingAssessments(true);
    try {
      const result = await saveCourseAssessmentsAction({
        data: {
          courseId,
          assessments: assessmentForm.map((a) => ({
            name: a.name,
            weight: a.weight,
            maxScore: a.maxScore
          }))
        }
      });
      if (result.success) {
        setAssessments(result.data.assessments);
        setAssessmentOpen(false);
        toast.success("Assessment weights saved");
        refreshData();
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save assessments");
    } finally {
      setSavingAssessments(false);
    }
  };
  const handleSaveScores = async (enrollmentId) => {
    const pending = pendingScores[enrollmentId] ?? {};
    const scores = Object.entries(pending).map(([assessmentId, score]) => ({
      assessmentId,
      score: score === "" ? null : score
    }));
    if (scores.length === 0) return;
    try {
      await saveAssessmentScoresAction({
        data: {
          enrollmentId,
          scores
        }
      });
      toast.success("Scores saved");
      setPendingScores((prev) => {
        const copy = {
          ...prev
        };
        delete copy[enrollmentId];
        return copy;
      });
      await refreshData();
      const student = students.find((s) => s.enrollmentId === enrollmentId);
      const baseScores = student?.assessmentScores ?? {};
      const merged = {};
      for (const a of assessments) {
        const p = pending[a.id];
        const b = baseScores[a.id];
        const score = p !== void 0 && p !== "" ? p : b?.score ?? null;
        merged[a.id] = {
          score,
          maxScore: b?.maxScore ?? a.maxScore
        };
      }
      for (const {
        assessmentId,
        score
      } of scores) {
        if (score !== null) {
          const a = assessments.find((x) => x.id === assessmentId);
          merged[assessmentId] = {
            score,
            maxScore: a?.maxScore ?? 100
          };
        }
      }
      const pct = calculateWeightedPercentage(assessments, merged);
      if (pct !== null) {
        setPendingGrades((prev) => ({
          ...prev,
          [enrollmentId]: percentageToGrade(pct)
        }));
      }
    } catch {
      toast.error("Failed to save scores");
    }
  };
  const handleSubmitGrade = async (enrollmentId, isUpdate) => {
    const student = students.find((s) => s.enrollmentId === enrollmentId);
    const pct = student ? calculatedPercentage(student) : null;
    const grade = pendingGrades[enrollmentId] ?? student?.grade ?? (pct !== null ? percentageToGrade(pct) : null);
    if (!grade) {
      toast.error("Please select a grade first");
      return;
    }
    setSubmitting(enrollmentId);
    try {
      const gradeData = {
        enrollmentId,
        grade
      };
      const result = isUpdate ? await updateGradeAction({
        data: gradeData
      }) : await submitGradeAction({
        data: gradeData
      });
      if (result.success) {
        toast.success(isUpdate ? "Grade updated" : "Grade submitted");
        setPendingGrades((prev) => {
          const copy = {
            ...prev
          };
          delete copy[enrollmentId];
          return copy;
        });
        refreshData();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to submit grade");
    } finally {
      setSubmitting(null);
    }
  };
  const validGradeValues = new Set(Object.keys(GRADE_LABELS));
  const gradeOptions = reactExports.useMemo(() => Object.entries(GRADE_LABELS).map(([value, label]) => ({
    value,
    label
  })), []);
  const handleCsvImport = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setBulkImporting(true);
    try {
      const text = await file.text();
      const lines = text.trim().split("\n").slice(1);
      const grades = [];
      const errors = [];
      for (let i = 0; i < lines.length; i++) {
        const cols = lines[i].split(",").map((c) => c.trim());
        if (cols.length < 2) {
          errors.push(`Row ${i + 2}: Invalid format`);
          continue;
        }
        const email = cols[0].toLowerCase();
        const raw = cols[1].toUpperCase().trim();
        const gradeVal = raw.replace(/\+/g, "_PLUS").replace(/-/g, "_MINUS");
        if (!validGradeValues.has(gradeVal)) {
          errors.push(`Row ${i + 2}: Invalid grade "${cols[1]}"`);
          continue;
        }
        const student = students.find((s) => s.email.toLowerCase() === email);
        if (!student) {
          errors.push(`Row ${i + 2}: Student "${cols[0]}" not found`);
          continue;
        }
        grades.push({
          enrollmentId: student.enrollmentId,
          grade: gradeVal
        });
      }
      if (errors.length > 0) {
        toast.error(`CSV errors: ${errors.slice(0, 3).join("; ")}${errors.length > 3 ? "..." : ""}`);
      }
      if (grades.length > 0) {
        const result = await bulkSubmitGradesAction({
          data: {
            courseId,
            grades
          }
        });
        if (result.success) {
          toast.success(`Imported: ${result.data.successCount} succeeded, ${result.data.failCount} failed`);
          refreshData();
        }
      } else {
        toast.error("No valid grades in CSV");
      }
    } catch {
      toast.error("Failed to parse CSV");
    } finally {
      setBulkImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };
  const addAssessmentRow = () => {
    setAssessmentForm((prev) => [...prev, {
      name: "",
      weight: 0,
      maxScore: 100
    }]);
  };
  const removeAssessmentRow = (idx) => {
    setAssessmentForm((prev) => prev.filter((_, i) => i !== idx));
  };
  const updateAssessmentForm = (idx, field, value) => {
    setAssessmentForm((prev) => {
      const next = [...prev];
      next[idx] = {
        ...next[idx],
        [field]: value
      };
      return next;
    });
  };
  const gradableStudents = students.filter((s) => s.status === "ENROLLED" || s.status === "COMPLETED");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Instructor",
      href: "/instructor"
    }, {
      label: "Courses",
      href: "/instructor/courses"
    }, {
      label: "Grading"
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: "Grade Submission" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mt-1", children: "Configure assessment weights and submit grades." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { ref: fileInputRef, type: "file", accept: ".csv", className: "hidden", onChange: handleCsvImport }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: () => fileInputRef.current?.click(), disabled: bulkImporting, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4 mr-2" }),
            bulkImporting ? "Importing..." : "Import CSV"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "cursor-pointer hover:bg-muted/50 transition-colors py-4", onClick: toggleAssessmentOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "text-base flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Settings2, { className: "h-4 w-4" }),
            "Assessment Weights",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground font-normal text-sm", children: assessmentOpen ? "▼" : "▶" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: assessments.length > 0 ? assessments.map((a) => `${a.name} (${a.weight}%)`).join(", ") : "Set weights for tests, exams, assignments, etc. Total must equal 100%." })
        ] }) }) }),
        assessmentOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4 pt-0 border-t", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: `Define assessment categories and their percentage weights. Weights must total 100%. Set "max pts" to the max points for each assessment (e.g. Test 1 max 15 if it's out of 15).` }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: assessmentForm.map((a, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 items-center", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Name (e.g. Test 1)", value: a.name, onChange: (e) => updateAssessmentForm(idx, "name", e.target.value), className: "w-40" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: 0, max: 100, placeholder: "%", value: a.weight || "", onChange: (e) => updateAssessmentForm(idx, "weight", parseInt(e.target.value, 10) || 0), className: "w-20" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground text-sm", children: "%" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: 1, placeholder: "Max", value: a.maxScore, onChange: (e) => updateAssessmentForm(idx, "maxScore", parseInt(e.target.value, 10) || 100), className: "w-16" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground text-xs", children: "max pts" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "icon", onClick: () => removeAssessmentRow(idx), className: "shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
          ] }, idx)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", size: "sm", onClick: addAssessmentRow, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-1" }),
              "Add custom"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: handleSaveAssessments, disabled: savingAssessments || assessmentForm.reduce((s, a) => s + a.weight, 0) !== 100, children: savingAssessments ? "Saving..." : "Save weights" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
            "Total: ",
            assessmentForm.reduce((s, a) => s + a.weight, 0),
            "%",
            assessmentForm.reduce((s, a) => s + a.weight, 0) !== 100 && " (must be 100%)"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-dashed", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "py-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-sm", children: "Bulk Grade Import" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardDescription, { className: "text-xs", children: [
          "CSV columns: ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "font-mono bg-muted px-1 rounded", children: "email,grade" }),
          ". Valid grades: ",
          Object.values(GRADE_LABELS).join(", "),
          "."
        ] })
      ] }) }),
      gradableStudents.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: ClipboardList, title: "No students to grade", description: "No enrolled or completed students in this course." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        assessments.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-primary/30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "py-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "To add each student's scores per assessment:" }),
          ` Save your assessment weights above first (click "Save weights"). Then columns for Test 1, Mid-Exam, Assignment, Quiz, Final Exam will appear here where you can enter each student's score.`
        ] }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Student" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Status" }),
            assessments.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableHead, { className: "text-center min-w-[70px]", children: [
              a.name,
              " (",
              a.weight,
              "%)"
            ] }, a.id)),
            assessments.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-center", children: "Calc %" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Final Grade" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: gradableStudents.map((s) => {
            const pct = calculatedPercentage(s);
            const suggested = suggestedGrade(s);
            const scores = getEffectiveScores(s);
            const hasPendingScores = Object.keys(pendingScores[s.enrollmentId] ?? {}).length > 0;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { className: "font-medium", children: [
                s.firstName,
                " ",
                s.lastName
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-muted-foreground text-sm", children: s.email }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: s.status === "ENROLLED" ? "success" : s.status === "COMPLETED" ? "secondary" : "destructive", children: s.status }) }),
              assessments.map((a) => {
                const val = pendingScores[s.enrollmentId]?.[a.id];
                const base = scores[a.id]?.score;
                const display = val !== void 0 ? val === "" ? "" : val : base ?? "";
                return /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "p-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: 0, max: a.maxScore, step: 0.5, placeholder: `/ ${a.maxScore}`, value: display, onChange: (e) => {
                  const v = e.target.value;
                  handleScoreChange(s.enrollmentId, a.id, v === "" ? "" : parseFloat(v));
                }, className: "h-8 w-16 text-center text-sm" }) }, a.id);
              }),
              assessments.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { className: "text-center text-sm font-medium", children: [
                pct !== null ? `${pct}%` : "-",
                suggested && pct !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block text-xs text-muted-foreground", children: [
                  "→ ",
                  GRADE_LABELS[suggested]
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-0.5", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: pendingGrades[s.enrollmentId] ?? s.grade ?? suggested ?? "", onValueChange: (val) => handleGradeChange(s.enrollmentId, val), children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-24", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Grade" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: gradeOptions.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: g.value, children: g.label }, g.value)) })
                ] }),
                s.gradedByName && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-muted-foreground", children: [
                  "by ",
                  s.gradedByName
                ] })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { className: "text-right space-x-1", children: [
                hasPendingScores && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => handleSaveScores(s.enrollmentId), children: "Save scores" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", disabled: !(pendingGrades[s.enrollmentId] ?? s.grade ?? suggested), loading: submitting === s.enrollmentId, onClick: () => setConfirmGrade({
                  enrollmentId: s.enrollmentId,
                  isUpdate: s.status === "COMPLETED"
                }), children: submitting === s.enrollmentId ? "Saving..." : s.status === "COMPLETED" ? "Update" : "Submit" })
              ] })
            ] }, s.enrollmentId);
          }) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialog, { open: !!confirmGrade, onOpenChange: (open) => !open && setConfirmGrade(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogContent, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogTitle, { children: confirmGrade?.isUpdate ? "Update Grade" : "Submit Grade" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogDescription, { children: confirmGrade?.isUpdate ? "This will overwrite the existing grade." : "This will mark the enrollment as completed." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogFooter, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogCancel, { children: "Cancel" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogAction, { onClick: () => {
            if (confirmGrade) {
              handleSubmitGrade(confirmGrade.enrollmentId, confirmGrade.isUpdate);
              setConfirmGrade(null);
            }
          }, children: "Confirm" })
        ] })
      ] }) })
    ] })
  ] });
}
export {
  InstructorGradingPage as component
};
