import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { R as Root } from "../_chunks/_libs/@radix-ui/react-label.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { A as cn } from "./router-DhCkpF2X.mjs";
const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);
const Label = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Root,
  {
    ref,
    className: cn(labelVariants(), className),
    ...props
  }
));
Label.displayName = Root.displayName;
export {
  Label as L
};
