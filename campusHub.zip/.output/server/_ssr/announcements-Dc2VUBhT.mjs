import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a0 as Route$b, B as Button, a1 as updateAnnouncementAction, a2 as createAnnouncementAction, a3 as deleteAnnouncementAction, a4 as listAllAnnouncementsAction } from "./router-DhCkpF2X.mjs";
import { I as Input } from "./input-9b2Tum0N.mjs";
import { L as Label } from "./label-DItuXM8a.mjs";
import { T as Textarea } from "./textarea-V4BEVgvG.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BlCW8AsE.mjs";
import { D as Dialog, e as DialogTrigger, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription, f as DialogFooter } from "./dialog-bXLpXEvc.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-D5Fm91vy.mjs";
import { A as AlertDialog, a as AlertDialogContent, b as AlertDialogHeader, c as AlertDialogTitle, d as AlertDialogDescription, e as AlertDialogFooter, f as AlertDialogCancel, g as AlertDialogAction } from "./alert-dialog-DTkhQAha.mjs";
import { E as EmptyState } from "./empty-state-D-g1-il0.mjs";
import { A as AnnouncementMedia } from "./AnnouncementMedia-B_p_UiOu.mjs";
import { W as Plus, Y as Upload, X, a as Megaphone, I as Info, Z as Pencil, R as Trash2 } from "../_libs/lucide-react.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/isbot.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "../_libs/zod.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./course.schema-DAXkVW6U.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
import "../_chunks/_libs/@radix-ui/react-label.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "./constants-DoiYt0dc.mjs";
import "../_chunks/_libs/@radix-ui/react-dialog.mjs";
import "../_chunks/_libs/@radix-ui/react-select.mjs";
import "../_chunks/_libs/@radix-ui/number.mjs";
import "../_chunks/_libs/@radix-ui/react-use-previous.mjs";
import "../_chunks/_libs/@radix-ui/react-visually-hidden.mjs";
import "../_chunks/_libs/@radix-ui/react-alert-dialog.mjs";
async function uploadToCloudinary(file, resourceType) {
  try {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("resourceType", resourceType);
    const res = await fetch("/api/upload/file", {
      method: "POST",
      body: formData,
      credentials: "include"
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || "Upload failed");
    }
    const data = await res.json();
    return data.url ?? null;
  } catch {
    return null;
  }
}
function AdminAnnouncementsPage() {
  const {
    announcements: initial
  } = Route$b.useLoaderData();
  const {
    user
  } = Route$b.useRouteContext();
  const [announcements, setAnnouncements] = reactExports.useState(initial);
  const [dialogOpen, setDialogOpen] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  const [deleteTarget, setDeleteTarget] = reactExports.useState(null);
  const [detailTarget, setDetailTarget] = reactExports.useState(null);
  const [mode, setMode] = reactExports.useState("create");
  const [editingId, setEditingId] = reactExports.useState(null);
  const [title, setTitle] = reactExports.useState("");
  const [content, setContent] = reactExports.useState("");
  const [targetRole, setTargetRole] = reactExports.useState("ALL");
  const [mediaType, setMediaType] = reactExports.useState("TEXT");
  const [mediaUrl, setMediaUrl] = reactExports.useState("");
  const [uploading, setUploading] = reactExports.useState(false);
  const fileInputRef = reactExports.useRef(null);
  const refresh = async () => {
    const data = await listAllAnnouncementsAction();
    setAnnouncements(data);
  };
  const resetForm = () => {
    setTitle("");
    setContent("");
    setTargetRole("ALL");
    setMediaType("TEXT");
    setMediaUrl("");
    setEditingId(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };
  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const resType = mediaType === "VIDEO" ? "video" : "image";
      const url = await uploadToCloudinary(file, resType);
      if (url) {
        setMediaUrl(url);
        toast.success("File uploaded successfully");
      } else {
        toast.error("Upload failed. Add Cloudinary env vars or paste a URL instead.");
      }
    } catch {
      toast.error("Upload failed");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  };
  const openCreateDialog = () => {
    setMode("create");
    resetForm();
    setDialogOpen(true);
  };
  const openEditDialog = (a) => {
    setMode("edit");
    setEditingId(a.id);
    setTitle(a.title);
    setContent(a.content);
    setTargetRole(a.targetRole ?? "ALL");
    setMediaType(a.mediaType || "TEXT");
    setMediaUrl(a.mediaUrl ?? "");
    setDialogOpen(true);
  };
  const handleSave = async () => {
    if (!title.trim() || !content.trim()) {
      toast.error("Title and content are required");
      return;
    }
    setSaving(true);
    try {
      const commonData = {
        title,
        content,
        targetRole: targetRole === "ALL" ? null : targetRole,
        mediaType,
        mediaUrl: mediaUrl.trim() || void 0
      };
      const result = mode === "edit" && editingId ? await updateAnnouncementAction({
        data: {
          id: editingId,
          ...commonData
        }
      }) : await createAnnouncementAction({
        data: commonData
      });
      if (result.success) {
        toast.success(mode === "edit" ? "Announcement updated successfully" : "Announcement created successfully");
        setDialogOpen(false);
        resetForm();
        refresh();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error(mode === "edit" ? "Failed to update announcement" : "Failed to create announcement");
    } finally {
      setSaving(false);
    }
  };
  const handleTogglePublish = async (a) => {
    const result = await updateAnnouncementAction({
      data: {
        id: a.id,
        isPublished: !a.isPublished
      }
    });
    if (result.success) {
      toast.success(a.isPublished ? "Announcement unpublished" : "Announcement published");
      refresh();
    } else {
      toast.error(result.error.message);
    }
  };
  const handleDelete = async () => {
    if (!deleteTarget) return;
    const result = await deleteAnnouncementAction({
      data: {
        id: deleteTarget.id
      }
    });
    if (result.success) {
      toast.success("Announcement deleted");
      setDeleteTarget(null);
      refresh();
    } else {
      toast.error(result.error.message);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Admin",
      href: "/admin"
    }, {
      label: "Announcements"
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: "Announcements" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mt-1", children: "Create and manage system announcements." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open: dialogOpen, onOpenChange: setDialogOpen, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: (e) => {
            e.preventDefault();
            openCreateDialog();
          }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-4 w-4 mr-2" }),
            "New Announcement"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: mode === "edit" ? "Edit Announcement" : "Create Announcement" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: mode === "edit" ? "Update the content and media for this announcement." : "Create a new announcement visible to users." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 py-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Title" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: title, onChange: (e) => setTitle(e.target.value), placeholder: "Announcement title" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Content" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: content, onChange: (e) => setContent(e.target.value), placeholder: "Announcement content...", rows: 4 })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Target Audience" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: targetRole, onValueChange: setTargetRole, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "ALL", children: "All Users" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "STUDENT", children: "Students Only" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "INSTRUCTOR", children: "Instructors Only" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "ADMIN", children: "Admins Only" })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Content type" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: mediaType, onValueChange: (v) => {
                  setMediaType(v);
                  setMediaUrl("");
                  if (fileInputRef.current) fileInputRef.current.value = "";
                }, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Select type" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectContent, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "TEXT", children: "Text only" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "IMAGE", children: "Image (upload or paste URL)" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "VIDEO", children: "Video (upload or paste URL)" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "AUDIO", children: "Audio (paste URL)" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: "Select Image or Video to upload files via Cloudinary or paste a URL." })
              ] }),
              (mediaType === "IMAGE" || mediaType === "VIDEO") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Upload or paste URL" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { ref: fileInputRef, type: "file", accept: mediaType === "IMAGE" ? "image/*" : "video/*", className: "hidden", onChange: handleFileUpload }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: () => fileInputRef.current?.click(), disabled: uploading, children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-4 w-4 mr-2" }),
                    uploading ? "Uploading..." : "Upload"
                  ] }),
                  mediaUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => {
                    setMediaUrl("");
                    fileInputRef.current && (fileInputRef.current.value = "");
                  }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: mediaUrl, onChange: (e) => setMediaUrl(e.target.value), placeholder: mediaType === "IMAGE" ? "Or paste image URL (e.g. Cloudinary, imgur)" : "Or paste URL (YouTube, Vimeo, MP4)" })
              ] }),
              mediaType === "AUDIO" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Media URL" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: mediaUrl, onChange: (e) => setMediaUrl(e.target.value), placeholder: "https://... (MP3, hosted audio)" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: handleSave, loading: saving, children: saving ? mode === "edit" ? "Saving…" : "Creating…" : mode === "edit" ? "Save changes" : "Create" }) })
          ] })
        ] })
      ] }),
      announcements.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: Megaphone, title: "No announcements yet", description: "Create your first announcement to communicate with users.", action: {
        label: "Create Announcement",
        onClick: () => setDialogOpen(true)
      } }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-md border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Title" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Author" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Audience" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Status" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Date" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: announcements.map((a) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "font-medium max-w-xs truncate", children: a.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: a.authorName }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", children: a.targetRole || "All" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: a.isPublished ? "success" : "secondary", children: a.isPublished ? "Published" : "Draft" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: new Date(a.createdAt).toLocaleDateString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { className: "text-right space-x-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", onClick: () => setDetailTarget(a), title: "View details", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "h-4 w-4 mr-1" }),
              "Details"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", onClick: () => openEditDialog(a), title: "Edit announcement", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-4 w-4 mr-1" }),
              "Edit"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleTogglePublish(a), children: a.isPublished ? "Unpublish" : "Publish" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", className: "text-destructive hover:text-destructive", onClick: () => setDeleteTarget(a), title: "Delete announcement", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4" }) })
          ] })
        ] }, a.id)) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialog, { open: !!deleteTarget, onOpenChange: (open) => !open && setDeleteTarget(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogTitle, { children: "Delete Announcement" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogDescription, { children: [
          'Are you sure you want to delete "',
          deleteTarget?.title,
          '"? This cannot be undone.'
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogCancel, { children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogAction, { onClick: handleDelete, className: "bg-destructive text-destructive-foreground hover:bg-destructive/90", children: "Delete" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: !!detailTarget, onOpenChange: (open) => !open && setDetailTarget(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: detailTarget?.title ?? "Announcement details" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Full details for this announcement, including content and any attached media." })
      ] }),
      detailTarget && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 py-2 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", children: detailTarget.targetRole || "All users" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: detailTarget.isPublished ? "success" : "secondary", children: detailTarget.isPublished ? "Published" : "Draft" }),
          detailTarget.mediaType && detailTarget.mediaType !== "TEXT" && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "uppercase", children: detailTarget.mediaType }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: new Date(detailTarget.createdAt).toLocaleString() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-foreground mb-1", children: "Content" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "whitespace-pre-line", children: detailTarget.content })
        ] }),
        detailTarget.mediaType && detailTarget.mediaType !== "TEXT" && detailTarget.mediaUrl && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-foreground mb-1 capitalize", children: detailTarget.mediaType }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AnnouncementMedia, { mediaType: detailTarget.mediaType, mediaUrl: detailTarget.mediaUrl, title: detailTarget.title })
        ] })
      ] })
    ] }) })
  ] });
}
export {
  AdminAnnouncementsPage as component
};
