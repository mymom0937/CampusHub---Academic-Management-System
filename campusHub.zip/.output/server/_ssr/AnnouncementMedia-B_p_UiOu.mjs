import { j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
function getYouTubeEmbedUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (url.hostname.includes("youtube.com")) {
      const v = url.searchParams.get("v");
      if (v) return `https://www.youtube.com/embed/${v}`;
    }
    if (url.hostname === "youtu.be") {
      const id = url.pathname.replace("/", "");
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    return null;
  } catch {
    return null;
  }
}
function AnnouncementMedia({
  mediaType,
  mediaUrl,
  title,
  className = ""
}) {
  if (!mediaUrl || !mediaType || mediaType === "TEXT") return null;
  if (mediaType === "IMAGE") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `mt-2 ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "img",
      {
        src: mediaUrl,
        alt: title,
        className: "max-w-full max-h-80 rounded-md border object-contain"
      }
    ) });
  }
  if (mediaType === "VIDEO") {
    const embed = getYouTubeEmbedUrl(mediaUrl);
    if (embed) {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `mt-2 aspect-video w-full overflow-hidden rounded-md border bg-black ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "iframe",
        {
          src: embed,
          title,
          className: "h-full w-full",
          allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
          allowFullScreen: true
        }
      ) });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `mt-2 ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "video",
      {
        controls: true,
        className: "w-full max-h-80 rounded-md border bg-black",
        src: mediaUrl,
        children: "Your browser does not support the video tag."
      }
    ) });
  }
  if (mediaType === "AUDIO") {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `mt-2 ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("audio", { controls: true, className: "w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("source", { src: mediaUrl }),
      "Your browser does not support the audio element."
    ] }) });
  }
  return null;
}
export {
  AnnouncementMedia as A
};
