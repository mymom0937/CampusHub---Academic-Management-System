import { p as prisma } from "./middleware-DiEMT5y4.mjs";
async function findCourseById(id) {
  return prisma.course.findFirst({
    where: { id, deletedAt: null },
    include: {
      semester: true,
      instructorAssignments: {
        include: {
          instructor: {
            select: { id: true, firstName: true, lastName: true }
          }
        }
      },
      _count: {
        select: {
          enrollments: { where: { status: "ENROLLED" } }
        }
      }
    }
  });
}
async function listCourses(params) {
  const { page, pageSize, search, semesterId } = params;
  const where = {
    deletedAt: null,
    ...semesterId && { semesterId },
    ...search && {
      OR: [
        { code: { contains: search, mode: "insensitive" } },
        { name: { contains: search, mode: "insensitive" } }
      ]
    }
  };
  const [items, total] = await Promise.all([
    prisma.course.findMany({
      where,
      include: {
        semester: { select: { id: true, name: true, code: true } },
        instructorAssignments: {
          include: {
            instructor: {
              select: { id: true, firstName: true, lastName: true }
            }
          }
        },
        _count: {
          select: {
            enrollments: { where: { status: "ENROLLED" } }
          }
        }
      },
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: { code: "asc" }
    }),
    prisma.course.count({ where })
  ]);
  return { items, total };
}
async function createCourse(data) {
  return prisma.course.create({ data });
}
async function updateCourse(id, data) {
  return prisma.course.update({
    where: { id },
    data
  });
}
async function assignInstructor(data) {
  return prisma.instructorAssignment.create({ data });
}
async function removeInstructor(courseId, instructorId) {
  return prisma.instructorAssignment.delete({
    where: {
      instructorId_courseId: { instructorId, courseId }
    }
  });
}
async function findCoursesByInstructor(instructorId) {
  return prisma.course.findMany({
    where: {
      deletedAt: null,
      instructorAssignments: {
        some: { instructorId }
      }
    },
    include: {
      semester: { select: { id: true, name: true, code: true, isActive: true } },
      instructorAssignments: {
        include: {
          instructor: {
            select: { id: true, firstName: true, lastName: true }
          }
        }
      },
      _count: {
        select: {
          enrollments: { where: { status: "ENROLLED" } }
        }
      }
    },
    orderBy: { semester: { startDate: "desc" } }
  });
}
async function findCourseCatalog(semesterId, search) {
  return prisma.course.findMany({
    where: {
      deletedAt: null,
      semesterId,
      ...search && {
        OR: [
          { code: { contains: search, mode: "insensitive" } },
          { name: { contains: search, mode: "insensitive" } }
        ]
      }
    },
    include: {
      semester: { select: { id: true, name: true, enrollmentStart: true, enrollmentEnd: true } },
      instructorAssignments: {
        include: {
          instructor: {
            select: { id: true, firstName: true, lastName: true }
          }
        }
      },
      _count: {
        select: {
          enrollments: { where: { status: "ENROLLED" } }
        }
      }
    },
    orderBy: { code: "asc" }
  });
}
async function archiveCourse(id) {
  return prisma.course.update({
    where: { id },
    data: { deletedAt: /* @__PURE__ */ new Date() }
  });
}
export {
  assignInstructor as a,
  archiveCourse as b,
  createCourse as c,
  findCoursesByInstructor as d,
  findCourseCatalog as e,
  findCourseById as f,
  listCourses as l,
  removeInstructor as r,
  updateCourse as u
};
