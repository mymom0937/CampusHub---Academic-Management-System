const SUPPORT_EMAIL = "support@campushub.com";
const GITHUB_URL = "https://github.com";
const FACEBOOK_URL = "https://facebook.com";
const INSTAGRAM_URL = "https://instagram.com";
const YOUTUBE_URL = "https://youtube.com";
const MAX_CREDITS_PER_SEMESTER = 18;
const GRADE_POINTS = {
  A_PLUS: 4,
  A: 4,
  A_MINUS: 3.75,
  B_PLUS: 3.5,
  B: 3,
  B_MINUS: 2.75,
  C_PLUS: 2.5,
  C: 2,
  D: 1,
  F: 0,
  P: null,
  // Pass - no GPA impact
  I: null,
  // Incomplete - no GPA impact
  W: null,
  // Withdrawn - no GPA impact
  DO: null,
  // Dropout - no GPA impact
  NG: null
  // No Grade - no GPA impact
};
const GRADE_LABELS = {
  A_PLUS: "A+",
  A: "A",
  A_MINUS: "A-",
  B_PLUS: "B+",
  B: "B",
  B_MINUS: "B-",
  C_PLUS: "C+",
  C: "C",
  D: "D",
  F: "F",
  P: "P",
  I: "I",
  W: "W",
  DO: "DO",
  NG: "NG"
};
const PERCENTAGE_TO_GRADE = [
  { min: 90, max: 100, grade: "A_PLUS" },
  { min: 85, max: 89, grade: "A" },
  { min: 80, max: 84, grade: "A_MINUS" },
  { min: 75, max: 79, grade: "B_PLUS" },
  { min: 70, max: 74, grade: "B" },
  { min: 65, max: 69, grade: "B_MINUS" },
  { min: 60, max: 64, grade: "C_PLUS" },
  { min: 50, max: 59, grade: "C" },
  { min: 40, max: 49, grade: "D" },
  { min: 0, max: 39, grade: "F" }
];
function percentageToGrade(percentage) {
  const clamped = Math.max(0, Math.min(100, percentage));
  const entry = PERCENTAGE_TO_GRADE.find((r) => clamped >= r.min && clamped <= r.max);
  return entry?.grade ?? "F";
}
const DEFAULT_ASSESSMENT_WEIGHTS = [
  { name: "Test 1", weight: 15, maxScore: 15 },
  { name: "Mid-Exam", weight: 25, maxScore: 25 },
  { name: "Assignment", weight: 15, maxScore: 15 },
  { name: "Quiz", weight: 5, maxScore: 5 },
  { name: "Final Exam", weight: 40, maxScore: 40 }
];
const ACADEMIC_STANDING = {
  DEANS_LIST: 3.5,
  // GPA ≥ 3.5
  GOOD_STANDING: 2
  // GPA ≥ 2.0
  /** GPA < 2.0 = Academic Probation */
};
export {
  ACADEMIC_STANDING as A,
  DEFAULT_ASSESSMENT_WEIGHTS as D,
  FACEBOOK_URL as F,
  GRADE_POINTS as G,
  INSTAGRAM_URL as I,
  MAX_CREDITS_PER_SEMESTER as M,
  SUPPORT_EMAIL as S,
  YOUTUBE_URL as Y,
  GITHUB_URL as a,
  GRADE_LABELS as b,
  percentageToGrade as p
};
