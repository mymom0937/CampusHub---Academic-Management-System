import { o as object, s as string, _ as _enum, c as boolean } from "../_libs/zod.mjs";
const mediaTypeEnum = _enum(["TEXT", "IMAGE", "VIDEO", "AUDIO"]);
const createAnnouncementSchema = object({
  title: string().min(1, "Title is required").max(200, "Title too long"),
  content: string().min(1, "Content is required").max(5e3, "Content too long"),
  targetRole: _enum(["ADMIN", "INSTRUCTOR", "STUDENT"]).nullable().optional(),
  mediaType: mediaTypeEnum.optional(),
  mediaUrl: string().trim().max(2048, "Media URL too long").optional().refine(
    (val) => !val || /^https:\/\//.test(val),
    "Media URL must be a valid https URL (e.g. Cloudinary, YouTube)"
  )
});
const updateAnnouncementSchema = object({
  id: string().min(1),
  title: string().min(1).max(200).optional(),
  content: string().min(1).max(5e3).optional(),
  targetRole: _enum(["ADMIN", "INSTRUCTOR", "STUDENT"]).nullable().optional(),
  isPublished: boolean().optional(),
  mediaType: mediaTypeEnum.optional(),
  mediaUrl: string().trim().max(2048, "Media URL too long").optional().refine(
    (val) => !val || /^https:\/\//.test(val),
    "Media URL must be a valid https URL (e.g. Cloudinary, YouTube)"
  )
});
const addPrerequisiteSchema = object({
  courseCode: string().min(1, "Course code is required"),
  prerequisiteCode: string().min(1, "Prerequisite code is required")
});
export {
  addPrerequisiteSchema as a,
  createAnnouncementSchema as c,
  updateAnnouncementSchema as u
};
