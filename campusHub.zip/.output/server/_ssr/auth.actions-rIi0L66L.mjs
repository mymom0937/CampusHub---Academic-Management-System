import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { l as loginSchema, r as registerSchema, c as changePasswordSchema, f as forgotPasswordSchema, a as resetPasswordSchema } from "./auth.schema-DqwSeq56.mjs";
import { c as auth, b as authMiddleware } from "./middleware-DiEMT5y4.mjs";
import { c as createServerFn, g as getRequestHeaders } from "./server-BubZoQFo.mjs";
import "../_libs/zod.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
function toSessionUser(au) {
  return {
    id: au.id,
    email: au.email,
    firstName: au.firstName,
    lastName: au.lastName,
    role: au.role,
    isActive: au.isActive ?? true,
    emailVerified: au.emailVerified ?? false
  };
}
const getSession_createServerFn_handler = createServerRpc({
  id: "3371e9152efa504ad80eb9dab602b7aa7a1b3e29a8d33eb7d02a3331db1793b0",
  name: "getSession",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => getSession.__executeServer(opts));
const getSession = createServerFn({
  method: "GET"
}).handler(getSession_createServerFn_handler, async () => {
  try {
    const session = await auth.api.getSession({
      headers: getRequestHeaders()
    });
    return session ? toSessionUser(session.user) : null;
  } catch {
    return null;
  }
});
const loginAction_createServerFn_handler = createServerRpc({
  id: "1fc2b78f24004bcf959a71aecd98be95da1b6d6d790a26b949d3b8359eb7a853",
  name: "loginAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => loginAction.__executeServer(opts));
const loginAction = createServerFn({
  method: "POST"
}).inputValidator((data) => loginSchema.parse(data)).handler(loginAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const result = await auth.api.signInEmail({
      body: {
        email: data.email,
        password: data.password
      }
    });
    if (!result) {
      return {
        success: false,
        error: {
          code: "UNAUTHORIZED",
          message: "Invalid email or password"
        }
      };
    }
    const user = result.user;
    if (user.isActive === false) {
      return {
        success: false,
        error: {
          code: "UNAUTHORIZED",
          message: "Your account has been deactivated"
        }
      };
    }
    return {
      success: true,
      data: {
        user: toSessionUser(user)
      }
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid email or password";
    return {
      success: false,
      error: {
        code: "UNAUTHORIZED",
        message
      }
    };
  }
});
const registerAction_createServerFn_handler = createServerRpc({
  id: "43a6492e0a1ad82b31d169e5e21da6e021a02ca51658015613954b019149e30a",
  name: "registerAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => registerAction.__executeServer(opts));
const registerAction = createServerFn({
  method: "POST"
}).inputValidator((data) => registerSchema.parse(data)).handler(registerAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const result = await auth.api.signUpEmail({
      body: {
        name: `${data.firstName} ${data.lastName}`,
        email: data.email,
        password: data.password,
        firstName: data.firstName,
        lastName: data.lastName
      }
    });
    if (!result) {
      return {
        success: false,
        error: {
          code: "INTERNAL_ERROR",
          message: "Registration failed"
        }
      };
    }
    return {
      success: true,
      data: {
        user: toSessionUser(result.user)
      }
    };
  } catch (error) {
    const msg = error instanceof Error ? error.message : "An error occurred during registration";
    const isConflict = msg.toLowerCase().includes("already") || msg.toLowerCase().includes("exist");
    return {
      success: false,
      error: {
        code: isConflict ? "CONFLICT" : "INTERNAL_ERROR",
        message: isConflict ? "An account with this email already exists" : msg
      }
    };
  }
});
const logoutAction_createServerFn_handler = createServerRpc({
  id: "b134a94da9cdf8cd1d7c10e3a4739f3b43ba00b07adf2add0751d75e023d30fe",
  name: "logoutAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => logoutAction.__executeServer(opts));
const logoutAction = createServerFn({
  method: "POST"
}).handler(logoutAction_createServerFn_handler, async () => {
  try {
    await auth.api.signOut({
      headers: getRequestHeaders()
    });
  } catch {
  }
  return {
    success: true
  };
});
const changePasswordAction_createServerFn_handler = createServerRpc({
  id: "862731301a0699f12cd7566d1f4d830f2a3e8d7db7c8ca0a2c55f0ab6342c10c",
  name: "changePasswordAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => changePasswordAction.__executeServer(opts));
const changePasswordAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).inputValidator((data) => changePasswordSchema.parse(data)).handler(changePasswordAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await auth.api.changePassword({
      headers: getRequestHeaders(),
      body: {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
        revokeOtherSessions: false
      }
    });
    return {
      success: true
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to change password";
    return {
      success: false,
      error: {
        code: "UNAUTHORIZED",
        message
      }
    };
  }
});
const forgotPasswordAction_createServerFn_handler = createServerRpc({
  id: "769ec723d51f50224802d9b6e2cae3f9c35c4be43e1c5469d351775506cc171a",
  name: "forgotPasswordAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => forgotPasswordAction.__executeServer(opts));
const forgotPasswordAction = createServerFn({
  method: "POST"
}).inputValidator((data) => forgotPasswordSchema.parse(data)).handler(forgotPasswordAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await auth.api.requestPasswordReset({
      body: {
        email: data.email,
        redirectTo: "/reset-password"
      }
    });
  } catch {
  }
  return {
    success: true,
    message: "If an account exists with that email, a password reset link has been sent."
  };
});
const resetPasswordAction_createServerFn_handler = createServerRpc({
  id: "a2cb7ff49417ae30d2288557ef32e09d44d6d88079bb99c2dbc8ca9f5e099f3e",
  name: "resetPasswordAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => resetPasswordAction.__executeServer(opts));
const resetPasswordAction = createServerFn({
  method: "POST"
}).inputValidator((data) => resetPasswordSchema.parse(data)).handler(resetPasswordAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await auth.api.resetPassword({
      body: {
        token: data.token,
        newPassword: data.newPassword
      }
    });
    return {
      success: true
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to reset password";
    const isBadRequest = message.toLowerCase().includes("expired") || message.toLowerCase().includes("invalid");
    return {
      success: false,
      error: {
        code: isBadRequest ? "BAD_REQUEST" : "INTERNAL_ERROR",
        message: isBadRequest ? "This reset link has expired or is invalid. Please request a new one." : message
      }
    };
  }
});
const resendVerificationEmailAction_createServerFn_handler = createServerRpc({
  id: "f6796a5d69fa587fd6c14e8dfa344ef6f3bb2e74f31f283d9405ce2a6fba369f",
  name: "resendVerificationEmailAction",
  filename: "src/server/actions/auth.actions.ts"
}, (opts) => resendVerificationEmailAction.__executeServer(opts));
const resendVerificationEmailAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).handler(resendVerificationEmailAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  try {
    await auth.api.sendVerificationEmail({
      body: {
        email: user.email,
        callbackURL: "/"
      }
    });
    return {
      success: true,
      message: "Verification email sent. Please check your inbox."
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to send verification email";
    return {
      success: false,
      error: {
        code: "INTERNAL_ERROR",
        message
      }
    };
  }
});
export {
  changePasswordAction_createServerFn_handler,
  forgotPasswordAction_createServerFn_handler,
  getSession_createServerFn_handler,
  loginAction_createServerFn_handler,
  logoutAction_createServerFn_handler,
  registerAction_createServerFn_handler,
  resendVerificationEmailAction_createServerFn_handler,
  resetPasswordAction_createServerFn_handler
};
