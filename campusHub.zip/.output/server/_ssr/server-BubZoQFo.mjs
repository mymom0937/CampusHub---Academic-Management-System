import { c as createMemoryHistory } from "../_chunks/_libs/@tanstack/history.mjs";
import { p as defineHandlerCallback, q as parseRedirect, u as mergeHeaders, b as isRedirect, v as getNormalizedURL, w as getOrigin, x as attachRouterServerSsrUtils, y as createSerializationAdapter, z as createRawStreamRPCPlugin, i as isNotFound, A as isResolvedRedirect, C as executeRewriteInput, D as defaultSerovalPlugins, E as makeSerovalPlugin, a as rootRouteId, c as transformPipeableStreamWithRouter, t as transformReadableStreamWithRouter } from "../_chunks/_libs/@tanstack/router-core.mjs";
import { AsyncLocalStorage } from "node:async_hooks";
import { H as H3Event, t as toResponse, s as setCookie$1 } from "../_libs/h3-v2.mjs";
import { i as invariant } from "../_libs/tiny-invariant.mjs";
import { a as au, I as Iu, o as ou } from "../_libs/seroval.mjs";
import { j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { R as RouterProvider, r as renderRouterToStream } from "../_chunks/_libs/@tanstack/react-router.mjs";
function StartServer(props) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(RouterProvider, { router: props.router });
}
const defaultStreamHandler = defineHandlerCallback(
  ({ request, router, responseHeaders }) => renderRouterToStream({
    request,
    router,
    responseHeaders,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(StartServer, { router })
  })
);
const TSS_FORMDATA_CONTEXT = "__TSS_CONTEXT";
const TSS_SERVER_FUNCTION = /* @__PURE__ */ Symbol.for("TSS_SERVER_FUNCTION");
const TSS_SERVER_FUNCTION_FACTORY = /* @__PURE__ */ Symbol.for(
  "TSS_SERVER_FUNCTION_FACTORY"
);
const X_TSS_SERIALIZED = "x-tss-serialized";
const X_TSS_RAW_RESPONSE = "x-tss-raw";
const TSS_CONTENT_TYPE_FRAMED = "application/x-tss-framed";
const FrameType = {
  /** Seroval JSON chunk (NDJSON line) */
  JSON: 0,
  /** Raw stream data chunk */
  CHUNK: 1,
  /** Raw stream end (EOF) */
  END: 2,
  /** Raw stream error */
  ERROR: 3
};
const FRAME_HEADER_SIZE = 9;
const TSS_FRAMED_PROTOCOL_VERSION = 1;
const TSS_CONTENT_TYPE_FRAMED_VERSIONED = `${TSS_CONTENT_TYPE_FRAMED}; v=${TSS_FRAMED_PROTOCOL_VERSION}`;
const GLOBAL_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:start-storage-context");
const globalObj$1 = globalThis;
if (!globalObj$1[GLOBAL_STORAGE_KEY]) {
  globalObj$1[GLOBAL_STORAGE_KEY] = new AsyncLocalStorage();
}
const startStorage = globalObj$1[GLOBAL_STORAGE_KEY];
async function runWithStartContext(context, fn) {
  return startStorage.run(context, fn);
}
function getStartContext(opts) {
  const context = startStorage.getStore();
  if (!context && opts?.throwIfNotFound !== false) {
    throw new Error(
      `No Start context found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`
    );
  }
  return context;
}
const getStartOptions = () => getStartContext().startOptions;
const getStartContextServerOnly = getStartContext;
function isSafeKey(key) {
  return key !== "__proto__" && key !== "constructor" && key !== "prototype";
}
function safeObjectMerge(target, source) {
  const result = /* @__PURE__ */ Object.create(null);
  if (target) {
    for (const key of Object.keys(target)) {
      if (isSafeKey(key)) result[key] = target[key];
    }
  }
  if (source && typeof source === "object") {
    for (const key of Object.keys(source)) {
      if (isSafeKey(key)) result[key] = source[key];
    }
  }
  return result;
}
function createNullProtoObject(source) {
  if (!source) return /* @__PURE__ */ Object.create(null);
  const obj = /* @__PURE__ */ Object.create(null);
  for (const key of Object.keys(source)) {
    if (isSafeKey(key)) obj[key] = source[key];
  }
  return obj;
}
const createServerFn = (options, __opts) => {
  const resolvedOptions = __opts || options || {};
  if (typeof resolvedOptions.method === "undefined") {
    resolvedOptions.method = "GET";
  }
  const res = {
    options: resolvedOptions,
    middleware: (middleware) => {
      const newMiddleware = [...resolvedOptions.middleware || []];
      middleware.map((m) => {
        if (TSS_SERVER_FUNCTION_FACTORY in m) {
          if (m.options.middleware) {
            newMiddleware.push(...m.options.middleware);
          }
        } else {
          newMiddleware.push(m);
        }
      });
      const newOptions = {
        ...resolvedOptions,
        middleware: newMiddleware
      };
      const res2 = createServerFn(void 0, newOptions);
      res2[TSS_SERVER_FUNCTION_FACTORY] = true;
      return res2;
    },
    inputValidator: (inputValidator) => {
      const newOptions = { ...resolvedOptions, inputValidator };
      return createServerFn(void 0, newOptions);
    },
    handler: (...args) => {
      const [extractedFn, serverFn] = args;
      const newOptions = { ...resolvedOptions, extractedFn, serverFn };
      const resolvedMiddleware = [
        ...newOptions.middleware || [],
        serverFnBaseToMiddleware(newOptions)
      ];
      return Object.assign(
        async (opts) => {
          const result = await executeMiddleware$1(resolvedMiddleware, "client", {
            ...extractedFn,
            ...newOptions,
            data: opts?.data,
            headers: opts?.headers,
            signal: opts?.signal,
            fetch: opts?.fetch,
            context: createNullProtoObject()
          });
          const redirect = parseRedirect(result.error);
          if (redirect) {
            throw redirect;
          }
          if (result.error) throw result.error;
          return result.result;
        },
        {
          // This copies over the URL, function ID
          ...extractedFn,
          // The extracted function on the server-side calls
          // this function
          __executeServer: async (opts) => {
            const startContext = getStartContextServerOnly();
            const serverContextAfterGlobalMiddlewares = startContext.contextAfterGlobalMiddlewares;
            const ctx = {
              ...extractedFn,
              ...opts,
              // Ensure we use the full serverFnMeta from the provider file's extractedFn
              // (which has id, name, filename) rather than the partial one from SSR/client
              // callers (which only has id)
              serverFnMeta: extractedFn.serverFnMeta,
              // Use safeObjectMerge for opts.context which comes from client
              context: safeObjectMerge(
                serverContextAfterGlobalMiddlewares,
                opts.context
              ),
              request: startContext.request
            };
            const result = await executeMiddleware$1(
              resolvedMiddleware,
              "server",
              ctx
            ).then((d) => ({
              // Only send the result and sendContext back to the client
              result: d.result,
              error: d.error,
              context: d.sendContext
            }));
            return result;
          }
        }
      );
    }
  };
  const fun = (options2) => {
    const newOptions = {
      ...resolvedOptions,
      ...options2
    };
    return createServerFn(void 0, newOptions);
  };
  return Object.assign(fun, res);
};
async function executeMiddleware$1(middlewares, env, opts) {
  const globalMiddlewares = getStartOptions()?.functionMiddleware || [];
  let flattenedMiddlewares = flattenMiddlewares([
    ...globalMiddlewares,
    ...middlewares
  ]);
  if (env === "server") {
    const startContext = getStartContextServerOnly({ throwIfNotFound: false });
    if (startContext?.executedRequestMiddlewares) {
      flattenedMiddlewares = flattenedMiddlewares.filter(
        (m) => !startContext.executedRequestMiddlewares.has(m)
      );
    }
  }
  const callNextMiddleware = async (ctx) => {
    const nextMiddleware = flattenedMiddlewares.shift();
    if (!nextMiddleware) {
      return ctx;
    }
    try {
      if ("inputValidator" in nextMiddleware.options && nextMiddleware.options.inputValidator && env === "server") {
        ctx.data = await execValidator(
          nextMiddleware.options.inputValidator,
          ctx.data
        );
      }
      let middlewareFn = void 0;
      if (env === "client") {
        if ("client" in nextMiddleware.options) {
          middlewareFn = nextMiddleware.options.client;
        }
      } else if ("server" in nextMiddleware.options) {
        middlewareFn = nextMiddleware.options.server;
      }
      if (middlewareFn) {
        const userNext = async (userCtx = {}) => {
          const nextCtx = {
            ...ctx,
            ...userCtx,
            context: safeObjectMerge(ctx.context, userCtx.context),
            sendContext: safeObjectMerge(ctx.sendContext, userCtx.sendContext),
            headers: mergeHeaders(ctx.headers, userCtx.headers),
            _callSiteFetch: ctx._callSiteFetch,
            fetch: ctx._callSiteFetch ?? userCtx.fetch ?? ctx.fetch,
            result: userCtx.result !== void 0 ? userCtx.result : userCtx instanceof Response ? userCtx : ctx.result,
            error: userCtx.error ?? ctx.error
          };
          const result2 = await callNextMiddleware(nextCtx);
          if (result2.error) {
            throw result2.error;
          }
          return result2;
        };
        const result = await middlewareFn({
          ...ctx,
          next: userNext
        });
        if (isRedirect(result)) {
          return {
            ...ctx,
            error: result
          };
        }
        if (result instanceof Response) {
          return {
            ...ctx,
            result
          };
        }
        if (!result) {
          throw new Error(
            "User middleware returned undefined. You must call next() or return a result in your middlewares."
          );
        }
        return result;
      }
      return callNextMiddleware(ctx);
    } catch (error) {
      return {
        ...ctx,
        error
      };
    }
  };
  return callNextMiddleware({
    ...opts,
    headers: opts.headers || {},
    sendContext: opts.sendContext || {},
    context: opts.context || createNullProtoObject(),
    _callSiteFetch: opts.fetch
  });
}
function flattenMiddlewares(middlewares, maxDepth = 100) {
  const seen = /* @__PURE__ */ new Set();
  const flattened = [];
  const recurse = (middleware, depth) => {
    if (depth > maxDepth) {
      throw new Error(
        `Middleware nesting depth exceeded maximum of ${maxDepth}. Check for circular references.`
      );
    }
    middleware.forEach((m) => {
      if (m.options.middleware) {
        recurse(m.options.middleware, depth + 1);
      }
      if (!seen.has(m)) {
        seen.add(m);
        flattened.push(m);
      }
    });
  };
  recurse(middlewares, 0);
  return flattened;
}
async function execValidator(validator, input) {
  if (validator == null) return {};
  if ("~standard" in validator) {
    const result = await validator["~standard"].validate(input);
    if (result.issues)
      throw new Error(JSON.stringify(result.issues, void 0, 2));
    return result.value;
  }
  if ("parse" in validator) {
    return validator.parse(input);
  }
  if (typeof validator === "function") {
    return validator(input);
  }
  throw new Error("Invalid validator type!");
}
function serverFnBaseToMiddleware(options) {
  return {
    "~types": void 0,
    options: {
      inputValidator: options.inputValidator,
      client: async ({ next, sendContext, fetch: fetch2, ...ctx }) => {
        const payload = {
          ...ctx,
          // switch the sendContext over to context
          context: sendContext,
          fetch: fetch2
        };
        const res = await options.extractedFn?.(payload);
        return next(res);
      },
      server: async ({ next, ...ctx }) => {
        const result = await options.serverFn?.(ctx);
        return next({
          ...ctx,
          result
        });
      }
    }
  };
}
function getDefaultSerovalPlugins() {
  const start = getStartOptions();
  const adapters = start?.serializationAdapters;
  return [
    ...adapters?.map(makeSerovalPlugin) ?? [],
    ...defaultSerovalPlugins
  ];
}
const GLOBAL_EVENT_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:event-storage");
const globalObj = globalThis;
if (!globalObj[GLOBAL_EVENT_STORAGE_KEY]) {
  globalObj[GLOBAL_EVENT_STORAGE_KEY] = new AsyncLocalStorage();
}
const eventStorage = globalObj[GLOBAL_EVENT_STORAGE_KEY];
function isPromiseLike(value) {
  return typeof value.then === "function";
}
function getSetCookieValues(headers) {
  const headersWithSetCookie = headers;
  if (typeof headersWithSetCookie.getSetCookie === "function") {
    return headersWithSetCookie.getSetCookie();
  }
  const value = headers.get("set-cookie");
  return value ? [value] : [];
}
function mergeEventResponseHeaders(response, event) {
  if (response.ok) {
    return;
  }
  const eventSetCookies = getSetCookieValues(event.res.headers);
  if (eventSetCookies.length === 0) {
    return;
  }
  const responseSetCookies = getSetCookieValues(response.headers);
  response.headers.delete("set-cookie");
  for (const cookie of responseSetCookies) {
    response.headers.append("set-cookie", cookie);
  }
  for (const cookie of eventSetCookies) {
    response.headers.append("set-cookie", cookie);
  }
}
function attachResponseHeaders(value, event) {
  if (isPromiseLike(value)) {
    return value.then((resolved) => {
      if (resolved instanceof Response) {
        mergeEventResponseHeaders(resolved, event);
      }
      return resolved;
    });
  }
  if (value instanceof Response) {
    mergeEventResponseHeaders(value, event);
  }
  return value;
}
function requestHandler(handler) {
  return (request, requestOpts) => {
    const h3Event = new H3Event(request);
    const response = eventStorage.run(
      { h3Event },
      () => handler(request, requestOpts)
    );
    return toResponse(attachResponseHeaders(response, h3Event), h3Event);
  };
}
function getH3Event() {
  const event = eventStorage.getStore();
  if (!event) {
    throw new Error(
      `No StartEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`
    );
  }
  return event.h3Event;
}
function getRequestHeaders() {
  return getH3Event().req.headers;
}
function setCookie(name, value, options) {
  const event = getH3Event();
  setCookie$1(event, name, value, options);
}
function getResponse() {
  const event = getH3Event();
  return event.res;
}
async function getStartManifest(matchedRoutes) {
  const { tsrStartManifest } = await import("./_tanstack-start-manifest_v-B-u9yBDX.mjs");
  const startManifest = tsrStartManifest();
  const rootRoute = startManifest.routes[rootRouteId] = startManifest.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  let script = `import('${startManifest.clientEntry}')`;
  rootRoute.assets.push({
    tag: "script",
    attrs: {
      type: "module",
      async: true
    },
    children: script
  });
  const manifest2 = {
    routes: Object.fromEntries(
      Object.entries(startManifest.routes).flatMap(([k, v]) => {
        const result = {};
        let hasData = false;
        if (v.preloads && v.preloads.length > 0) {
          result["preloads"] = v.preloads;
          hasData = true;
        }
        if (v.assets && v.assets.length > 0) {
          result["assets"] = v.assets;
          hasData = true;
        }
        if (!hasData) {
          return [];
        }
        return [[k, result]];
      })
    )
  };
  return manifest2;
}
const textEncoder$1 = new TextEncoder();
const EMPTY_PAYLOAD = new Uint8Array(0);
function encodeFrame(type, streamId, payload) {
  const frame = new Uint8Array(FRAME_HEADER_SIZE + payload.length);
  frame[0] = type;
  frame[1] = streamId >>> 24 & 255;
  frame[2] = streamId >>> 16 & 255;
  frame[3] = streamId >>> 8 & 255;
  frame[4] = streamId & 255;
  frame[5] = payload.length >>> 24 & 255;
  frame[6] = payload.length >>> 16 & 255;
  frame[7] = payload.length >>> 8 & 255;
  frame[8] = payload.length & 255;
  frame.set(payload, FRAME_HEADER_SIZE);
  return frame;
}
function encodeJSONFrame(json) {
  return encodeFrame(FrameType.JSON, 0, textEncoder$1.encode(json));
}
function encodeChunkFrame(streamId, chunk) {
  return encodeFrame(FrameType.CHUNK, streamId, chunk);
}
function encodeEndFrame(streamId) {
  return encodeFrame(FrameType.END, streamId, EMPTY_PAYLOAD);
}
function encodeErrorFrame(streamId, error) {
  const message = error instanceof Error ? error.message : String(error ?? "Unknown error");
  return encodeFrame(FrameType.ERROR, streamId, textEncoder$1.encode(message));
}
function createMultiplexedStream(jsonStream, rawStreams) {
  let activePumps = 1 + rawStreams.size;
  let controllerRef = null;
  let cancelled = false;
  const cancelReaders = [];
  const safeEnqueue = (chunk) => {
    if (cancelled || !controllerRef) return;
    try {
      controllerRef.enqueue(chunk);
    } catch {
    }
  };
  const safeError = (err) => {
    if (cancelled || !controllerRef) return;
    try {
      controllerRef.error(err);
    } catch {
    }
  };
  const safeClose = () => {
    if (cancelled || !controllerRef) return;
    try {
      controllerRef.close();
    } catch {
    }
  };
  const checkComplete = () => {
    activePumps--;
    if (activePumps === 0) {
      safeClose();
    }
  };
  return new ReadableStream({
    start(controller) {
      controllerRef = controller;
      cancelReaders.length = 0;
      const pumpJSON = async () => {
        const reader = jsonStream.getReader();
        cancelReaders.push(() => {
          reader.cancel().catch(() => {
          });
        });
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (cancelled) break;
            if (done) break;
            safeEnqueue(encodeJSONFrame(value));
          }
        } catch (error) {
          safeError(error);
        } finally {
          reader.releaseLock();
          checkComplete();
        }
      };
      const pumpRawStream = async (streamId, stream) => {
        const reader = stream.getReader();
        cancelReaders.push(() => {
          reader.cancel().catch(() => {
          });
        });
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (cancelled) break;
            if (done) {
              safeEnqueue(encodeEndFrame(streamId));
              break;
            }
            safeEnqueue(encodeChunkFrame(streamId, value));
          }
        } catch (error) {
          safeEnqueue(encodeErrorFrame(streamId, error));
        } finally {
          reader.releaseLock();
          checkComplete();
        }
      };
      pumpJSON();
      for (const [streamId, stream] of rawStreams) {
        pumpRawStream(streamId, stream);
      }
    },
    cancel() {
      cancelled = true;
      controllerRef = null;
      for (const cancelReader of cancelReaders) {
        cancelReader();
      }
      cancelReaders.length = 0;
    }
  });
}
const manifest = { "89d0eac46cf2a30cbefcdf12bb8e1589afb4c47fe34188957786a61fb4d0e772": {
  functionName: "listCoursesAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "2d91f84c7988949e1a65bf760d8d1d390a00d22b37c6d97619e3634ec398e6de": {
  functionName: "createCourseAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "b6bd1bbb785f2cf30fec61de7100948c6d4a937f50a3f790801f8a2d13957915": {
  functionName: "updateCourseAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "9f8deeee7f16bc119fb2f3707ecfc4cd38916b864aff013e6e5e9450fbebaade": {
  functionName: "assignInstructorAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "41b7c5098198af2a6b787a7080cbb18c5575f37dda4f846e3d8484cdef61a68c": {
  functionName: "removeInstructorAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "6d4db7a6f0e17194c8160ba6d1d3f3d5cf5e1d691d8813f10a86f2e9e03613e4": {
  functionName: "archiveCourseAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "791591abb8f80b9b64c72cff0785b1fa2d92ea7d40b7ebbe8a3af1a65b99c2fe": {
  functionName: "getCourseDetailAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "3935a70ea8d99a1fa3ff30072b2ce5527569aae6f2495750944fd04685201fb3": {
  functionName: "getInstructorCoursesAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "1b0dbefaa552c4d1b08293494fd27ca0d49ec3c7e0d5ad57fb1ad886bea4f5a8": {
  functionName: "getInstructorCourseDetailAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "e6e42c858ab32014e131535b48a33a6ec98e42edcf1d6ec932e68fe2b08ee400": {
  functionName: "getCourseCatalogAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "2ad86fda792ecbf3746de0cfafeb88b95b4cdf238c34c6101110d54c953c28eb": {
  functionName: "listSemestersAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "953e31a563fd7cde17d3b4ef3f36b85ddbff8a70595ce02610470cc666ba9dc8": {
  functionName: "getSemesterDetailAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "584b6aa9638085acb6fbcaff9b964237c4777b6cbe2d4b70ac329e9972b92f23": {
  functionName: "createSemesterAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "2a93a65798c00954ca1e2744b9899351b5a1ba5e496c457079ad4a75ef6a7004": {
  functionName: "updateSemesterAction_createServerFn_handler",
  importer: () => import("./course.actions-C4xuUDdW.mjs")
}, "b7696922eb2a9b4b534965e82b8dbc591fb7480c15a4911ce8c8f8eb6ec6d84d": {
  functionName: "listUsersAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "e6165ffadd665440f233c6dcdabad7ee5acec2dddf768cad9cbd3263669f5f31": {
  functionName: "getUserDetailAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "3051a517b703384fb169c2458f9993be9e13aeef758c48f794f23cc3e01ee64b": {
  functionName: "createUserAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "3a59b41934309245ebe39c5ffc725bce70819d69088f9c7c32959f9b958a2f93": {
  functionName: "updateUserAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "d8fd2a3b13c2cd23962fa7e7d22eaab6db1db56576ea23ad049142f16c69c5c3": {
  functionName: "deactivateUserAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "6f44cebbfa92944baa2c11f0a67a9a9c62430b1ff9353369b7ad7ce54f12e3af": {
  functionName: "updateProfileAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "ff0b6c6a19031f0571921308251dc45447ba423cb1dc67f2e04eabd66b402550": {
  functionName: "listInstructorsAction_createServerFn_handler",
  importer: () => import("./user.actions-B0XEDKpF.mjs")
}, "3371e9152efa504ad80eb9dab602b7aa7a1b3e29a8d33eb7d02a3331db1793b0": {
  functionName: "getSession_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "1fc2b78f24004bcf959a71aecd98be95da1b6d6d790a26b949d3b8359eb7a853": {
  functionName: "loginAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "43a6492e0a1ad82b31d169e5e21da6e021a02ca51658015613954b019149e30a": {
  functionName: "registerAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "b134a94da9cdf8cd1d7c10e3a4739f3b43ba00b07adf2add0751d75e023d30fe": {
  functionName: "logoutAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "862731301a0699f12cd7566d1f4d830f2a3e8d7db7c8ca0a2c55f0ab6342c10c": {
  functionName: "changePasswordAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "769ec723d51f50224802d9b6e2cae3f9c35c4be43e1c5469d351775506cc171a": {
  functionName: "forgotPasswordAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "a2cb7ff49417ae30d2288557ef32e09d44d6d88079bb99c2dbc8ca9f5e099f3e": {
  functionName: "resetPasswordAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "f6796a5d69fa587fd6c14e8dfa344ef6f3bb2e74f31f283d9405ce2a6fba369f": {
  functionName: "resendVerificationEmailAction_createServerFn_handler",
  importer: () => import("./auth.actions-rIi0L66L.mjs")
}, "b28c5a3ebc7c9e496a37f2a62e6012faf1afe8d1767c0cf4b29dfab21fc10c70": {
  functionName: "getCourseGradingDataAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "c68c971d8fcc272b6656f1fbbf9c3fbc3ceb181d3a2aa6d04c04b25a631e9953": {
  functionName: "saveCourseAssessmentsAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "21825f7f80042905195ed1bb495d9e99efa35ecdb7007b5708e6bbe3ae59f3ea": {
  functionName: "saveAssessmentScoresAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "bf6397dbe815c826e566b801c62b3a94d1fc23f43ea938195e22a37ccf113758": {
  functionName: "submitGradeAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "21a1038707fb64906b3a6492dc2bf5667f816e1c96007ae1a1da13da315596e8": {
  functionName: "updateGradeAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "2705d8a5439a8e8f3e28eed689a67a4db9ace9333cdf0671a9c1d5327d06ba99": {
  functionName: "getCourseGradesAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "d65d611ed28452d83db16c898e9257d6c08376a12cfa0678fbf896d474b3f986": {
  functionName: "getInstructorStudentsAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "270693b94f64ace4ee2d5a973c0d6d31ad358e74d9d07045324b756196a2aa59": {
  functionName: "getTranscriptAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "0cf4315e6281c9e10980f98ce9f055acb8ac51b0affaa4f5443f983d7b4b8e80": {
  functionName: "getStudentTranscriptAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "0c3d12901aa4cecc3831709234039c4298b00e0c4de75957090cb22865074e1f": {
  functionName: "bulkSubmitGradesAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "86378e06d26d8880920ab7690beeb3ed37ce09f334a7df1a8a8914b22ea57c53": {
  functionName: "getGpaSummaryAction_createServerFn_handler",
  importer: () => import("./grade.actions-DvyWcNrz.mjs")
}, "4241717dddff692f1c510a57e93446024b3c329ccb1e4cd74bd885fd88d66ff2": {
  functionName: "getAdminDashboardAction_createServerFn_handler",
  importer: () => import("./dashboard.actions-Dm7nQb8a.mjs")
}, "311a0dae574090455fbdae778e0c39ef68b72fbc26582dbd2770b92d5c186c4d": {
  functionName: "getStudentDashboardAction_createServerFn_handler",
  importer: () => import("./dashboard.actions-Dm7nQb8a.mjs")
}, "a585870de6c2c99093caff11d5d17265418b24f6448596f0234a961ad425a889": {
  functionName: "getInstructorDashboardAction_createServerFn_handler",
  importer: () => import("./dashboard.actions-Dm7nQb8a.mjs")
}, "cd24a0e03c85684621d7bd04bc76038683585685ff88cb6b8d43cd978f052788": {
  functionName: "enrollAction_createServerFn_handler",
  importer: () => import("./enrollment.actions-B0i4pATI.mjs")
}, "31056efa21668ce31615531eb3d83fb427bf95dfa2c445b79413bf0e95a8e715": {
  functionName: "dropAction_createServerFn_handler",
  importer: () => import("./enrollment.actions-B0i4pATI.mjs")
}, "c93562cbf035e3663ab758a7d4563f23de1f488d0a39227a10a50f48881f3266": {
  functionName: "leaveWaitlistAction_createServerFn_handler",
  importer: () => import("./enrollment.actions-B0i4pATI.mjs")
}, "7974daa4b3e3b441dd33de5179985efe805d23c565c078507d0892187ca702ba": {
  functionName: "getStudentEnrollmentsAction_createServerFn_handler",
  importer: () => import("./enrollment.actions-B0i4pATI.mjs")
}, "249bfa1ab6b136226c38fdf4e80f010a28cc820824051c432777e2b52f44749b": {
  functionName: "getNotificationsAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "22a533bbc9f89ec4423b30bf94853b23d130253cb0d703cb00f979498fe5686e": {
  functionName: "getUnreadCountAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "c8a8d82718fdc162048ff23eca5b3771448bda863a57c4b9ebe6a9a62ead8d23": {
  functionName: "markNotificationReadAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "8c2420d1dec316c78f5b7f42e6660db9222e2f718145a4ca64f0e5d409680d13": {
  functionName: "markAllNotificationsReadAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "84b6b9a3459f859c6178b53d901f0cbb55d6d26544b3581a0e418680069e9683": {
  functionName: "listAnnouncementsAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "b696228bce9cb00f685fc5b8084c0ef3e644dc737eaf36b0b70a2abd472285cf": {
  functionName: "listAllAnnouncementsAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "80a05c721ed82ea6f61419cbae9f2ff31f86f2643d1291e5c5b2376966c97695": {
  functionName: "createAnnouncementAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "0ad2230b2868467795caa203427b0e72e336df891d4aceef0a05ddbc2116edf7": {
  functionName: "updateAnnouncementAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "c6287c9304ca945f185d6efa26127a07020faea4a3712915fc5dc441d27f6e0c": {
  functionName: "deleteAnnouncementAction_createServerFn_handler",
  importer: () => import("./notification.actions-B8zObXza.mjs")
}, "d6e6583fcf51ef9f009b45f504c53c7e4fdef7db96ca75b5a5357197719bb165": {
  functionName: "listPrerequisitesAction_createServerFn_handler",
  importer: () => import("./prerequisite.actions-DMANYETV.mjs")
}, "bbf0f5869f50e6e558ed92c1beb5003785691452a4a538307db481cf537fd925": {
  functionName: "getCoursePrerequisitesAction_createServerFn_handler",
  importer: () => import("./prerequisite.actions-DMANYETV.mjs")
}, "17a47d1b958d7c69e487d5a096b75f8d7104dde9c2974a6fa14b8705905977d5": {
  functionName: "addPrerequisiteAction_createServerFn_handler",
  importer: () => import("./prerequisite.actions-DMANYETV.mjs")
}, "5155cf2b656faf6d7b2694bdfe93afbeae8a055afec5d2b2e8c72b6c05e9864e": {
  functionName: "removePrerequisiteAction_createServerFn_handler",
  importer: () => import("./prerequisite.actions-DMANYETV.mjs")
} };
async function getServerFnById(id) {
  const serverFnInfo = manifest[id];
  if (!serverFnInfo) {
    throw new Error("Server function info not found for " + id);
  }
  const fnModule = await serverFnInfo.importer();
  if (!fnModule) {
    console.info("serverFnInfo", serverFnInfo);
    throw new Error("Server function module not resolved for " + id);
  }
  const action = fnModule[serverFnInfo.functionName];
  if (!action) {
    console.info("serverFnInfo", serverFnInfo);
    console.info("fnModule", fnModule);
    throw new Error(
      `Server function module export not resolved for serverFn ID: ${id}`
    );
  }
  return action;
}
let serovalPlugins = void 0;
const textEncoder = new TextEncoder();
const FORM_DATA_CONTENT_TYPES = [
  "multipart/form-data",
  "application/x-www-form-urlencoded"
];
const MAX_PAYLOAD_SIZE = 1e6;
const handleServerAction = async ({
  request,
  context,
  serverFnId
}) => {
  const method = request.method;
  const methodUpper = method.toUpperCase();
  const methodLower = method.toLowerCase();
  const url = new URL(request.url);
  const action = await getServerFnById(serverFnId);
  const isServerFn = request.headers.get("x-tsr-serverFn") === "true";
  if (!serovalPlugins) {
    serovalPlugins = getDefaultSerovalPlugins();
  }
  const contentType = request.headers.get("Content-Type");
  function parsePayload(payload) {
    const parsedPayload = Iu(payload, { plugins: serovalPlugins });
    return parsedPayload;
  }
  const response = await (async () => {
    try {
      let serializeResult = function(res2) {
        let nonStreamingBody = void 0;
        const alsResponse = getResponse();
        if (res2 !== void 0) {
          const rawStreams = /* @__PURE__ */ new Map();
          const rawStreamPlugin = createRawStreamRPCPlugin(
            (id, stream2) => {
              rawStreams.set(id, stream2);
            }
          );
          const plugins = [rawStreamPlugin, ...serovalPlugins || []];
          let done = false;
          const callbacks = {
            onParse: (value) => {
              nonStreamingBody = value;
            },
            onDone: () => {
              done = true;
            },
            onError: (error) => {
              throw error;
            }
          };
          au(res2, {
            refs: /* @__PURE__ */ new Map(),
            plugins,
            onParse(value) {
              callbacks.onParse(value);
            },
            onDone() {
              callbacks.onDone();
            },
            onError: (error) => {
              callbacks.onError(error);
            }
          });
          if (done && rawStreams.size === 0) {
            return new Response(
              nonStreamingBody ? JSON.stringify(nonStreamingBody) : void 0,
              {
                status: alsResponse.status,
                statusText: alsResponse.statusText,
                headers: {
                  "Content-Type": "application/json",
                  [X_TSS_SERIALIZED]: "true"
                }
              }
            );
          }
          if (rawStreams.size > 0) {
            const jsonStream = new ReadableStream({
              start(controller) {
                callbacks.onParse = (value) => {
                  controller.enqueue(JSON.stringify(value) + "\n");
                };
                callbacks.onDone = () => {
                  try {
                    controller.close();
                  } catch {
                  }
                };
                callbacks.onError = (error) => controller.error(error);
                if (nonStreamingBody !== void 0) {
                  callbacks.onParse(nonStreamingBody);
                }
              }
            });
            const multiplexedStream = createMultiplexedStream(
              jsonStream,
              rawStreams
            );
            return new Response(multiplexedStream, {
              status: alsResponse.status,
              statusText: alsResponse.statusText,
              headers: {
                "Content-Type": TSS_CONTENT_TYPE_FRAMED_VERSIONED,
                [X_TSS_SERIALIZED]: "true"
              }
            });
          }
          const stream = new ReadableStream({
            start(controller) {
              callbacks.onParse = (value) => controller.enqueue(
                textEncoder.encode(JSON.stringify(value) + "\n")
              );
              callbacks.onDone = () => {
                try {
                  controller.close();
                } catch (error) {
                  controller.error(error);
                }
              };
              callbacks.onError = (error) => controller.error(error);
              if (nonStreamingBody !== void 0) {
                callbacks.onParse(nonStreamingBody);
              }
            }
          });
          return new Response(stream, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": "application/x-ndjson",
              [X_TSS_SERIALIZED]: "true"
            }
          });
        }
        return new Response(void 0, {
          status: alsResponse.status,
          statusText: alsResponse.statusText
        });
      };
      let res = await (async () => {
        if (FORM_DATA_CONTENT_TYPES.some(
          (type) => contentType && contentType.includes(type)
        )) {
          invariant(
            methodLower !== "get",
            "GET requests with FormData payloads are not supported"
          );
          const formData = await request.formData();
          const serializedContext = formData.get(TSS_FORMDATA_CONTEXT);
          formData.delete(TSS_FORMDATA_CONTEXT);
          const params = {
            context,
            data: formData,
            method: methodUpper
          };
          if (typeof serializedContext === "string") {
            try {
              const parsedContext = JSON.parse(serializedContext);
              const deserializedContext = Iu(parsedContext, {
                plugins: serovalPlugins
              });
              if (typeof deserializedContext === "object" && deserializedContext) {
                params.context = safeObjectMerge(
                  context,
                  deserializedContext
                );
              }
            } catch (e) {
              if (false) ;
            }
          }
          return await action(params);
        }
        if (methodLower === "get") {
          const payloadParam = url.searchParams.get("payload");
          if (payloadParam && payloadParam.length > MAX_PAYLOAD_SIZE) {
            throw new Error("Payload too large");
          }
          const payload2 = payloadParam ? parsePayload(JSON.parse(payloadParam)) : {};
          payload2.context = safeObjectMerge(context, payload2.context);
          payload2.method = methodUpper;
          return await action(payload2);
        }
        if (methodLower !== "post") {
          throw new Error("expected POST method");
        }
        let jsonPayload;
        if (contentType?.includes("application/json")) {
          jsonPayload = await request.json();
        }
        const payload = jsonPayload ? parsePayload(jsonPayload) : {};
        payload.context = safeObjectMerge(payload.context, context);
        payload.method = methodUpper;
        return await action(payload);
      })();
      const unwrapped = res.result || res.error;
      if (isNotFound(res)) {
        res = isNotFoundResponse(res);
      }
      if (!isServerFn) {
        return unwrapped;
      }
      if (unwrapped instanceof Response) {
        if (isRedirect(unwrapped)) {
          return unwrapped;
        }
        unwrapped.headers.set(X_TSS_RAW_RESPONSE, "true");
        return unwrapped;
      }
      return serializeResult(res);
    } catch (error) {
      if (error instanceof Response) {
        return error;
      }
      if (isNotFound(error)) {
        return isNotFoundResponse(error);
      }
      console.info();
      console.info("Server Fn Error!");
      console.info();
      console.error(error);
      console.info();
      const serializedError = JSON.stringify(
        await Promise.resolve(
          ou(error, {
            refs: /* @__PURE__ */ new Map(),
            plugins: serovalPlugins
          })
        )
      );
      const response2 = getResponse();
      return new Response(serializedError, {
        status: response2.status ?? 500,
        statusText: response2.statusText,
        headers: {
          "Content-Type": "application/json",
          [X_TSS_SERIALIZED]: "true"
        }
      });
    }
  })();
  return response;
};
function isNotFoundResponse(error) {
  const { headers, ...rest } = error;
  return new Response(JSON.stringify(rest), {
    status: 404,
    headers: {
      "Content-Type": "application/json",
      ...headers || {}
    }
  });
}
const HEADERS = {
  TSS_SHELL: "X-TSS_SHELL"
};
const ServerFunctionSerializationAdapter = createSerializationAdapter({
  key: "$TSS/serverfn",
  test: (v) => {
    if (typeof v !== "function") return false;
    if (!(TSS_SERVER_FUNCTION in v)) return false;
    return !!v[TSS_SERVER_FUNCTION];
  },
  toSerializable: ({ serverFnMeta }) => ({ functionId: serverFnMeta.id }),
  fromSerializable: ({ functionId }) => {
    const fn = async (opts, signal) => {
      const serverFn = await getServerFnById(functionId);
      const result = await serverFn(opts ?? {}, signal);
      return result.result;
    };
    return fn;
  }
});
function getStartResponseHeaders(opts) {
  const headers = mergeHeaders(
    {
      "Content-Type": "text/html; charset=utf-8"
    },
    ...opts.router.state.matches.map((match) => {
      return match.headers;
    })
  );
  return headers;
}
let entriesPromise;
let manifestPromise;
async function loadEntries() {
  const routerEntry = await import("./router-DhCkpF2X.mjs").then((n) => n.ao);
  const startEntry = await import("./start-HYkvq4Ni.mjs");
  return { startEntry, routerEntry };
}
function getEntries() {
  if (!entriesPromise) {
    entriesPromise = loadEntries();
  }
  return entriesPromise;
}
function getManifest(matchedRoutes) {
  if (!manifestPromise) {
    manifestPromise = getStartManifest();
  }
  return manifestPromise;
}
const ROUTER_BASEPATH = "/";
const SERVER_FN_BASE = "/_serverFn/";
const IS_PRERENDERING = process.env.TSS_PRERENDERING === "true";
const IS_SHELL_ENV = process.env.TSS_SHELL === "true";
const ERR_NO_RESPONSE = "Internal Server Error";
const ERR_NO_DEFER = "Internal Server Error";
function throwRouteHandlerError() {
  throw new Error(ERR_NO_RESPONSE);
}
function throwIfMayNotDefer() {
  throw new Error(ERR_NO_DEFER);
}
function isSpecialResponse(value) {
  return value instanceof Response || isRedirect(value);
}
function handleCtxResult(result) {
  if (isSpecialResponse(result)) {
    return { response: result };
  }
  return result;
}
function executeMiddleware(middlewares, ctx) {
  let index2 = -1;
  const next = async (nextCtx) => {
    if (nextCtx) {
      if (nextCtx.context) {
        ctx.context = safeObjectMerge(ctx.context, nextCtx.context);
      }
      for (const key of Object.keys(nextCtx)) {
        if (key !== "context") {
          ctx[key] = nextCtx[key];
        }
      }
    }
    index2++;
    const middleware = middlewares[index2];
    if (!middleware) return ctx;
    let result;
    try {
      result = await middleware({ ...ctx, next });
    } catch (err) {
      if (isSpecialResponse(err)) {
        ctx.response = err;
        return ctx;
      }
      throw err;
    }
    const normalized = handleCtxResult(result);
    if (normalized) {
      if (normalized.response !== void 0) {
        ctx.response = normalized.response;
      }
      if (normalized.context) {
        ctx.context = safeObjectMerge(ctx.context, normalized.context);
      }
    }
    return ctx;
  };
  return next();
}
function handlerToMiddleware(handler, mayDefer = false) {
  if (mayDefer) {
    return handler;
  }
  return async (ctx) => {
    const response = await handler({ ...ctx, next: throwIfMayNotDefer });
    if (!response) {
      throwRouteHandlerError();
    }
    return response;
  };
}
function createStartHandler(cb) {
  const startRequestResolver = async (request, requestOpts) => {
    let router = null;
    let cbWillCleanup = false;
    try {
      const url = getNormalizedURL(request.url);
      const href = url.pathname + url.search + url.hash;
      const origin = getOrigin(request);
      const entries = await getEntries();
      const startOptions = await entries.startEntry.startInstance?.getOptions() || {};
      const serializationAdapters = [
        ...startOptions.serializationAdapters || [],
        ServerFunctionSerializationAdapter
      ];
      const requestStartOptions = {
        ...startOptions,
        serializationAdapters
      };
      const flattenedRequestMiddlewares = startOptions.requestMiddleware ? flattenMiddlewares(startOptions.requestMiddleware) : [];
      const executedRequestMiddlewares = new Set(
        flattenedRequestMiddlewares
      );
      const getRouter = async () => {
        if (router) return router;
        router = await entries.routerEntry.getRouter();
        let isShell = IS_SHELL_ENV;
        if (IS_PRERENDERING && !isShell) {
          isShell = request.headers.get(HEADERS.TSS_SHELL) === "true";
        }
        const history = createMemoryHistory({
          initialEntries: [href]
        });
        router.update({
          history,
          isShell,
          isPrerendering: IS_PRERENDERING,
          origin: router.options.origin ?? origin,
          ...{
            defaultSsr: requestStartOptions.defaultSsr,
            serializationAdapters: [
              ...requestStartOptions.serializationAdapters,
              ...router.options.serializationAdapters || []
            ]
          },
          basepath: ROUTER_BASEPATH
        });
        return router;
      };
      if (SERVER_FN_BASE && url.pathname.startsWith(SERVER_FN_BASE)) {
        const serverFnId = url.pathname.slice(SERVER_FN_BASE.length).split("/")[0];
        if (!serverFnId) {
          throw new Error("Invalid server action param for serverFnId");
        }
        const serverFnHandler = async ({ context }) => {
          return runWithStartContext(
            {
              getRouter,
              startOptions: requestStartOptions,
              contextAfterGlobalMiddlewares: context,
              request,
              executedRequestMiddlewares
            },
            () => handleServerAction({
              request,
              context: requestOpts?.context,
              serverFnId
            })
          );
        };
        const middlewares2 = flattenedRequestMiddlewares.map(
          (d) => d.options.server
        );
        const ctx2 = await executeMiddleware([...middlewares2, serverFnHandler], {
          request,
          context: createNullProtoObject(requestOpts?.context)
        });
        return handleRedirectResponse(ctx2.response, request, getRouter);
      }
      const executeRouter = async (serverContext, matchedRoutes) => {
        const acceptHeader = request.headers.get("Accept") || "*/*";
        const acceptParts = acceptHeader.split(",");
        const supportedMimeTypes = ["*/*", "text/html"];
        const isSupported = supportedMimeTypes.some(
          (mimeType) => acceptParts.some((part) => part.trim().startsWith(mimeType))
        );
        if (!isSupported) {
          return Response.json(
            { error: "Only HTML requests are supported here" },
            { status: 500 }
          );
        }
        const manifest2 = await getManifest(matchedRoutes);
        const routerInstance = await getRouter();
        attachRouterServerSsrUtils({
          router: routerInstance,
          manifest: manifest2
        });
        routerInstance.update({ additionalContext: { serverContext } });
        await routerInstance.load();
        if (routerInstance.state.redirect) {
          return routerInstance.state.redirect;
        }
        await routerInstance.serverSsr.dehydrate();
        const responseHeaders = getStartResponseHeaders({
          router: routerInstance
        });
        cbWillCleanup = true;
        return cb({
          request,
          router: routerInstance,
          responseHeaders
        });
      };
      const requestHandlerMiddleware = async ({ context }) => {
        return runWithStartContext(
          {
            getRouter,
            startOptions: requestStartOptions,
            contextAfterGlobalMiddlewares: context,
            request,
            executedRequestMiddlewares
          },
          async () => {
            try {
              return await handleServerRoutes({
                getRouter,
                request,
                url,
                executeRouter,
                context,
                executedRequestMiddlewares
              });
            } catch (err) {
              if (err instanceof Response) {
                return err;
              }
              throw err;
            }
          }
        );
      };
      const middlewares = flattenedRequestMiddlewares.map(
        (d) => d.options.server
      );
      const ctx = await executeMiddleware(
        [...middlewares, requestHandlerMiddleware],
        { request, context: createNullProtoObject(requestOpts?.context) }
      );
      return handleRedirectResponse(ctx.response, request, getRouter);
    } finally {
      if (router && !cbWillCleanup) {
        router.serverSsr?.cleanup();
      }
      router = null;
    }
  };
  return requestHandler(startRequestResolver);
}
async function handleRedirectResponse(response, request, getRouter) {
  if (!isRedirect(response)) {
    return response;
  }
  if (isResolvedRedirect(response)) {
    if (request.headers.get("x-tsr-serverFn") === "true") {
      return Response.json(
        { ...response.options, isSerializedRedirect: true },
        { headers: response.headers }
      );
    }
    return response;
  }
  const opts = response.options;
  if (opts.to && typeof opts.to === "string" && !opts.to.startsWith("/")) {
    throw new Error(
      `Server side redirects must use absolute paths via the 'href' or 'to' options. The redirect() method's "to" property accepts an internal path only. Use the "href" property to provide an external URL. Received: ${JSON.stringify(opts)}`
    );
  }
  if (["params", "search", "hash"].some(
    (d) => typeof opts[d] === "function"
  )) {
    throw new Error(
      `Server side redirects must use static search, params, and hash values and do not support functional values. Received functional values for: ${Object.keys(
        opts
      ).filter((d) => typeof opts[d] === "function").map((d) => `"${d}"`).join(", ")}`
    );
  }
  const router = await getRouter();
  const redirect = router.resolveRedirect(response);
  if (request.headers.get("x-tsr-serverFn") === "true") {
    return Response.json(
      { ...response.options, isSerializedRedirect: true },
      { headers: response.headers }
    );
  }
  return redirect;
}
async function handleServerRoutes({
  getRouter,
  request,
  url,
  executeRouter,
  context,
  executedRequestMiddlewares
}) {
  const router = await getRouter();
  const rewrittenUrl = executeRewriteInput(router.rewrite, url);
  const pathname = rewrittenUrl.pathname;
  const { matchedRoutes, foundRoute, routeParams } = router.getMatchedRoutes(pathname);
  const isExactMatch = foundRoute && routeParams["**"] === void 0;
  const routeMiddlewares = [];
  for (const route of matchedRoutes) {
    const serverMiddleware = route.options.server?.middleware;
    if (serverMiddleware) {
      const flattened = flattenMiddlewares(serverMiddleware);
      for (const m of flattened) {
        if (!executedRequestMiddlewares.has(m)) {
          routeMiddlewares.push(m.options.server);
        }
      }
    }
  }
  const server2 = foundRoute?.options.server;
  if (server2?.handlers && isExactMatch) {
    const handlers = typeof server2.handlers === "function" ? server2.handlers({ createHandlers: (d) => d }) : server2.handlers;
    const requestMethod = request.method.toUpperCase();
    const handler = handlers[requestMethod] ?? handlers["ANY"];
    if (handler) {
      const mayDefer = !!foundRoute.options.component;
      if (typeof handler === "function") {
        routeMiddlewares.push(handlerToMiddleware(handler, mayDefer));
      } else {
        if (handler.middleware?.length) {
          const handlerMiddlewares = flattenMiddlewares(handler.middleware);
          for (const m of handlerMiddlewares) {
            routeMiddlewares.push(m.options.server);
          }
        }
        if (handler.handler) {
          routeMiddlewares.push(handlerToMiddleware(handler.handler, mayDefer));
        }
      }
    }
  }
  routeMiddlewares.push(
    (ctx2) => executeRouter(ctx2.context, matchedRoutes)
  );
  const ctx = await executeMiddleware(routeMiddlewares, {
    request,
    context,
    params: routeParams,
    pathname
  });
  return ctx.response;
}
const fetch = createStartHandler(defaultStreamHandler);
function createServerEntry(entry) {
  return {
    async fetch(...args) {
      return await entry.fetch(...args);
    }
  };
}
const server = createServerEntry({ fetch });
const index = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  H: HEADERS,
  S: StartServer,
  T: TSS_SERVER_FUNCTION,
  a: getResponse,
  b: createServerFn,
  c: createStartHandler,
  createServerEntry,
  d: defaultStreamHandler,
  default: server,
  e: getServerFnById,
  g: getRequestHeaders,
  r: requestHandler,
  s: setCookie
});
const serverBubZoQFo = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  HEADERS,
  StartServer,
  attachRouterServerSsrUtils,
  createStartHandler,
  defaultStreamHandler,
  defineHandlerCallback,
  getRequestHeaders,
  getResponse,
  requestHandler,
  setCookie,
  transformPipeableStreamWithRouter,
  transformReadableStreamWithRouter
});
export {
  TSS_SERVER_FUNCTION as T,
  getServerFnById as a,
  createServerFn as c,
  getRequestHeaders as g,
  index as i,
  serverBubZoQFo as s
};
