import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { q as Route$m, B as Button, s as getCourseCatalogAction, t as enrollAction } from "./router-DhCkpF2X.mjs";
import { I as Input } from "./input-9b2Tum0N.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { C as Card, a as CardHeader, b as CardTitle, c as CardDescription, e as CardContent, d as CardFooter } from "./card-QCkASOp1.mjs";
import { A as AlertDialog, a as AlertDialogContent, b as AlertDialogHeader, c as AlertDialogTitle, d as AlertDialogDescription, e as AlertDialogFooter, f as AlertDialogCancel, g as AlertDialogAction } from "./alert-dialog-DTkhQAha.mjs";
import { E as EmptyState } from "./empty-state-D-g1-il0.mjs";
import { v as Search, B as BookOpen, N as CircleCheckBig, O as Clock, V as UserPlus } from "../_libs/lucide-react.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_libs/isbot.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "../_libs/zod.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./course.schema-DAXkVW6U.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "./constants-DoiYt0dc.mjs";
import "../_chunks/_libs/@radix-ui/react-alert-dialog.mjs";
import "../_chunks/_libs/@radix-ui/react-dialog.mjs";
function StudentCourseCatalog() {
  const {
    courses: initialCourses
  } = Route$m.useLoaderData();
  const {
    user
  } = Route$m.useRouteContext();
  const [courses, setCourses] = reactExports.useState(initialCourses);
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [enrollingCourseId, setEnrollingCourseId] = reactExports.useState(null);
  const [confirmCourse, setConfirmCourse] = reactExports.useState(null);
  const handleSearch = async () => {
    const data = await getCourseCatalogAction({
      data: {
        search: searchQuery || void 0
      }
    });
    setCourses(data);
  };
  const handleEnroll = async (courseId) => {
    setEnrollingCourseId(courseId);
    try {
      const result = await enrollAction({
        data: {
          courseId
        }
      });
      if (result.success) {
        if (result.data.status === "waitlisted") {
          toast.success(`Added to waitlist! Position: #${result.data.waitlistPosition}`);
        } else {
          toast.success("Successfully enrolled!");
        }
        setConfirmCourse(null);
        const data = await getCourseCatalogAction({
          data: {
            search: searchQuery || void 0
          }
        });
        setCourses(data);
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to enroll");
    } finally {
      setEnrollingCourseId(null);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Student",
      href: "/student"
    }, {
      label: "Course Catalog"
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: "Course Catalog" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mt-1", children: "Browse and enroll in available courses." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 max-w-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Search courses...", className: "pl-10", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value), onKeyDown: (e) => e.key === "Enter" && handleSearch() })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: handleSearch, children: "Search" })
      ] }),
      courses.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: BookOpen, title: "No courses available", description: "There are no courses available for enrollment in the current semester." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 grid-cols-1 min-w-0 md:grid-cols-2 lg:grid-cols-3", children: courses.map((course) => {
        const isFull = course.enrolledCount >= course.capacity;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "font-mono", children: course.code }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: isFull ? "destructive" : "success", children: [
                course.enrolledCount,
                "/",
                course.capacity
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-lg mt-2", children: course.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardDescription, { children: [
              course.credits,
              " credits | ",
              course.semesterName
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "flex-1", children: [
            course.description && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mb-3", children: course.description }),
            course.instructors.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Instructor: " }),
              course.instructors.map((i) => `${i.firstName} ${i.lastName}`).join(", ")
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardFooter, { children: course.isEnrolled ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "w-full", variant: "secondary", disabled: true, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "h-4 w-4 mr-2" }),
            "Enrolled"
          ] }) : course.isWaitlisted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "w-full", variant: "outline", disabled: true, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4 mr-2" }),
            "Waitlisted #",
            course.waitlistPosition
          ] }) : isFull ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "w-full", variant: "outline", onClick: () => setConfirmCourse(course), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4 mr-2" }),
            "Join Waitlist",
            (course.waitlistCount ?? 0) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "ml-1 text-xs", children: [
              "(",
              course.waitlistCount,
              " waiting)"
            ] })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "w-full", onClick: () => setConfirmCourse(course), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 mr-2" }),
            "Enroll"
          ] }) })
        ] }, course.id);
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialog, { open: !!confirmCourse, onOpenChange: (open) => !open && setConfirmCourse(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogTitle, { children: confirmCourse && confirmCourse.enrolledCount >= confirmCourse.capacity ? "Join Waitlist" : "Confirm Enrollment" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogDescription, { children: confirmCourse && confirmCourse.enrolledCount >= confirmCourse.capacity ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
            confirmCourse?.code,
            " - ",
            confirmCourse?.name
          ] }),
          " is currently full. You will be added to the waitlist and automatically enrolled when a spot opens up."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Are you sure you want to enroll in ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
            confirmCourse?.code,
            " - ",
            confirmCourse?.name
          ] }),
          "? This will add ",
          confirmCourse?.credits,
          " credits."
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogCancel, { children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogAction, { onClick: () => confirmCourse && handleEnroll(confirmCourse.id), disabled: enrollingCourseId !== null, children: enrollingCourseId ? "Processing..." : confirmCourse && confirmCourse.enrolledCount >= confirmCourse.capacity ? "Join Waitlist" : "Confirm" })
      ] })
    ] }) })
  ] });
}
export {
  StudentCourseCatalog as component
};
