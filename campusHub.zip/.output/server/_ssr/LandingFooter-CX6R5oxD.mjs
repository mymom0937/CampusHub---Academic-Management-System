import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { u as useNavigate, L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { B as Button, Z as logoutAction } from "./router-DhCkpF2X.mjs";
import { M as ModeToggle } from "./ModeToggle-l3F05cxw.mjs";
import { A as AppFooter } from "./AppFooter-D0WDOsDC.mjs";
import { G as GraduationCap, L as LayoutDashboard, k as LogOut, X, l as Menu } from "../_libs/lucide-react.mjs";
const navLinks = [
  { to: "/", label: "Home" },
  { to: "/", hash: "about", label: "About" },
  { to: "/", hash: "academics", label: "Academics" },
  { to: "/", hash: "campus", label: "Campus Life" },
  { to: "/news", label: "News" },
  { to: "/", hash: "contact", label: "Contact" }
];
function LandingNavbar({ user, dashboardPath }) {
  const [mobileMenuOpen, setMobileMenuOpen] = reactExports.useState(false);
  const [loggingOut, setLoggingOut] = reactExports.useState(false);
  const navigate = useNavigate();
  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await logoutAction();
      navigate({ to: "/login" });
      setMobileMenuOpen(false);
    } finally {
      setLoggingOut(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto flex h-16 items-center justify-between px-4 md:px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-8 w-8 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "hidden sm:block", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-lg", children: "CampusHub" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-[10px] text-muted-foreground -mt-0.5", children: "Academic Management" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-lg sm:hidden", children: "CampusHub" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "flex items-center gap-1 max-md:hidden font-nav", children: navLinks.map(
        (link) => link.hash ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: link.to,
            hash: link.hash,
            className: "px-3 py-2 text-base font-medium text-muted-foreground hover:text-foreground transition-colors rounded-md",
            children: link.label
          },
          link.label
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: link.to,
            className: "px-3 py-2 text-base font-medium text-muted-foreground hover:text-foreground transition-colors rounded-md",
            children: link.label
          },
          link.label
        )
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 max-md:hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ModeToggle, {}),
        user && dashboardPath ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, className: "gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: dashboardPath, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-4 w-4" }),
            "Portal"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "outline",
              className: "gap-2",
              onClick: handleLogout,
              disabled: loggingOut,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
                loggingOut ? "Signing out…" : "Log Out"
              ]
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/login", children: "Sign In" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/register", children: "Get Started" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 md:hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ModeToggle, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "ghost",
            size: "icon",
            onClick: () => setMobileMenuOpen(!mobileMenuOpen),
            children: mobileMenuOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-5 w-5" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" })
          }
        )
      ] })
    ] }),
    mobileMenuOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:hidden border-t bg-background px-4 pb-4 pt-2 space-y-2 font-nav", children: [
      navLinks.map(
        (link) => link.hash ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: link.to,
            hash: link.hash,
            onClick: () => setMobileMenuOpen(false),
            className: "block px-3 py-2 text-base font-medium text-muted-foreground hover:text-foreground rounded-md",
            children: link.label
          },
          link.label
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: link.to,
            onClick: () => setMobileMenuOpen(false),
            className: "block px-3 py-2 text-base font-medium text-muted-foreground hover:text-foreground rounded-md",
            children: link.label
          },
          link.label
        )
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col gap-2 pt-2 border-t", children: user && dashboardPath ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "w-full gap-2", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: dashboardPath, onClick: () => setMobileMenuOpen(false), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-4 w-4" }),
          "Portal"
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "outline",
            className: "w-full gap-2",
            onClick: handleLogout,
            disabled: loggingOut,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "h-4 w-4" }),
              loggingOut ? "Signing out…" : "Log Out"
            ]
          }
        )
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", className: "flex-1", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/login", children: "Sign In" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "flex-1", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/register", children: "Get Started" }) })
      ] }) })
    ] })
  ] });
}
function LandingFooter() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AppFooter, {});
}
export {
  LandingNavbar as L,
  LandingFooter as a
};
