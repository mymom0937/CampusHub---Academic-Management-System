import { o as object, s as string, g as number, c as boolean, h as date } from "../_libs/zod.mjs";
const createCourseSchema = object({
  code: string().min(1, "Course code is required").max(20, "Course code too long").transform((v) => v.toUpperCase().trim()),
  name: string().min(1, "Course name is required").max(200, "Course name too long").transform((v) => v.trim()),
  description: string().max(1e3).nullable().optional(),
  credits: number().int().min(1, "Credits must be at least 1").max(6, "Credits cannot exceed 6"),
  capacity: number().int().min(1, "Capacity must be at least 1").max(500, "Capacity cannot exceed 500"),
  semesterId: string().min(1, "Semester is required")
});
const updateCourseSchema = object({
  id: string().min(1),
  name: string().min(1).max(200).transform((v) => v.trim()).optional(),
  description: string().max(1e3).nullable().optional(),
  credits: number().int().min(1).max(6).optional(),
  capacity: number().int().min(1).max(500).optional()
});
const assignInstructorSchema = object({
  courseId: string().min(1, "Course is required"),
  instructorId: string().min(1, "Instructor is required"),
  isPrimary: boolean().default(true)
});
object({
  courseId: string().min(1),
  instructorId: string().min(1)
});
const createSemesterSchema = object({
  name: string().min(1, "Semester name is required").max(50).transform((v) => v.trim()),
  code: string().min(1, "Semester code is required").max(20).transform((v) => v.toUpperCase().trim()),
  startDate: date(),
  endDate: date(),
  enrollmentStart: date(),
  enrollmentEnd: date(),
  dropDeadline: date(),
  isActive: boolean().default(false)
}).refine((data) => data.endDate > data.startDate, {
  message: "End date must be after start date",
  path: ["endDate"]
}).refine((data) => data.enrollmentEnd > data.enrollmentStart, {
  message: "Enrollment end must be after enrollment start",
  path: ["enrollmentEnd"]
});
const updateSemesterSchema = object({
  id: string().min(1),
  name: string().min(1).max(50).transform((v) => v.trim()).optional(),
  startDate: date().optional(),
  endDate: date().optional(),
  enrollmentStart: date().optional(),
  enrollmentEnd: date().optional(),
  dropDeadline: date().optional(),
  isActive: boolean().optional()
});
const courseListFiltersSchema = object({
  page: number().int().positive().default(1),
  pageSize: number().int().positive().max(100).default(10),
  search: string().optional(),
  semesterId: string().optional()
});
export {
  createCourseSchema as a,
  assignInstructorSchema as b,
  courseListFiltersSchema as c,
  createSemesterSchema as d,
  updateSemesterSchema as e,
  updateCourseSchema as u
};
