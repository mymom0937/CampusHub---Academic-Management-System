import { j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { k as Route$p, B as Button } from "./router-DhCkpF2X.mjs";
import { C as Card, e as CardContent, a as CardHeader, b as CardTitle } from "./card-QCkASOp1.mjs";
import { S as Separator } from "./separator-BT66itnq.mjs";
import { E as EmptyState } from "./empty-state-D-g1-il0.mjs";
import { b as GRADE_LABELS } from "./constants-DoiYt0dc.mjs";
import { P as Printer, Q as Download, o as FileText } from "../_libs/lucide-react.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/isbot.mjs";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "../_libs/zod.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./course.schema-DAXkVW6U.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
import "../_chunks/_libs/@radix-ui/react-separator.mjs";
function StudentTranscriptPage() {
  const {
    transcript
  } = Route$p.useLoaderData();
  const {
    user
  } = Route$p.useRouteContext();
  const {
    entries,
    summary
  } = transcript;
  const handleDownloadPdf = async () => {
    try {
      const {
        generateTranscriptPdf
      } = await import("./generate-transcript-pdf-C6jFWBxb.mjs");
      generateTranscriptPdf({
        user,
        entries,
        summary
      });
      toast.success("Transcript PDF downloaded!");
    } catch {
      toast.error("Failed to generate PDF. Please try again.");
    }
  };
  const handlePrint = () => window.print();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Student",
      href: "/student"
    }, {
      label: "Transcript"
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: "Academic Transcript" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mt-1", children: "Your official academic record." })
        ] }),
        entries.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handlePrint, variant: "outline", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Printer, { className: "h-4 w-4 mr-2" }),
            "Print"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handleDownloadPdf, variant: "outline", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4 mr-2" }),
            "Export PDF"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "pt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 min-w-0 md:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Student Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium", children: [
            user.firstName,
            " ",
            user.lastName
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: user.email })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Cumulative GPA" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-lg", children: summary.cumulativeGpa !== null ? summary.cumulativeGpa.toFixed(3) : "N/A" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Academic Standing" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: summary.academicStanding === "Dean's List" ? "success" : summary.academicStanding === "Good Standing" ? "secondary" : summary.academicStanding === "Academic Probation" ? "destructive" : "outline", children: summary.academicStanding })
        ] })
      ] }) }) }),
      entries.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: FileText, title: "No transcript data", description: "Your transcript will appear here once you have completed coursework." }) : entries.map((entry) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-lg", children: entry.semesterName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground font-mono", children: entry.semesterCode })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-right", children: entry.semesterGpa !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Semester GPA" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xl font-bold", children: entry.semesterGpa.toFixed(3) })
          ] }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 gap-4 text-xs text-muted-foreground font-medium mb-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Code" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Course Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: "Credit Hr" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-right", children: "Grade · Points" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: entry.courses.map((course) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between py-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-sm font-medium w-20", children: course.courseCode }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: course.courseName })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm text-muted-foreground", children: [
                course.credits,
                " cr"
              ] }),
              course.grade ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "min-w-12 justify-center", children: GRADE_LABELS[course.grade] || course.grade }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "min-w-12 justify-center text-muted-foreground", children: "-" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-muted-foreground w-12 text-right", children: course.gradePoints !== null && course.gradePoints !== void 0 ? course.gradePoints.toFixed(2) : "-" })
            ] })
          ] }, course.courseCode)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "my-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-sm font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Totals: ",
              entry.semesterCredits,
              " cr · ",
              entry.semesterGradePoints.toFixed(2),
              " pts"
            ] }),
            entry.semesterGpa !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Semester GPA: ",
              entry.semesterGpa.toFixed(2)
            ] })
          ] })
        ] })
      ] }, entry.semesterCode)),
      entries.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-muted/30", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-lg", children: "Academic Summary" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: summary.progression ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 gap-4 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground font-medium" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center font-medium", children: "Credit Hrs" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center font-medium", children: "Grade Pts" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center font-medium", children: "GPA" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 gap-4 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Previous Total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.previousTotalCredits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.previousTotalGradePoints.toFixed(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.previousGpa !== null ? summary.progression.previousGpa.toFixed(2) : "N/A" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 gap-4 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Semester Total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.lastSemesterCredits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.lastSemesterGradePoints.toFixed(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.lastSemesterGpa !== null ? summary.progression.lastSemesterGpa.toFixed(2) : "N/A" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-4 gap-4 text-sm font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Cumulative Average" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.cumulativeCredits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.cumulativeGradePoints.toFixed(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.cumulativeGpa !== null ? summary.progression.cumulativeGpa.toFixed(2) : "N/A" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Academic Status: " }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: summary.progression.academicStatus === "Promoted" ? "success" : "destructive", children: summary.progression.academicStatus })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
            "Total Credits: ",
            summary.totalCredits
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Cumulative GPA" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-2xl font-bold", children: summary.cumulativeGpa !== null ? summary.cumulativeGpa.toFixed(3) : "N/A" })
          ] })
        ] }) })
      ] })
    ] })
  ] });
}
export {
  StudentTranscriptPage as component
};
