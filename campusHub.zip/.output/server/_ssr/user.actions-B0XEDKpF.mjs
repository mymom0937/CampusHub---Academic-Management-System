import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { a as adminMiddleware, t as toAppError, b as authMiddleware, A as AppError, h as hashPassword } from "./middleware-DiEMT5y4.mjs";
import { listUsers as listUsers$1, findUserById, findUserByEmail, createUserWithAccount, updateUser as updateUser$1 } from "./user.repository-02e89y02.mjs";
import { u as userListFiltersSchema, c as createUserSchema, a as updateUserSchema, b as updateProfileSchema } from "./user.schema-uS5_1fSq.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
async function createUser(input) {
  const existing = await findUserByEmail(input.email);
  if (existing) {
    throw new AppError("CONFLICT", "A user with this email already exists");
  }
  const user = await createUserWithAccount({
    email: input.email,
    password: await hashPassword(input.password),
    firstName: input.firstName,
    lastName: input.lastName,
    role: input.role || "STUDENT"
  });
  return {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    isActive: user.isActive,
    createdAt: user.createdAt.toISOString()
  };
}
async function updateUser(input) {
  const user = await findUserById(input.id);
  if (!user) {
    throw new AppError("NOT_FOUND", "User not found");
  }
  const newFirstName = input.firstName || user.firstName;
  const newLastName = input.lastName || user.lastName;
  const updated = await updateUser$1(input.id, {
    ...input.firstName && { firstName: input.firstName },
    ...input.lastName && { lastName: input.lastName },
    ...(input.firstName || input.lastName) && { name: `${newFirstName} ${newLastName}` },
    ...input.role && { role: input.role },
    ...input.isActive !== void 0 && { isActive: input.isActive }
  });
  return {
    id: updated.id,
    email: updated.email,
    firstName: updated.firstName,
    lastName: updated.lastName,
    role: updated.role,
    isActive: updated.isActive,
    createdAt: updated.createdAt.toISOString()
  };
}
async function getUserDetail(id) {
  const user = await findUserById(id);
  if (!user) {
    throw new AppError("NOT_FOUND", "User not found");
  }
  return {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    isActive: user.isActive,
    emailVerified: user.emailVerified,
    createdAt: user.createdAt.toISOString()
  };
}
async function listUsers(params) {
  const { items, total } = await listUsers$1({
    ...params,
    role: params.role
  });
  return {
    items: items.map((u) => ({
      id: u.id,
      email: u.email,
      firstName: u.firstName,
      lastName: u.lastName,
      role: u.role,
      isActive: u.isActive,
      createdAt: u.createdAt.toISOString()
    })),
    total,
    page: params.page,
    pageSize: params.pageSize,
    totalPages: Math.ceil(total / params.pageSize)
  };
}
async function deactivateUser(id) {
  const user = await findUserById(id);
  if (!user) {
    throw new AppError("NOT_FOUND", "User not found");
  }
  await updateUser$1(id, { isActive: false });
}
async function updateProfile(userId, data) {
  await updateUser$1(userId, {
    ...data,
    name: `${data.firstName} ${data.lastName}`
  });
}
const listUsersAction_createServerFn_handler = createServerRpc({
  id: "b7696922eb2a9b4b534965e82b8dbc591fb7480c15a4911ce8c8f8eb6ec6d84d",
  name: "listUsersAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => listUsersAction.__executeServer(opts));
const listUsersAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => userListFiltersSchema.parse(data)).handler(listUsersAction_createServerFn_handler, async ({
  data
}) => {
  return listUsers(data);
});
const getUserDetailAction_createServerFn_handler = createServerRpc({
  id: "e6165ffadd665440f233c6dcdabad7ee5acec2dddf768cad9cbd3263669f5f31",
  name: "getUserDetailAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => getUserDetailAction.__executeServer(opts));
const getUserDetailAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("User ID is required");
  return parsed;
}).handler(getUserDetailAction_createServerFn_handler, async ({
  data
}) => {
  return getUserDetail(data.id);
});
const createUserAction_createServerFn_handler = createServerRpc({
  id: "3051a517b703384fb169c2458f9993be9e13aeef758c48f794f23cc3e01ee64b",
  name: "createUserAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => createUserAction.__executeServer(opts));
const createUserAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createUserSchema.parse(data)).handler(createUserAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const user = await createUser(data);
    return {
      success: true,
      data: user
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const updateUserAction_createServerFn_handler = createServerRpc({
  id: "3a59b41934309245ebe39c5ffc725bce70819d69088f9c7c32959f9b958a2f93",
  name: "updateUserAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => updateUserAction.__executeServer(opts));
const updateUserAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateUserSchema.parse(data)).handler(updateUserAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const user = await updateUser(data);
    return {
      success: true,
      data: user
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const deactivateUserAction_createServerFn_handler = createServerRpc({
  id: "d8fd2a3b13c2cd23962fa7e7d22eaab6db1db56576ea23ad049142f16c69c5c3",
  name: "deactivateUserAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => deactivateUserAction.__executeServer(opts));
const deactivateUserAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("User ID is required");
  return parsed;
}).handler(deactivateUserAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await deactivateUser(data.id);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const updateProfileAction_createServerFn_handler = createServerRpc({
  id: "6f44cebbfa92944baa2c11f0a67a9a9c62430b1ff9353369b7ad7ce54f12e3af",
  name: "updateProfileAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => updateProfileAction.__executeServer(opts));
const updateProfileAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).inputValidator((data) => updateProfileSchema.parse(data)).handler(updateProfileAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    await updateProfile(user.id, data);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const listInstructorsAction_createServerFn_handler = createServerRpc({
  id: "ff0b6c6a19031f0571921308251dc45447ba423cb1dc67f2e04eabd66b402550",
  name: "listInstructorsAction",
  filename: "src/server/actions/user.actions.ts"
}, (opts) => listInstructorsAction.__executeServer(opts));
const listInstructorsAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(listInstructorsAction_createServerFn_handler, async () => {
  const {
    listInstructors
  } = await import("./user.repository-02e89y02.mjs");
  return listInstructors();
});
export {
  createUserAction_createServerFn_handler,
  deactivateUserAction_createServerFn_handler,
  getUserDetailAction_createServerFn_handler,
  listInstructorsAction_createServerFn_handler,
  listUsersAction_createServerFn_handler,
  updateProfileAction_createServerFn_handler,
  updateUserAction_createServerFn_handler
};
