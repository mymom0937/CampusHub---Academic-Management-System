const SplitComponent = () => null;
export {
  SplitComponent as component
};
