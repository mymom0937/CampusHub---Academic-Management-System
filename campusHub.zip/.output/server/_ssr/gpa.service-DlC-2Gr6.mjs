import { p as prisma, A as AppError } from "./middleware-DiEMT5y4.mjs";
import { G as GRADE_POINTS, A as ACADEMIC_STANDING } from "./constants-DoiYt0dc.mjs";
function calculateGpa(entries) {
  let totalPoints = 0;
  let totalCredits = 0;
  for (const entry of entries) {
    if (!entry.grade) continue;
    const points = GRADE_POINTS[entry.grade];
    if (points === null) continue;
    totalPoints += points * entry.credits;
    totalCredits += entry.credits;
  }
  if (totalCredits === 0) return null;
  return Math.round(totalPoints / totalCredits * 1e3) / 1e3;
}
function getAcademicStanding(gpa) {
  if (gpa === null) return "N/A";
  if (gpa >= ACADEMIC_STANDING.DEANS_LIST) return "Dean's List";
  if (gpa >= ACADEMIC_STANDING.GOOD_STANDING) return "Good Standing";
  return "Academic Probation";
}
function getAcademicStatus(gpa) {
  if (gpa === null) return "N/A";
  if (gpa >= ACADEMIC_STANDING.GOOD_STANDING) return "Promoted";
  return "Academic Probation";
}
function getGpaEligibleEnrollments(enrollments) {
  const latestByCourseCode = /* @__PURE__ */ new Map();
  const latestDateByCourseCode = /* @__PURE__ */ new Map();
  for (const enrollment of enrollments) {
    if (enrollment.status !== "COMPLETED") continue;
    if (!enrollment.grade || GRADE_POINTS[enrollment.grade] === null) continue;
    const code = enrollment.course.code;
    const date = enrollment.course.semester.startDate;
    const existingDate = latestDateByCourseCode.get(code);
    if (!existingDate || date > existingDate) {
      latestByCourseCode.set(code, enrollment.id);
      latestDateByCourseCode.set(code, date);
    }
  }
  return new Set(latestByCourseCode.values());
}
async function getTranscript(studentId) {
  const enrollments = await prisma.enrollment.findMany({
    where: { studentId },
    include: {
      course: {
        include: {
          semester: {
            select: { id: true, name: true, code: true, startDate: true }
          }
        }
      }
    }
  });
  enrollments.sort((a, b) => {
    const dA = a.course?.semester?.startDate;
    const dB = b.course?.semester?.startDate;
    if (!dA || !dB) return 0;
    return new Date(dA).getTime() - new Date(dB).getTime();
  });
  const gpaEligible = getGpaEligibleEnrollments(
    enrollments.map((e) => ({
      id: e.id,
      course: {
        code: e.course.code,
        semester: { startDate: new Date(e.course.semester.startDate) }
      },
      grade: e.grade,
      status: e.status
    }))
  );
  const semesterMap = /* @__PURE__ */ new Map();
  for (const enrollment of enrollments) {
    if (!enrollment.course?.semester) continue;
    const semesterId = enrollment.course.semester.id;
    if (!semesterMap.has(semesterId)) {
      semesterMap.set(semesterId, {
        semesterName: enrollment.course.semester.name,
        semesterCode: enrollment.course.semester.code,
        semesterStartDate: new Date(enrollment.course.semester.startDate),
        courses: []
      });
    }
    semesterMap.get(semesterId).courses.push({
      courseCode: enrollment.course.code,
      courseName: enrollment.course.name,
      credits: enrollment.course.credits,
      grade: enrollment.grade,
      gradePoints: enrollment.gradePoints,
      status: enrollment.status,
      enrollmentId: enrollment.id
    });
  }
  const rawEntries = [];
  for (const semesterData of semesterMap.values()) {
    const gpaEligibleCourses = semesterData.courses.filter(
      (c) => gpaEligible.has(c.enrollmentId)
    );
    const semesterGpa = calculateGpa(
      gpaEligibleCourses.map((c) => ({
        grade: c.grade,
        credits: c.credits,
        gradePoints: c.gradePoints
      }))
    );
    let semesterCredits = 0;
    let semesterGradePoints = 0;
    for (const course of gpaEligibleCourses) {
      if (course.grade && GRADE_POINTS[course.grade] !== null) {
        const pts = GRADE_POINTS[course.grade] ?? 0;
        semesterCredits += course.credits;
        semesterGradePoints += pts * course.credits;
      }
    }
    rawEntries.push({
      semesterName: semesterData.semesterName,
      semesterCode: semesterData.semesterCode,
      semesterStartDate: semesterData.semesterStartDate,
      courses: semesterData.courses.map(({ enrollmentId, ...rest }) => rest),
      semesterCredits,
      semesterGradePoints,
      semesterGpa
    });
  }
  rawEntries.sort((a, b) => a.semesterStartDate.getTime() - b.semesterStartDate.getTime());
  const entries = rawEntries.map((e) => ({
    semesterName: e.semesterName,
    semesterCode: e.semesterCode,
    semesterStartDate: e.semesterStartDate.toISOString(),
    courses: e.courses,
    semesterCredits: e.semesterCredits,
    semesterGradePoints: e.semesterGradePoints,
    semesterGpa: e.semesterGpa
  }));
  const allTotalCredits = rawEntries.reduce((s, e) => s + e.semesterCredits, 0);
  const allTotalPoints = rawEntries.reduce((s, e) => s + e.semesterGradePoints, 0);
  const cumulativeGpa = allTotalCredits > 0 ? Math.round(allTotalPoints / allTotalCredits * 1e3) / 1e3 : null;
  const lastEntry = rawEntries[rawEntries.length - 1];
  const previousCredits = lastEntry ? allTotalCredits - lastEntry.semesterCredits : 0;
  const previousGradePoints = lastEntry ? allTotalPoints - lastEntry.semesterGradePoints : 0;
  const previousGpa = previousCredits > 0 ? Math.round(previousGradePoints / previousCredits * 1e3) / 1e3 : null;
  const progression = lastEntry ? {
    previousTotalCredits: previousCredits,
    previousTotalGradePoints: previousGradePoints,
    previousGpa,
    lastSemesterCredits: lastEntry.semesterCredits,
    lastSemesterGradePoints: lastEntry.semesterGradePoints,
    lastSemesterGpa: lastEntry.semesterGpa,
    cumulativeCredits: allTotalCredits,
    cumulativeGradePoints: allTotalPoints,
    cumulativeGpa,
    academicStatus: getAcademicStatus(cumulativeGpa)
  } : void 0;
  const summary = {
    cumulativeGpa,
    totalCredits: allTotalCredits,
    totalGradePoints: allTotalPoints,
    academicStanding: getAcademicStanding(cumulativeGpa),
    progression
  };
  return { entries, summary };
}
async function getGpaSummary(studentId) {
  const { summary } = await getTranscript(studentId);
  return summary;
}
async function getStudentTranscriptForStaff(staffId, staffRole, studentId) {
  const student = await prisma.user.findUnique({
    where: { id: studentId },
    select: { id: true, firstName: true, lastName: true, email: true, role: true }
  });
  if (!student) {
    throw new AppError("NOT_FOUND", "Student not found");
  }
  if (student.role !== "STUDENT") {
    throw new AppError("BAD_REQUEST", "Only student transcripts can be viewed");
  }
  if (staffRole === "INSTRUCTOR") {
    const hasAccess = await prisma.enrollment.findFirst({
      where: {
        studentId,
        course: {
          instructorAssignments: {
            some: { instructorId: staffId }
          }
        }
      }
    });
    if (!hasAccess) {
      throw new AppError("FORBIDDEN", "You can only view transcripts of students in your courses");
    }
  }
  const transcript = await getTranscript(studentId);
  return {
    transcript,
    student: {
      id: student.id,
      firstName: student.firstName,
      lastName: student.lastName,
      email: student.email
    }
  };
}
export {
  getStudentTranscriptForStaff as a,
  getGpaSummary as b,
  getTranscript as g
};
