import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { b as authMiddleware, a as adminMiddleware, t as toAppError, A as AppError, p as prisma } from "./middleware-DiEMT5y4.mjs";
import { c as createAnnouncementSchema, u as updateAnnouncementSchema } from "./notification.schema-BWgQdqns.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
async function getUserNotifications$1(userId, limit = 20, unreadOnly = false) {
  return prisma.notification.findMany({
    where: {
      userId,
      ...unreadOnly && { isRead: false }
    },
    orderBy: { createdAt: "desc" },
    take: limit
  });
}
async function countUnread(userId) {
  return prisma.notification.count({
    where: { userId, isRead: false }
  });
}
async function markAsRead$1(id, userId) {
  return prisma.notification.updateMany({
    where: { id, userId },
    data: { isRead: true }
  });
}
async function markAllAsRead$1(userId) {
  return prisma.notification.updateMany({
    where: { userId, isRead: false },
    data: { isRead: true }
  });
}
async function createAnnouncement$1(data) {
  return prisma.announcement.create({ data });
}
async function updateAnnouncement$1(id, data) {
  return prisma.announcement.update({
    where: { id },
    data
  });
}
async function deleteAnnouncement$1(id) {
  return prisma.announcement.delete({ where: { id } });
}
async function listAnnouncements$1(role) {
  return prisma.announcement.findMany({
    where: {
      isPublished: true,
      OR: [
        { targetRole: null },
        ...role ? [{ targetRole: role }] : []
      ]
    },
    include: {
      author: {
        select: { firstName: true, lastName: true }
      }
    },
    orderBy: { createdAt: "desc" },
    take: 50
  });
}
async function listAllAnnouncements$1() {
  return prisma.announcement.findMany({
    include: {
      author: {
        select: { firstName: true, lastName: true }
      }
    },
    orderBy: { createdAt: "desc" }
  });
}
async function findAnnouncementById(id) {
  return prisma.announcement.findUnique({
    where: { id },
    include: {
      author: {
        select: { firstName: true, lastName: true }
      }
    }
  });
}
async function getUserNotifications(userId, unreadOnly = false) {
  const notifications = await getUserNotifications$1(userId, 20, unreadOnly);
  return notifications.map((n) => ({
    id: n.id,
    title: n.title,
    message: n.message,
    type: n.type,
    isRead: n.isRead,
    link: n.link,
    createdAt: n.createdAt.toISOString()
  }));
}
async function getUnreadCount(userId) {
  return countUnread(userId);
}
async function markAsRead(id, userId) {
  await markAsRead$1(id, userId);
}
async function markAllAsRead(userId) {
  await markAllAsRead$1(userId);
}
async function createAnnouncement(data) {
  return createAnnouncement$1(data);
}
async function updateAnnouncement(id, data) {
  const existing = await findAnnouncementById(id);
  if (!existing) {
    throw new AppError("NOT_FOUND", "Announcement not found");
  }
  return updateAnnouncement$1(id, data);
}
async function deleteAnnouncement(id) {
  const existing = await findAnnouncementById(id);
  if (!existing) {
    throw new AppError("NOT_FOUND", "Announcement not found");
  }
  await deleteAnnouncement$1(id);
}
async function listAnnouncements(role) {
  const announcements = await listAnnouncements$1(role);
  return announcements.map((a) => ({
    id: a.id,
    title: a.title,
    content: a.content,
    authorName: `${a.author.firstName} ${a.author.lastName}`,
    targetRole: a.targetRole,
    isPublished: a.isPublished,
    createdAt: a.createdAt.toISOString(),
    mediaType: a.mediaType ?? "TEXT",
    mediaUrl: a.mediaUrl ?? null
  }));
}
async function listAllAnnouncements() {
  const announcements = await listAllAnnouncements$1();
  return announcements.map((a) => ({
    id: a.id,
    title: a.title,
    content: a.content,
    authorName: `${a.author.firstName} ${a.author.lastName}`,
    targetRole: a.targetRole,
    isPublished: a.isPublished,
    createdAt: a.createdAt.toISOString(),
    mediaType: a.mediaType ?? "TEXT",
    mediaUrl: a.mediaUrl ?? null
  }));
}
const getNotificationsAction_createServerFn_handler = createServerRpc({
  id: "249bfa1ab6b136226c38fdf4e80f010a28cc820824051c432777e2b52f44749b",
  name: "getNotificationsAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => getNotificationsAction.__executeServer(opts));
const getNotificationsAction = createServerFn({
  method: "GET"
}).middleware([authMiddleware]).handler(getNotificationsAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getUserNotifications(user.id);
});
const getUnreadCountAction_createServerFn_handler = createServerRpc({
  id: "22a533bbc9f89ec4423b30bf94853b23d130253cb0d703cb00f979498fe5686e",
  name: "getUnreadCountAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => getUnreadCountAction.__executeServer(opts));
const getUnreadCountAction = createServerFn({
  method: "GET"
}).middleware([authMiddleware]).handler(getUnreadCountAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getUnreadCount(user.id);
});
const markNotificationReadAction_createServerFn_handler = createServerRpc({
  id: "c8a8d82718fdc162048ff23eca5b3771448bda863a57c4b9ebe6a9a62ead8d23",
  name: "markNotificationReadAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => markNotificationReadAction.__executeServer(opts));
const markNotificationReadAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Notification ID is required");
  return parsed;
}).handler(markNotificationReadAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  await markAsRead(data.id, user.id);
  return {
    success: true
  };
});
const markAllNotificationsReadAction_createServerFn_handler = createServerRpc({
  id: "8c2420d1dec316c78f5b7f42e6660db9222e2f718145a4ca64f0e5d409680d13",
  name: "markAllNotificationsReadAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => markAllNotificationsReadAction.__executeServer(opts));
const markAllNotificationsReadAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).handler(markAllNotificationsReadAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  await markAllAsRead(user.id);
  return {
    success: true
  };
});
const listAnnouncementsAction_createServerFn_handler = createServerRpc({
  id: "84b6b9a3459f859c6178b53d901f0cbb55d6d26544b3581a0e418680069e9683",
  name: "listAnnouncementsAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => listAnnouncementsAction.__executeServer(opts));
const listAnnouncementsAction = createServerFn({
  method: "GET"
}).middleware([authMiddleware]).handler(listAnnouncementsAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return listAnnouncements(user.role);
});
const listAllAnnouncementsAction_createServerFn_handler = createServerRpc({
  id: "b696228bce9cb00f685fc5b8084c0ef3e644dc737eaf36b0b70a2abd472285cf",
  name: "listAllAnnouncementsAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => listAllAnnouncementsAction.__executeServer(opts));
const listAllAnnouncementsAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(listAllAnnouncementsAction_createServerFn_handler, async () => {
  return listAllAnnouncements();
});
const createAnnouncementAction_createServerFn_handler = createServerRpc({
  id: "80a05c721ed82ea6f61419cbae9f2ff31f86f2643d1291e5c5b2376966c97695",
  name: "createAnnouncementAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => createAnnouncementAction.__executeServer(opts));
const createAnnouncementAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createAnnouncementSchema.parse(data)).handler(createAnnouncementAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    await createAnnouncement({
      ...data,
      authorId: user.id,
      targetRole: data.targetRole ?? null
    });
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const updateAnnouncementAction_createServerFn_handler = createServerRpc({
  id: "0ad2230b2868467795caa203427b0e72e336df891d4aceef0a05ddbc2116edf7",
  name: "updateAnnouncementAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => updateAnnouncementAction.__executeServer(opts));
const updateAnnouncementAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateAnnouncementSchema.parse(data)).handler(updateAnnouncementAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await updateAnnouncement(data.id, {
      title: data.title,
      content: data.content,
      // NOTE: keep `null` (ALL users) distinct from `undefined` (no change)
      targetRole: data.targetRole,
      isPublished: data.isPublished,
      mediaType: data.mediaType,
      mediaUrl: data.mediaUrl ?? null
    });
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const deleteAnnouncementAction_createServerFn_handler = createServerRpc({
  id: "c6287c9304ca945f185d6efa26127a07020faea4a3712915fc5dc441d27f6e0c",
  name: "deleteAnnouncementAction",
  filename: "src/server/actions/notification.actions.ts"
}, (opts) => deleteAnnouncementAction.__executeServer(opts));
const deleteAnnouncementAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Announcement ID is required");
  return parsed;
}).handler(deleteAnnouncementAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await deleteAnnouncement(data.id);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
export {
  createAnnouncementAction_createServerFn_handler,
  deleteAnnouncementAction_createServerFn_handler,
  getNotificationsAction_createServerFn_handler,
  getUnreadCountAction_createServerFn_handler,
  listAllAnnouncementsAction_createServerFn_handler,
  listAnnouncementsAction_createServerFn_handler,
  markAllNotificationsReadAction_createServerFn_handler,
  markNotificationReadAction_createServerFn_handler,
  updateAnnouncementAction_createServerFn_handler
};
