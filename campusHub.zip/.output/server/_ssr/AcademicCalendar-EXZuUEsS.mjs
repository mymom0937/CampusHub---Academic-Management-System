import { j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { C as Card, e as CardContent, a as CardHeader, b as CardTitle, c as CardDescription } from "./card-QCkASOp1.mjs";
import { a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { C as Calendar, G as GraduationCap, B as BookOpen, T as TriangleAlert, O as Clock } from "../_libs/lucide-react.mjs";
function AcademicCalendar({ semesters }) {
  const now = /* @__PURE__ */ new Date();
  const formatDate = (iso) => new Date(iso).toLocaleDateString("en-US", {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric"
  });
  const getStatus = (semester) => {
    const start = new Date(semester.startDate);
    const end = new Date(semester.endDate);
    if (now < start) return "upcoming";
    if (now > end) return "completed";
    return "active";
  };
  const getEnrollmentStatus = (semester) => {
    const enrollStart = new Date(semester.enrollmentStart);
    const enrollEnd = new Date(semester.enrollmentEnd);
    if (now < enrollStart) return "upcoming";
    if (now > enrollEnd) return "closed";
    return "open";
  };
  const isDropDeadlinePassed = (semester) => {
    return now > new Date(semester.dropDeadline);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6", children: semesters.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "py-12 text-center text-muted-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-10 w-10 mx-auto mb-3 opacity-40" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No semesters available." })
  ] }) }) : semesters.map((semester) => {
    const status = getStatus(semester);
    const enrollStatus = getEnrollmentStatus(semester);
    const dropPassed = isDropDeadlinePassed(semester);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: status === "active" ? "border-primary" : "", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-5 w-5" }),
            semester.name,
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono text-sm text-muted-foreground", children: [
              "(",
              semester.code,
              ")"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardDescription, { children: [
            semester.courseCount,
            " courses"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Badge,
          {
            variant: status === "active" ? "success" : status === "upcoming" ? "secondary" : "outline",
            children: status === "active" ? "Current" : status === "upcoming" ? "Upcoming" : "Completed"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 min-w-0 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-4 w-4 mt-0.5 text-muted-foreground shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: "Semester Period" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: formatDate(semester.startDate) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
              "to ",
              formatDate(semester.endDate)
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-4 w-4 mt-0.5 text-muted-foreground shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-medium flex items-center gap-1.5", children: [
              "Enrollment",
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: enrollStatus === "open" ? "success" : enrollStatus === "upcoming" ? "secondary" : "destructive", className: "text-[10px] px-1.5 py-0", children: enrollStatus === "open" ? "Open" : enrollStatus === "upcoming" ? "Not yet" : "Closed" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: formatDate(semester.enrollmentStart) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground", children: [
              "to ",
              formatDate(semester.enrollmentEnd)
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-4 w-4 mt-0.5 text-muted-foreground shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-medium flex items-center gap-1.5", children: [
              "Drop Deadline",
              dropPassed && /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "destructive", className: "text-[10px] px-1.5 py-0", children: "Passed" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: formatDate(semester.dropDeadline) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4 mt-0.5 text-muted-foreground shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: semester.isActive ? "Active semester" : "Inactive" })
          ] })
        ] })
      ] }) })
    ] }, semester.id);
  }) });
}
export {
  AcademicCalendar as A
};
