import { o as object, j as array, s as string, n as number } from "../_libs/zod.mjs";
const assessmentItemSchema = object({
  name: string().min(1, "Name is required").max(80),
  weight: number().min(0).max(100),
  maxScore: number().min(1).max(1e3).optional().default(100)
});
const saveAssessmentsSchema = object({
  courseId: string().min(1),
  assessments: array(assessmentItemSchema).min(1, "At least one assessment required")
}).refine(
  (data) => {
    const total = data.assessments.reduce((s, a) => s + a.weight, 0);
    return total === 100;
  },
  { message: "Assessment weights must total 100%", path: ["assessments"] }
);
const saveScoresSchema = object({
  enrollmentId: string().min(1),
  scores: array(object({
    assessmentId: string().min(1),
    score: number().min(0).nullable(),
    maxScore: number().min(1).optional()
  }))
});
export {
  saveScoresSchema as a,
  saveAssessmentsSchema as s
};
