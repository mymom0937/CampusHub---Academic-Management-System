import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { A as cn } from "./router-DhCkpF2X.mjs";
const Input = reactExports.forwardRef(
  ({ className, type, error, ...props }, ref) => {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type,
          className: cn(
            "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
            error && "border-destructive focus-visible:ring-destructive",
            className
          ),
          ref,
          ...props
        }
      ),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-destructive", children: error })
    ] });
  }
);
Input.displayName = "Input";
export {
  Input as I
};
