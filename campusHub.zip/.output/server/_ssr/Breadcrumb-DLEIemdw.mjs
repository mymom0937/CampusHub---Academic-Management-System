import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { L as Link, d as useLocation, u as useNavigate } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { A as cn, B as Button, h as ROLE_LABELS, Z as logoutAction, am as resendVerificationEmailAction, ai as getNotificationsAction, aj as getUnreadCountAction, ak as markAllNotificationsReadAction, al as markNotificationReadAction } from "./router-DhCkpF2X.mjs";
import { M as ModeToggle, D as DropdownMenu, a as DropdownMenuTrigger, b as DropdownMenuContent, c as DropdownMenuLabel, d as DropdownMenuSeparator, e as DropdownMenuItem } from "./ModeToggle-l3F05cxw.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { A as AppFooter } from "./AppFooter-D0WDOsDC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { j as ChevronRight, H as House, i as ChevronLeft, u as CircleQuestionMark, l as Menu, G as GraduationCap, v as Search, w as ChevronDown, x as User, K as KeyRound, k as LogOut, T as TriangleAlert, c as Mail, X, y as School, z as Settings, L as LayoutDashboard, B as BookOpen, m as ClipboardList, f as ChartColumn, o as FileText, C as Calendar, U as Users, a as Megaphone, D as Bell, J as CheckCheck } from "../_libs/lucide-react.mjs";
const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground",
        secondary: "border-transparent bg-secondary text-secondary-foreground",
        destructive: "border-transparent bg-destructive text-destructive-foreground",
        outline: "text-foreground",
        success: "border-transparent bg-success text-success-foreground",
        warning: "border-transparent bg-warning text-warning-foreground"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Badge({ className, variant, ...props }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn(badgeVariants({ variant }), className), ...props });
}
const adminNav = [
  {
    title: "Overview",
    items: [
      { label: "Dashboard", href: "/admin", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-5 w-5" }) }
    ]
  },
  {
    title: "Management",
    items: [
      { label: "Users", href: "/admin/users", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-5 w-5" }) },
      { label: "Courses", href: "/admin/courses", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-5 w-5" }) },
      { label: "Semesters", href: "/admin/semesters", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-5 w-5" }) },
      { label: "Transcripts", href: "/admin/transcripts", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-5 w-5" }) }
    ]
  },
  {
    title: "Communication",
    items: [
      { label: "Announcements", href: "/admin/announcements", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Megaphone, { className: "h-5 w-5" }) },
      { label: "Calendar", href: "/admin/calendar", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-5 w-5" }) }
    ]
  }
];
const instructorNav = [
  {
    title: "Overview",
    items: [
      { label: "Dashboard", href: "/instructor", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-5 w-5" }) }
    ]
  },
  {
    title: "Teaching",
    items: [
      { label: "My Courses", href: "/instructor/courses", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-5 w-5" }) },
      { label: "Transcripts", href: "/instructor/transcripts", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-5 w-5" }) },
      { label: "Calendar", href: "/instructor/calendar", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-5 w-5" }) }
    ]
  }
];
const studentNav = [
  {
    title: "Overview",
    items: [
      { label: "Dashboard", href: "/student", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-5 w-5" }) }
    ]
  },
  {
    title: "Academics",
    items: [
      { label: "Course Catalog", href: "/student/courses", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-5 w-5" }) },
      { label: "My Enrollment", href: "/student/enrollment", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ClipboardList, { className: "h-5 w-5" }) },
      { label: "My Grades", href: "/student/grades", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "h-5 w-5" }) },
      { label: "Transcript", href: "/student/transcript", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-5 w-5" }) }
    ]
  },
  {
    title: "Schedule",
    items: [
      { label: "Calendar", href: "/student/calendar", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-5 w-5" }) }
    ]
  }
];
const roleNavMap = {
  ADMIN: adminNav,
  INSTRUCTOR: instructorNav,
  STUDENT: studentNav
};
const roleIconMap = {
  ADMIN: /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "h-5 w-5" }),
  INSTRUCTOR: /* @__PURE__ */ jsxRuntimeExports.jsx(School, { className: "h-5 w-5" }),
  STUDENT: /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-5 w-5" })
};
const roleLabelMap = {
  ADMIN: "Admin Panel",
  INSTRUCTOR: "Instructor Portal",
  STUDENT: "Student Portal"
};
const bottomNav = [
  { label: "Profile", href: "/profile", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "h-5 w-5" }) },
  { label: "Change Password", href: "/profile/password", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "h-5 w-5" }) }
];
function Sidebar({ role, collapsed, onToggle }) {
  const location = useLocation();
  const navGroups = roleNavMap[role];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "aside",
    {
      className: cn(
        "fixed left-0 top-0 z-40 flex h-screen flex-col border-r bg-sidebar text-sidebar-foreground transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      ),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between h-16 px-4 border-b border-sidebar-border shrink-0", children: [
          collapsed ? /* @__PURE__ */ jsxRuntimeExports.jsx(
            Link,
            {
              to: "/",
              className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors",
              title: "Back to home",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "h-5 w-5" })
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Link,
            {
              to: "/",
              className: "flex items-center gap-2.5 rounded-md hover:bg-sidebar-accent/50 transition-colors",
              title: "Back to home",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary", children: roleIconMap[role] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-sm truncate", children: roleLabelMap[role] })
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: onToggle,
              className: cn(
                "p-1.5 rounded-md hover:bg-sidebar-accent transition-colors",
                collapsed && "mx-auto"
              ),
              "aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                ChevronLeft,
                {
                  className: cn(
                    "h-4 w-4 transition-transform",
                    collapsed && "rotate-180"
                  )
                }
              )
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "flex-1 overflow-y-auto p-3 space-y-4 font-nav", children: navGroups.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-sidebar-foreground/40", children: group.title }),
          collapsed && group.title !== "Overview" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-3 mb-2 border-t border-sidebar-border" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-0.5", children: group.items.map((item) => {
            const isActive = location.pathname === item.href || item.href !== `/${role.toLowerCase()}` && location.pathname.startsWith(item.href);
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Link,
              {
                to: item.href,
                className: cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                  isActive ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                ),
                title: collapsed ? item.label : void 0,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0", children: item.icon }),
                  !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.label })
                ]
              },
              item.href
            );
          }) })
        ] }, group.title)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "shrink-0 border-t border-sidebar-border p-3 space-y-0.5", children: [
          !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-sidebar-foreground/40", children: "Account" }),
          bottomNav.map((item) => {
            const isActive = location.pathname === item.href;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Link,
              {
                to: item.href,
                className: cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                  isActive ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                ),
                title: collapsed ? item.label : void 0,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0", children: item.icon }),
                  !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: item.label })
                ]
              },
              item.href
            );
          }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Link,
            {
              to: "/",
              hash: "contact",
              className: "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground transition-colors",
              title: collapsed ? "Help & Support" : void 0,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleQuestionMark, { className: "h-5 w-5" }) }),
                !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: "Help & Support" })
              ]
            }
          ),
          !collapsed && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-sidebar-foreground/30 font-medium", children: "CampusHub v1.0.0" }) })
        ] })
      ]
    }
  );
}
function NotificationBell() {
  const [notifications, setNotifications] = reactExports.useState([]);
  const [unreadCount, setUnreadCount] = reactExports.useState(0);
  const [open, setOpen] = reactExports.useState(false);
  const fetchData = async () => {
    try {
      const [notifs, count] = await Promise.all([
        getNotificationsAction(),
        getUnreadCountAction()
      ]);
      setNotifications(notifs);
      setUnreadCount(count);
    } catch {
    }
  };
  reactExports.useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 6e4);
    return () => clearInterval(interval);
  }, []);
  const handleMarkRead = async (id) => {
    await markNotificationReadAction({ data: { id } });
    fetchData();
  };
  const handleMarkAllRead = async () => {
    await markAllNotificationsReadAction();
    fetchData();
  };
  const formatTime = (iso) => {
    const date = new Date(iso);
    const now = /* @__PURE__ */ new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 6e4);
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenu, { open, onOpenChange: setOpen, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "icon", className: "relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "h-5 w-5" }),
      unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground", children: unreadCount > 9 ? "9+" : unreadCount }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Notifications" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenuContent, { align: "end", className: "w-80", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenuLabel, { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Notifications" }),
        unreadCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "ghost",
            size: "sm",
            className: "h-auto p-0 text-xs text-muted-foreground hover:text-foreground",
            onClick: (e) => {
              e.preventDefault();
              handleMarkAllRead();
            },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CheckCheck, { className: "h-3 w-3 mr-1" }),
              "Mark all read"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuSeparator, {}),
      notifications.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-6 text-center text-sm text-muted-foreground", children: "No notifications" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-80 overflow-y-auto", children: notifications.slice(0, 10).map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        DropdownMenuItem,
        {
          className: "flex flex-col items-start gap-1 p-3 cursor-pointer",
          onClick: () => {
            if (!n.isRead) handleMarkRead(n.id);
            setOpen(false);
          },
          asChild: !!n.link,
          children: n.link ? /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: n.link, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2 w-full", children: [
            !n.isRead && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-1.5 h-2 w-2 rounded-full bg-blue-500 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: !n.isRead ? "" : "ml-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium leading-tight", children: n.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-0.5 line-clamp-2", children: n.message }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground mt-1", children: formatTime(n.createdAt) })
            ] })
          ] }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2 w-full", children: [
            !n.isRead && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-1.5 h-2 w-2 rounded-full bg-blue-500 shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: !n.isRead ? "" : "ml-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium leading-tight", children: n.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-0.5 line-clamp-2", children: n.message }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-muted-foreground mt-1", children: formatTime(n.createdAt) })
            ] })
          ] })
        },
        n.id
      )) })
    ] })
  ] });
}
function Navbar({ user, onMenuToggle }) {
  const navigate = useNavigate();
  const handleLogout = async () => {
    await logoutAction();
    navigate({ to: "/login" });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "sticky top-0 z-40 flex h-16 shrink-0 items-center border-b bg-background backdrop-blur-md px-4 md:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "ghost",
        size: "icon",
        className: "mr-2 md:hidden",
        onClick: onMenuToggle,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "h-5 w-5" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Toggle menu" })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-6 w-6 text-primary" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-lg", children: "CampusHub" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-1 max-w-md max-md:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "search",
          placeholder: "Search courses, students...",
          "aria-label": "Search courses and students",
          className: "flex h-9 w-full rounded-lg border border-input bg-muted/50 px-3 pl-9 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(NotificationBell, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ModeToggle, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenu, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", className: "flex items-center gap-2 px-2 lg:px-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-8 w-8 items-center justify-center rounded-full bg-linear-to-br from-primary to-violet-600 text-primary-foreground text-sm font-semibold", children: [
            user.firstName[0],
            user.lastName[0]
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-lg:hidden text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-medium leading-tight", children: [
              user.firstName,
              " ",
              user.lastName
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-muted-foreground leading-tight", children: ROLE_LABELS[user.role] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "max-lg:hidden h-3.5 w-3.5 text-muted-foreground" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DropdownMenuContent, { align: "end", className: "w-64", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuLabel, { className: "font-normal", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-10 w-10 items-center justify-center rounded-full bg-linear-to-br from-primary to-violet-600 text-primary-foreground text-sm font-semibold shrink-0", children: [
              user.firstName[0],
              user.lastName[0]
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col space-y-0.5 min-w-0", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-semibold truncate", children: [
                user.firstName,
                " ",
                user.lastName
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground truncate", children: user.email }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "secondary", className: "w-fit text-[10px] px-1.5 py-0", children: ROLE_LABELS[user.role] })
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/profile", className: "cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "mr-2 h-4 w-4" }),
            "Profile Settings"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuItem, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/profile/password", className: "cursor-pointer", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "mr-2 h-4 w-4" }),
            "Change Password"
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            DropdownMenuItem,
            {
              onClick: handleLogout,
              className: "cursor-pointer text-destructive focus:text-destructive",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "mr-2 h-4 w-4" }),
                "Log Out"
              ]
            }
          )
        ] })
      ] })
    ] })
  ] });
}
function DashboardFooter() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AppFooter, {});
}
function EmailVerificationBanner({ email }) {
  const [dismissed, setDismissed] = reactExports.useState(false);
  const [sending, setSending] = reactExports.useState(false);
  if (dismissed) return null;
  const handleResend = async () => {
    setSending(true);
    try {
      const result = await resendVerificationEmailAction();
      if (result.success) {
        toast.success(result.message);
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to send verification email");
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-amber-50 dark:bg-amber-950/30 border-b border-amber-200 dark:border-amber-800", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 px-4 py-3 md:px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "h-5 w-5 text-amber-600 dark:text-amber-400" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-amber-800 dark:text-amber-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: "Email not verified." }),
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "hidden sm:inline", children: [
          "Please verify your email address (",
          email,
          ") to access all features."
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "outline",
          size: "sm",
          onClick: handleResend,
          disabled: sending,
          className: "border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/50",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-4 w-4 mr-1.5" }),
            sending ? "Sending..." : "Resend"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "ghost",
          size: "icon",
          onClick: () => setDismissed(true),
          className: "h-8 w-8 text-amber-600 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-900/50",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Dismiss" })
          ]
        }
      )
    ] })
  ] }) });
}
function DashboardLayout({ user, children }) {
  const [sidebarCollapsed, setSidebarCollapsed] = reactExports.useState(false);
  const [mobileOpen, setMobileOpen] = reactExports.useState(false);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-md:hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Sidebar,
      {
        role: user.role,
        collapsed: sidebarCollapsed,
        onToggle: () => setSidebarCollapsed(!sidebarCollapsed)
      }
    ) }),
    mobileOpen && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "fixed inset-0 z-40 bg-black/50",
          onClick: () => setMobileOpen(false)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed left-0 top-0 z-50 h-full", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        Sidebar,
        {
          role: user.role,
          collapsed: false,
          onToggle: () => setMobileOpen(false)
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: cn(
          "min-w-0 transition-all duration-300 flex flex-col min-h-screen",
          sidebarCollapsed ? "md:ml-16" : "md:ml-64"
        ),
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Navbar,
            {
              user,
              onMenuToggle: () => setMobileOpen(!mobileOpen)
            }
          ),
          !user.emailVerified && /* @__PURE__ */ jsxRuntimeExports.jsx(EmailVerificationBanner, { email: user.email }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "min-w-0 max-w-full flex-1 overflow-x-hidden p-4 md:p-6 lg:p-8", children }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(DashboardFooter, {})
        ]
      }
    )
  ] });
}
function Breadcrumb({ items, className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "nav",
    {
      "aria-label": "Breadcrumb",
      className: cn("flex flex-wrap items-center gap-y-1 gap-x-1 text-sm text-muted-foreground mb-4 min-w-0", className),
      children: items.map((item, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center", children: [
        index > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-4 w-4 mx-1" }),
        item.href && index < items.length - 1 ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: item.href,
            className: "hover:text-foreground transition-colors",
            children: item.label
          }
        ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: cn(index === items.length - 1 && "text-foreground font-medium"),
            children: item.label
          }
        )
      ] }, `${item.label}-${index}`))
    }
  );
}
export {
  Breadcrumb as B,
  DashboardLayout as D,
  Badge as a
};
