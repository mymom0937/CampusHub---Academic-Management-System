import { o as object, c as boolean, _ as _enum, s as string, g as number } from "../_libs/zod.mjs";
const createUserSchema = object({
  email: string().min(1, "Email is required").email("Invalid email address").transform((v) => v.toLowerCase().trim()),
  password: string().min(8, "Password must be at least 8 characters").regex(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/,
    "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character (!@#$%^&*)"
  ),
  firstName: string().min(1, "First name is required").max(50, "First name too long").transform((v) => v.trim()),
  lastName: string().min(1, "Last name is required").max(50, "Last name too long").transform((v) => v.trim()),
  role: _enum(["ADMIN", "INSTRUCTOR", "STUDENT"])
});
const updateUserSchema = object({
  id: string().min(1),
  firstName: string().min(1, "First name is required").max(50).transform((v) => v.trim()).optional(),
  lastName: string().min(1, "Last name is required").max(50).transform((v) => v.trim()).optional(),
  role: _enum(["ADMIN", "INSTRUCTOR", "STUDENT"]).optional(),
  isActive: boolean().optional()
});
const updateProfileSchema = object({
  firstName: string().min(1, "First name is required").max(50).transform((v) => v.trim()),
  lastName: string().min(1, "Last name is required").max(50).transform((v) => v.trim())
});
const userListFiltersSchema = object({
  page: number().int().positive().default(1),
  pageSize: number().int().positive().max(100).default(10),
  search: string().optional(),
  role: _enum(["ADMIN", "INSTRUCTOR", "STUDENT"]).optional(),
  isActive: boolean().optional()
});
export {
  updateUserSchema as a,
  updateProfileSchema as b,
  createUserSchema as c,
  userListFiltersSchema as u
};
