import { p as prisma, A as AppError } from "./middleware-DiEMT5y4.mjs";
async function getPrerequisites$1(courseCode) {
  return prisma.coursePrerequisite.findMany({
    where: { courseCode },
    orderBy: { prerequisiteCode: "asc" }
  });
}
async function addPrerequisite$1(courseCode, prerequisiteCode) {
  return prisma.coursePrerequisite.create({
    data: { courseCode, prerequisiteCode }
  });
}
async function removePrerequisite$1(id) {
  return prisma.coursePrerequisite.delete({
    where: { id }
  });
}
async function checkPrerequisitesMet$1(studentId, courseCode) {
  const prerequisites = await prisma.coursePrerequisite.findMany({
    where: { courseCode }
  });
  if (prerequisites.length === 0) {
    return { met: true, missing: [] };
  }
  const completedEnrollments = await prisma.enrollment.findMany({
    where: {
      studentId,
      status: "COMPLETED",
      grade: { notIn: ["F", "W", "DO", "NG", "I"] }
    },
    include: {
      course: { select: { code: true } }
    }
  });
  const completedCodes = new Set(completedEnrollments.map((e) => e.course.code));
  const missing = prerequisites.filter((p) => !completedCodes.has(p.prerequisiteCode)).map((p) => p.prerequisiteCode);
  return { met: missing.length === 0, missing };
}
async function listAllPrerequisites$1() {
  return prisma.coursePrerequisite.findMany({
    orderBy: [{ courseCode: "asc" }, { prerequisiteCode: "asc" }]
  });
}
async function getPrerequisites(courseCode) {
  return getPrerequisites$1(courseCode);
}
async function addPrerequisite(courseCode, prerequisiteCode) {
  if (courseCode === prerequisiteCode) {
    throw new AppError("VALIDATION_ERROR", "A course cannot be its own prerequisite");
  }
  try {
    await addPrerequisite$1(courseCode, prerequisiteCode);
  } catch {
    throw new AppError("CONFLICT", "This prerequisite already exists");
  }
}
async function removePrerequisite(id) {
  try {
    await removePrerequisite$1(id);
  } catch {
    throw new AppError("NOT_FOUND", "Prerequisite not found");
  }
}
async function checkPrerequisitesMet(studentId, courseCode) {
  return checkPrerequisitesMet$1(studentId, courseCode);
}
async function listAllPrerequisites() {
  return listAllPrerequisites$1();
}
export {
  addPrerequisite as a,
  checkPrerequisitesMet as c,
  getPrerequisites as g,
  listAllPrerequisites as l,
  removePrerequisite as r
};
