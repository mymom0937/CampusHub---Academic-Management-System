import { p as prisma } from "./middleware-DiEMT5y4.mjs";
async function findSemesterById(id) {
  return prisma.semester.findFirst({
    where: { id, deletedAt: null },
    include: {
      _count: { select: { courses: true } }
    }
  });
}
async function findActiveSemester() {
  return prisma.semester.findFirst({
    where: { isActive: true, deletedAt: null }
  });
}
async function listSemesters() {
  return prisma.semester.findMany({
    where: { deletedAt: null },
    include: {
      _count: { select: { courses: true } }
    },
    orderBy: { startDate: "desc" }
  });
}
async function createSemester(data) {
  if (data.isActive) {
    await prisma.semester.updateMany({
      where: { isActive: true },
      data: { isActive: false }
    });
  }
  return prisma.semester.create({ data });
}
async function updateSemester(id, data) {
  if (data.isActive) {
    await prisma.semester.updateMany({
      where: { isActive: true, id: { not: id } },
      data: { isActive: false }
    });
  }
  return prisma.semester.update({
    where: { id },
    data
  });
}
async function findSemesterByCode(code) {
  return prisma.semester.findFirst({
    where: { code, deletedAt: null }
  });
}
export {
  findActiveSemester as a,
  findSemesterByCode as b,
  createSemester as c,
  findSemesterById as f,
  listSemesters as l,
  updateSemester as u
};
