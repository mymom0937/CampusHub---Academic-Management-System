import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { a as adminMiddleware, p as prisma, s as studentMiddleware, i as instructorMiddleware } from "./middleware-DiEMT5y4.mjs";
import { g as getTranscript } from "./gpa.service-DlC-2Gr6.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./constants-DoiYt0dc.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
const getAdminDashboardAction_createServerFn_handler = createServerRpc({
  id: "4241717dddff692f1c510a57e93446024b3c329ccb1e4cd74bd885fd88d66ff2",
  name: "getAdminDashboardAction",
  filename: "src/server/actions/dashboard.actions.ts"
}, (opts) => getAdminDashboardAction.__executeServer(opts));
const getAdminDashboardAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(getAdminDashboardAction_createServerFn_handler, async () => {
  const [totalUsers, totalStudents, totalInstructors, totalCourses, totalEnrollments, activeSemesters, coursesWithEnrollments, gradeGroups, recentEnrollmentRows] = await Promise.all([
    prisma.user.count({
      where: {
        deletedAt: null
      }
    }),
    prisma.user.count({
      where: {
        role: "STUDENT",
        deletedAt: null,
        isActive: true
      }
    }),
    prisma.user.count({
      where: {
        role: "INSTRUCTOR",
        deletedAt: null,
        isActive: true
      }
    }),
    prisma.course.count({
      where: {
        deletedAt: null
      }
    }),
    prisma.enrollment.count({
      where: {
        status: "ENROLLED"
      }
    }),
    prisma.semester.count({
      where: {
        isActive: true,
        deletedAt: null
      }
    }),
    // Enrollment by course
    prisma.course.findMany({
      where: {
        deletedAt: null
      },
      select: {
        code: true,
        name: true,
        capacity: true,
        _count: {
          select: {
            enrollments: {
              where: {
                status: "ENROLLED"
              }
            }
          }
        }
      },
      orderBy: {
        code: "asc"
      }
    }),
    // Grade distribution
    prisma.enrollment.groupBy({
      by: ["grade"],
      _count: {
        grade: true
      },
      where: {
        grade: {
          not: null
        }
      }
    }),
    // Recent enrollments
    prisma.enrollment.findMany({
      take: 5,
      orderBy: {
        enrolledAt: "desc"
      },
      include: {
        student: {
          select: {
            firstName: true,
            lastName: true
          }
        },
        course: {
          select: {
            code: true
          }
        }
      }
    })
  ]);
  return {
    totalUsers,
    totalStudents,
    totalInstructors,
    totalCourses,
    totalEnrollments,
    activeSemesters,
    enrollmentByCourse: coursesWithEnrollments.map((c) => ({
      courseCode: c.code,
      courseName: c.name,
      enrolled: c._count.enrollments,
      capacity: c.capacity
    })),
    gradeDistribution: gradeGroups.map((g) => ({
      grade: g.grade || "Pending",
      count: g._count.grade
    })),
    recentEnrollments: recentEnrollmentRows.map((e) => ({
      studentName: `${e.student.firstName} ${e.student.lastName}`,
      courseCode: e.course.code,
      enrolledAt: e.enrolledAt.toISOString()
    }))
  };
});
const getStudentDashboardAction_createServerFn_handler = createServerRpc({
  id: "311a0dae574090455fbdae778e0c39ef68b72fbc26582dbd2770b92d5c186c4d",
  name: "getStudentDashboardAction",
  filename: "src/server/actions/dashboard.actions.ts"
}, (opts) => getStudentDashboardAction.__executeServer(opts));
const getStudentDashboardAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(getStudentDashboardAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  const [enrolledCourses, completedCourses, transcript] = await Promise.all([prisma.enrollment.count({
    where: {
      studentId: user.id,
      status: "ENROLLED"
    }
  }), prisma.enrollment.count({
    where: {
      studentId: user.id,
      status: "COMPLETED"
    }
  }), getTranscript(user.id)]);
  const enrolledCredits = await prisma.enrollment.findMany({
    where: {
      studentId: user.id,
      status: "ENROLLED"
    },
    include: {
      course: {
        select: {
          credits: true
        }
      }
    }
  });
  const totalCredits = enrolledCredits.reduce((sum, e) => sum + e.course.credits, 0);
  const gpaTrend = transcript.entries.filter((e) => e.semesterGpa !== null).map((e) => ({
    semesterCode: e.semesterCode,
    semesterName: e.semesterName,
    gpa: e.semesterGpa
  }));
  return {
    enrolledCourses,
    completedCourses,
    totalCredits,
    currentGpa: transcript.summary.cumulativeGpa,
    gpaTrend
  };
});
const getInstructorDashboardAction_createServerFn_handler = createServerRpc({
  id: "a585870de6c2c99093caff11d5d17265418b24f6448596f0234a961ad425a889",
  name: "getInstructorDashboardAction",
  filename: "src/server/actions/dashboard.actions.ts"
}, (opts) => getInstructorDashboardAction.__executeServer(opts));
const getInstructorDashboardAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).handler(getInstructorDashboardAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  const assignments = await prisma.instructorAssignment.findMany({
    where: {
      instructorId: user.id
    },
    include: {
      course: {
        include: {
          _count: {
            select: {
              enrollments: true
            }
          },
          enrollments: {
            select: {
              grade: true
            }
          }
        }
      }
    }
  });
  const assignedCourses = assignments.length;
  let totalStudents = 0;
  let gradedCount = 0;
  let pendingGrades = 0;
  for (const assignment of assignments) {
    totalStudents += assignment.course._count.enrollments;
    for (const enrollment of assignment.course.enrollments) {
      if (enrollment.grade) {
        gradedCount++;
      } else {
        pendingGrades++;
      }
    }
  }
  return {
    assignedCourses,
    totalStudents,
    gradedCount,
    pendingGrades
  };
});
export {
  getAdminDashboardAction_createServerFn_handler,
  getInstructorDashboardAction_createServerFn_handler,
  getStudentDashboardAction_createServerFn_handler
};
