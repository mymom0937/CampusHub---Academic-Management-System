import { o as redirect } from "../_chunks/_libs/@tanstack/router-core.mjs";
import { c as createRouter, a as createRootRoute, b as createFileRoute, l as lazyRouteComponent, H as HeadContent, S as Scripts, O as Outlet, L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { j as jsxRuntimeExports, r as reactExports } from "../_chunks/_libs/react.mjs";
import { T as Toaster } from "../_libs/sonner.mjs";
import { S as Slot } from "../_chunks/_libs/@radix-ui/react-slot.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { g as getRequestHeaders, c as createServerFn, T as TSS_SERVER_FUNCTION, a as getServerFnById } from "./server-BubZoQFo.mjs";
import { l as loginSchema, r as registerSchema, c as changePasswordSchema, f as forgotPasswordSchema, a as resetPasswordSchema } from "./auth.schema-DqwSeq56.mjs";
import { c as auth, i as instructorMiddleware, s as studentMiddleware, a as adminMiddleware, b as authMiddleware, d as staffMiddleware } from "./middleware-DiEMT5y4.mjs";
import { c as createAnnouncementSchema, u as updateAnnouncementSchema } from "./notification.schema-BWgQdqns.mjs";
import { s as submitGradeSchema, b as bulkGradeSchema, e as enrollSchema, d as dropSchema } from "./enrollment.schema-YQ3WLO4x.mjs";
import { s as saveAssessmentsSchema, a as saveScoresSchema } from "./assessment.schema-DvXBy4tg.mjs";
import { c as courseListFiltersSchema, a as createCourseSchema, u as updateCourseSchema, b as assignInstructorSchema, d as createSemesterSchema, e as updateSemesterSchema } from "./course.schema-DAXkVW6U.mjs";
import { u as userListFiltersSchema, c as createUserSchema, a as updateUserSchema, b as updateProfileSchema } from "./user.schema-uS5_1fSq.mjs";
import { c as cloudinaryExports } from "../_chunks/_libs/cloudinary.mjs";
import { F as FileQuestionMark, H as House } from "../_libs/lucide-react.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_libs/zod.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
const ThemeProviderContext = reactExports.createContext({
  theme: "system",
  setTheme: () => null
});
function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "campushub-theme"
}) {
  const [theme, setTheme] = reactExports.useState(() => {
    if (typeof window === "undefined") return defaultTheme;
    try {
      const stored = localStorage.getItem(storageKey);
      return stored ?? defaultTheme;
    } catch {
      return defaultTheme;
    }
  });
  reactExports.useEffect(() => {
    const root = window.document.documentElement;
    const resolved = theme === "system" ? window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light" : theme;
    if (!root.classList.contains(resolved)) {
      root.classList.remove("light", "dark");
      root.classList.add(resolved);
    }
  }, [theme]);
  const value = {
    theme,
    setTheme: (newTheme) => {
      localStorage.setItem(storageKey, newTheme);
      setTheme(newTheme);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeProviderContext.Provider, { value, children });
}
function useTheme() {
  const context = reactExports.useContext(ThemeProviderContext);
  if (context === void 0) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, loading, children, disabled, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Comp,
      {
        className: cn(buttonVariants({ variant, size, className })),
        ref,
        disabled: disabled || loading,
        ...props,
        children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "svg",
            {
              className: "animate-spin h-4 w-4",
              xmlns: "http://www.w3.org/2000/svg",
              fill: "none",
              viewBox: "0 0 24 24",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "circle",
                  {
                    className: "opacity-25",
                    cx: "12",
                    cy: "12",
                    r: "10",
                    stroke: "currentColor",
                    strokeWidth: "4"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "path",
                  {
                    className: "opacity-75",
                    fill: "currentColor",
                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                  }
                )
              ]
            }
          ),
          children
        ] }) : children
      }
    );
  }
);
Button.displayName = "Button";
const appCss = "/assets/styles-CxkMWm6Q.css";
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col items-center justify-center gap-6 p-4 bg-muted/30", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-20 w-20 items-center justify-center rounded-full bg-muted", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileQuestionMark, { className: "h-10 w-10 text-muted-foreground" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-bold", children: "Page not found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, className: "gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "h-4 w-4" }),
      "Back to Home"
    ] }) })
  ] });
}
const Route$D = createRootRoute({
  notFoundComponent: NotFoundComponent,
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "CampusHub - Academic Management System" },
      {
        name: "description",
        content: "A modern full-stack academic management system for universities and colleges."
      }
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=Inter:wght@300;400;500;600;700;800&display=swap"
      }
    ]
  }),
  component: RootComponent,
  shellComponent: RootDocument
});
function RootDocument({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", suppressHydrationWarning: true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("head", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "script",
        {
          dangerouslySetInnerHTML: {
            __html: `
              try {
                const theme = localStorage.getItem('campushub-theme');
                const isDark = theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches);
                document.documentElement.classList.add(isDark ? 'dark' : 'light');
              } catch (e) {}
            `
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {})
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { className: "min-h-screen bg-background text-foreground antialiased", children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(ThemeProvider, { defaultTheme: "system", storageKey: "campushub-theme", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Toaster,
      {
        position: "top-right",
        richColors: true,
        closeButton: true,
        toastOptions: {
          duration: 3e3
        }
      }
    )
  ] });
}
const createSsrRpc = (functionId, importer) => {
  const url = "/_serverFn/" + functionId;
  const serverFnMeta = { id: functionId };
  const fn = async (...args) => {
    const serverFn = await getServerFnById(functionId);
    return serverFn(...args);
  };
  return Object.assign(fn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const getSession = createServerFn({
  method: "GET"
}).handler(createSsrRpc("3371e9152efa504ad80eb9dab602b7aa7a1b3e29a8d33eb7d02a3331db1793b0"));
const loginAction = createServerFn({
  method: "POST"
}).inputValidator((data) => loginSchema.parse(data)).handler(createSsrRpc("1fc2b78f24004bcf959a71aecd98be95da1b6d6d790a26b949d3b8359eb7a853"));
const registerAction = createServerFn({
  method: "POST"
}).inputValidator((data) => registerSchema.parse(data)).handler(createSsrRpc("43a6492e0a1ad82b31d169e5e21da6e021a02ca51658015613954b019149e30a"));
const logoutAction = createServerFn({
  method: "POST"
}).handler(createSsrRpc("b134a94da9cdf8cd1d7c10e3a4739f3b43ba00b07adf2add0751d75e023d30fe"));
const changePasswordAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).inputValidator((data) => changePasswordSchema.parse(data)).handler(createSsrRpc("862731301a0699f12cd7566d1f4d830f2a3e8d7db7c8ca0a2c55f0ab6342c10c"));
const forgotPasswordAction = createServerFn({
  method: "POST"
}).inputValidator((data) => forgotPasswordSchema.parse(data)).handler(createSsrRpc("769ec723d51f50224802d9b6e2cae3f9c35c4be43e1c5469d351775506cc171a"));
const resetPasswordAction = createServerFn({
  method: "POST"
}).inputValidator((data) => resetPasswordSchema.parse(data)).handler(createSsrRpc("a2cb7ff49417ae30d2288557ef32e09d44d6d88079bb99c2dbc8ca9f5e099f3e"));
const resendVerificationEmailAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).handler(createSsrRpc("f6796a5d69fa587fd6c14e8dfa344ef6f3bb2e74f31f283d9405ce2a6fba369f"));
const $$splitComponentImporter$A = () => import("./terms-of-service-BuJnfmIA.mjs");
const Route$C = createFileRoute("/terms-of-service")({
  beforeLoad: async () => {
    const user = await getSession();
    return {
      user
    };
  },
  component: lazyRouteComponent($$splitComponentImporter$A, "component")
});
const ROLE_LABELS = {
  ADMIN: "Administrator",
  INSTRUCTOR: "Instructor",
  STUDENT: "Student"
};
const ROLE_DASHBOARD_PATHS = {
  ADMIN: "/admin",
  INSTRUCTOR: "/instructor",
  STUDENT: "/student"
};
const $$splitComponentImporter$z = () => import("./reset-password-2ZRWOBSq.mjs");
const Route$B = createFileRoute("/reset-password")({
  validateSearch: (search) => ({
    token: typeof search.token === "string" ? search.token : void 0
  }),
  beforeLoad: async () => {
    const user = await getSession();
    if (user) {
      throw redirect({
        to: ROLE_DASHBOARD_PATHS[user.role]
      });
    }
  },
  component: lazyRouteComponent($$splitComponentImporter$z, "component")
});
const $$splitComponentImporter$y = () => import("./register-7-nWeP9W.mjs");
const Route$A = createFileRoute("/register")({
  beforeLoad: async () => {
    const user = await getSession();
    if (user) {
      throw redirect({
        to: ROLE_DASHBOARD_PATHS[user.role]
      });
    }
  },
  component: lazyRouteComponent($$splitComponentImporter$y, "component")
});
const $$splitComponentImporter$x = () => import("./privacy-policy-DB5qM_GD.mjs");
const Route$z = createFileRoute("/privacy-policy")({
  beforeLoad: async () => {
    const user = await getSession();
    return {
      user
    };
  },
  component: lazyRouteComponent($$splitComponentImporter$x, "component")
});
function TableSkeleton({
  rows = 5,
  cols = 4,
  className
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn("w-full", className), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-4 border-b pb-3 mb-3", children: Array.from({ length: cols }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "h-4 bg-muted animate-pulse rounded flex-1"
      },
      `h-${i}`
    )) }),
    Array.from({ length: rows }).map((_, rowIdx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "flex gap-4 py-3 border-b border-muted/50",
        children: Array.from({ length: cols }).map((_2, colIdx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "h-4 bg-muted animate-pulse rounded flex-1",
            style: { animationDelay: `${(rowIdx + colIdx) * 100}ms` }
          },
          `c-${colIdx}`
        ))
      },
      `r-${rowIdx}`
    ))
  ] });
}
const getNotificationsAction = createServerFn({
  method: "GET"
}).middleware([authMiddleware]).handler(createSsrRpc("249bfa1ab6b136226c38fdf4e80f010a28cc820824051c432777e2b52f44749b"));
const getUnreadCountAction = createServerFn({
  method: "GET"
}).middleware([authMiddleware]).handler(createSsrRpc("22a533bbc9f89ec4423b30bf94853b23d130253cb0d703cb00f979498fe5686e"));
const markNotificationReadAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Notification ID is required");
  return parsed;
}).handler(createSsrRpc("c8a8d82718fdc162048ff23eca5b3771448bda863a57c4b9ebe6a9a62ead8d23"));
const markAllNotificationsReadAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).handler(createSsrRpc("8c2420d1dec316c78f5b7f42e6660db9222e2f718145a4ca64f0e5d409680d13"));
const listAnnouncementsAction = createServerFn({
  method: "GET"
}).middleware([authMiddleware]).handler(createSsrRpc("84b6b9a3459f859c6178b53d901f0cbb55d6d26544b3581a0e418680069e9683"));
const listAllAnnouncementsAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(createSsrRpc("b696228bce9cb00f685fc5b8084c0ef3e644dc737eaf36b0b70a2abd472285cf"));
const createAnnouncementAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createAnnouncementSchema.parse(data)).handler(createSsrRpc("80a05c721ed82ea6f61419cbae9f2ff31f86f2643d1291e5c5b2376966c97695"));
const updateAnnouncementAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateAnnouncementSchema.parse(data)).handler(createSsrRpc("0ad2230b2868467795caa203427b0e72e336df891d4aceef0a05ddbc2116edf7"));
const deleteAnnouncementAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Announcement ID is required");
  return parsed;
}).handler(createSsrRpc("c6287c9304ca945f185d6efa26127a07020faea4a3712915fc5dc441d27f6e0c"));
const $$splitComponentImporter$w = () => import("./news-DYCStof9.mjs");
const Route$y = createFileRoute("/news")({
  beforeLoad: async () => {
    const user = await getSession();
    if (!user) {
      throw redirect({
        to: "/login"
      });
    }
    return {
      user
    };
  },
  loader: async () => {
    const announcements = await listAnnouncementsAction();
    return {
      announcements
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 4, cols: 3 }) }),
  component: lazyRouteComponent($$splitComponentImporter$w, "component")
});
const $$splitComponentImporter$v = () => import("./login-jDclWMRj.mjs");
const Route$x = createFileRoute("/login")({
  beforeLoad: async () => {
    const user = await getSession();
    if (user) {
      throw redirect({
        to: ROLE_DASHBOARD_PATHS[user.role]
      });
    }
  },
  component: lazyRouteComponent($$splitComponentImporter$v, "component")
});
const $$splitComponentImporter$u = () => import("./forgot-password-DQzXRYAQ.mjs");
const Route$w = createFileRoute("/forgot-password")({
  beforeLoad: async () => {
    const user = await getSession();
    if (user) {
      throw redirect({
        to: ROLE_DASHBOARD_PATHS[user.role]
      });
    }
  },
  component: lazyRouteComponent($$splitComponentImporter$u, "component")
});
const $$splitComponentImporter$t = () => import("./dashboard-BTU5dmpx.mjs");
const Route$v = createFileRoute("/dashboard")({
  beforeLoad: async () => {
    const user = await getSession();
    if (!user) {
      throw redirect({
        to: "/login"
      });
    }
    throw redirect({
      to: ROLE_DASHBOARD_PATHS[user.role]
    });
  },
  component: lazyRouteComponent($$splitComponentImporter$t, "component")
});
const $$splitComponentImporter$s = () => import("./index-C2j5CSuK.mjs");
const Route$u = createFileRoute("/")({
  beforeLoad: async () => {
    const user = await getSession();
    return {
      user
    };
  },
  component: lazyRouteComponent($$splitComponentImporter$s, "component")
});
function CardSkeleton({ className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: cn(
        "rounded-lg border bg-card p-6 shadow-sm",
        className
      ),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 w-1/3 bg-muted animate-pulse rounded" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-8 w-1/2 bg-muted animate-pulse rounded" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-3 w-2/3 bg-muted animate-pulse rounded" })
      ] })
    }
  );
}
function StatsSkeleton({ count = 4, className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: cn(
        "grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
        className
      ),
      children: Array.from({ length: count }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {}, i))
    }
  );
}
async function requireAuth() {
  const user = await getSession();
  if (!user) throw redirect({ to: "/login" });
  return user;
}
async function requireAdmin() {
  const user = await requireAuth();
  if (user.role !== "ADMIN") throw redirect({ to: "/dashboard" });
  return user;
}
async function requireInstructor() {
  const user = await requireAuth();
  if (user.role !== "INSTRUCTOR") throw redirect({ to: "/dashboard" });
  return user;
}
async function requireStudent() {
  const user = await requireAuth();
  if (user.role !== "STUDENT") throw redirect({ to: "/dashboard" });
  return user;
}
const getAdminDashboardAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(createSsrRpc("4241717dddff692f1c510a57e93446024b3c329ccb1e4cd74bd885fd88d66ff2"));
const getStudentDashboardAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(createSsrRpc("311a0dae574090455fbdae778e0c39ef68b72fbc26582dbd2770b92d5c186c4d"));
const getInstructorDashboardAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).handler(createSsrRpc("a585870de6c2c99093caff11d5d17265418b24f6448596f0234a961ad425a889"));
const $$splitComponentImporter$r = () => import("./index-BI7tgzdE.mjs");
const Route$t = createFileRoute("/student/")({
  beforeLoad: async () => ({
    user: await requireStudent()
  }),
  loader: async () => {
    const stats = await getStudentDashboardAction();
    return {
      stats
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatsSkeleton, { count: 4 }) }),
  component: lazyRouteComponent($$splitComponentImporter$r, "component")
});
const $$splitComponentImporter$q = () => import("./index-9dFydLoA.mjs");
const Route$s = createFileRoute("/profile/")({
  beforeLoad: async () => ({
    user: await requireAuth()
  }),
  component: lazyRouteComponent($$splitComponentImporter$q, "component")
});
const $$splitComponentImporter$p = () => import("./index-Bia5Zk4Q.mjs");
const Route$r = createFileRoute("/instructor/")({
  beforeLoad: async () => ({
    user: await requireInstructor()
  }),
  loader: async () => {
    const stats = await getInstructorDashboardAction();
    return {
      stats
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatsSkeleton, { count: 4 }) }),
  component: lazyRouteComponent($$splitComponentImporter$p, "component")
});
const $$splitComponentImporter$o = () => import("./index-QUXU8SKv.mjs");
const Route$q = createFileRoute("/admin/")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const stats = await getAdminDashboardAction();
    return {
      stats
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatsSkeleton, { count: 4 }) }),
  component: lazyRouteComponent($$splitComponentImporter$o, "component")
});
function FormSkeleton({ fields = 4, className }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn("space-y-6", className), children: [
    Array.from({ length: fields }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "h-4 w-24 bg-muted animate-pulse rounded",
          style: { animationDelay: `${i * 100}ms` }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "h-10 w-full bg-muted animate-pulse rounded",
          style: { animationDelay: `${i * 100 + 50}ms` }
        }
      )
    ] }, i)),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-32 bg-muted animate-pulse rounded mt-4" })
  ] });
}
const getCourseGradingDataAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseId) throw new Error("Course ID is required");
  return parsed;
}).handler(createSsrRpc("b28c5a3ebc7c9e496a37f2a62e6012faf1afe8d1767c0cf4b29dfab21fc10c70"));
const saveCourseAssessmentsAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => saveAssessmentsSchema.parse(data)).handler(createSsrRpc("c68c971d8fcc272b6656f1fbbf9c3fbc3ceb181d3a2aa6d04c04b25a631e9953"));
const saveAssessmentScoresAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => saveScoresSchema.parse(data)).handler(createSsrRpc("21825f7f80042905195ed1bb495d9e99efa35ecdb7007b5708e6bbe3ae59f3ea"));
const submitGradeAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => submitGradeSchema.parse(data)).handler(createSsrRpc("bf6397dbe815c826e566b801c62b3a94d1fc23f43ea938195e22a37ccf113758"));
const updateGradeAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => submitGradeSchema.parse(data)).handler(createSsrRpc("21a1038707fb64906b3a6492dc2bf5667f816e1c96007ae1a1da13da315596e8"));
const getCourseGradesAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseId) throw new Error("Course ID is required");
  return parsed;
}).handler(createSsrRpc("2705d8a5439a8e8f3e28eed689a67a4db9ace9333cdf0671a9c1d5327d06ba99"));
const getInstructorStudentsAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).handler(createSsrRpc("d65d611ed28452d83db16c898e9257d6c08376a12cfa0678fbf896d474b3f986"));
const getTranscriptAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(createSsrRpc("270693b94f64ace4ee2d5a973c0d6d31ad358e74d9d07045324b756196a2aa59"));
const getStudentTranscriptAction = createServerFn({
  method: "POST"
}).middleware([staffMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed?.studentId) throw new Error("Student ID is required");
  return parsed;
}).handler(createSsrRpc("0cf4315e6281c9e10980f98ce9f055acb8ac51b0affaa4f5443f983d7b4b8e80"));
const bulkSubmitGradesAction = createServerFn({
  method: "POST"
}).middleware([instructorMiddleware]).inputValidator((data) => bulkGradeSchema.parse(data)).handler(createSsrRpc("0c3d12901aa4cecc3831709234039c4298b00e0c4de75957090cb22865074e1f"));
createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(createSsrRpc("86378e06d26d8880920ab7690beeb3ed37ce09f334a7df1a8a8914b22ea57c53"));
const $$splitComponentImporter$n = () => import("./transcript-CcnZs0Sv.mjs");
const Route$p = createFileRoute("/student/transcript")({
  beforeLoad: async () => ({
    user: await requireStudent()
  }),
  loader: async () => {
    const transcript = await getTranscriptAction();
    return {
      transcript
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FormSkeleton, { fields: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$n, "component")
});
const $$splitComponentImporter$m = () => import("./grades-ClfPKA70.mjs");
const Route$o = createFileRoute("/student/grades")({
  beforeLoad: async () => ({
    user: await requireStudent()
  }),
  loader: async () => {
    const transcript = await getTranscriptAction();
    return {
      transcript
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 5, cols: 5 }) }),
  component: lazyRouteComponent($$splitComponentImporter$m, "component")
});
const enrollAction = createServerFn({
  method: "POST"
}).middleware([studentMiddleware]).inputValidator((data) => enrollSchema.parse(data)).handler(createSsrRpc("cd24a0e03c85684621d7bd04bc76038683585685ff88cb6b8d43cd978f052788"));
const dropAction = createServerFn({
  method: "POST"
}).middleware([studentMiddleware]).inputValidator((data) => dropSchema.parse(data)).handler(createSsrRpc("31056efa21668ce31615531eb3d83fb427bf95dfa2c445b79413bf0e95a8e715"));
createServerFn({
  method: "POST"
}).middleware([studentMiddleware]).inputValidator((data) => dropSchema.parse(data)).handler(createSsrRpc("c93562cbf035e3663ab758a7d4563f23de1f488d0a39227a10a50f48881f3266"));
const getStudentEnrollmentsAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(createSsrRpc("7974daa4b3e3b441dd33de5179985efe805d23c565c078507d0892187ca702ba"));
const $$splitComponentImporter$l = () => import("./enrollment-Dc1nwaaN.mjs");
const Route$n = createFileRoute("/student/enrollment")({
  beforeLoad: async () => ({
    user: await requireStudent()
  }),
  loader: async () => {
    const enrollments = await getStudentEnrollmentsAction();
    return {
      enrollments
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 5, cols: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$l, "component")
});
const listCoursesAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => courseListFiltersSchema.parse(data)).handler(createSsrRpc("89d0eac46cf2a30cbefcdf12bb8e1589afb4c47fe34188957786a61fb4d0e772"));
const createCourseAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createCourseSchema.parse(data)).handler(createSsrRpc("2d91f84c7988949e1a65bf760d8d1d390a00d22b37c6d97619e3634ec398e6de"));
const updateCourseAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateCourseSchema.parse(data)).handler(createSsrRpc("b6bd1bbb785f2cf30fec61de7100948c6d4a937f50a3f790801f8a2d13957915"));
const assignInstructorAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => assignInstructorSchema.parse(data)).handler(createSsrRpc("9f8deeee7f16bc119fb2f3707ecfc4cd38916b864aff013e6e5e9450fbebaade"));
const removeInstructorAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseId || !parsed.instructorId) throw new Error("Invalid input");
  return parsed;
}).handler(createSsrRpc("41b7c5098198af2a6b787a7080cbb18c5575f37dda4f846e3d8484cdef61a68c"));
createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Course ID is required");
  return parsed;
}).handler(createSsrRpc("6d4db7a6f0e17194c8160ba6d1d3f3d5cf5e1d691d8813f10a86f2e9e03613e4"));
const getCourseDetailAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Course ID is required");
  return parsed;
}).handler(createSsrRpc("791591abb8f80b9b64c72cff0785b1fa2d92ea7d40b7ebbe8a3af1a65b99c2fe"));
const getInstructorCoursesAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).handler(createSsrRpc("3935a70ea8d99a1fa3ff30072b2ce5527569aae6f2495750944fd04685201fb3"));
const getInstructorCourseDetailAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Course ID is required");
  return parsed;
}).handler(createSsrRpc("1b0dbefaa552c4d1b08293494fd27ca0d49ec3c7e0d5ad57fb1ad886bea4f5a8"));
const getCourseCatalogAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).inputValidator((data) => {
  const parsed = data;
  return parsed || {};
}).handler(createSsrRpc("e6e42c858ab32014e131535b48a33a6ec98e42edcf1d6ec932e68fe2b08ee400"));
const listSemestersAction = createServerFn({
  method: "GET"
}).handler(createSsrRpc("2ad86fda792ecbf3746de0cfafeb88b95b4cdf238c34c6101110d54c953c28eb"));
const getSemesterDetailAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Semester ID is required");
  return parsed;
}).handler(createSsrRpc("953e31a563fd7cde17d3b4ef3f36b85ddbff8a70595ce02610470cc666ba9dc8"));
const createSemesterAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createSemesterSchema.parse(data)).handler(createSsrRpc("584b6aa9638085acb6fbcaff9b964237c4777b6cbe2d4b70ac329e9972b92f23"));
const updateSemesterAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateSemesterSchema.parse(data)).handler(createSsrRpc("2a93a65798c00954ca1e2744b9899351b5a1ba5e496c457079ad4a75ef6a7004"));
const $$splitComponentImporter$k = () => import("./courses-Crs4mpP3.mjs");
const Route$m = createFileRoute("/student/courses")({
  beforeLoad: async () => ({
    user: await requireStudent()
  }),
  loader: async () => {
    const courses = await getCourseCatalogAction({
      data: {}
    });
    return {
      courses
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatsSkeleton, { count: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$k, "component")
});
const $$splitComponentImporter$j = () => import("./calendar-YNfbRp3T.mjs");
const Route$l = createFileRoute("/student/calendar")({
  beforeLoad: async () => ({
    user: await requireStudent()
  }),
  loader: async () => {
    const semesters = await listSemestersAction();
    return {
      semesters
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {})
  ] }),
  component: lazyRouteComponent($$splitComponentImporter$j, "component")
});
const $$splitComponentImporter$i = () => import("./password-CowXido8.mjs");
const Route$k = createFileRoute("/profile/password")({
  beforeLoad: async () => ({
    user: await requireAuth()
  }),
  component: lazyRouteComponent($$splitComponentImporter$i, "component")
});
const $$splitComponentImporter$h = () => import("./transcripts-C172pc2M.mjs");
const Route$j = createFileRoute("/instructor/transcripts")({
  beforeLoad: async () => ({
    user: await requireInstructor()
  }),
  loader: async () => {
    const students = await getInstructorStudentsAction();
    return {
      students
    };
  },
  component: lazyRouteComponent($$splitComponentImporter$h, "component")
});
const $$splitComponentImporter$g = () => import("./courses-BFsOu0JM.mjs");
const Route$i = createFileRoute("/instructor/courses")({
  component: lazyRouteComponent($$splitComponentImporter$g, "component")
});
const $$splitComponentImporter$f = () => import("./calendar-C5j181I-.mjs");
const Route$h = createFileRoute("/instructor/calendar")({
  beforeLoad: async () => ({
    user: await requireInstructor()
  }),
  loader: async () => {
    const semesters = await listSemestersAction();
    return {
      semesters
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {})
  ] }),
  component: lazyRouteComponent($$splitComponentImporter$f, "component")
});
const $$splitComponentImporter$e = () => import("./users-BFsOu0JM.mjs");
const Route$g = createFileRoute("/admin/users")({
  component: lazyRouteComponent($$splitComponentImporter$e, "component")
});
const listUsersAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => userListFiltersSchema.parse(data)).handler(createSsrRpc("b7696922eb2a9b4b534965e82b8dbc591fb7480c15a4911ce8c8f8eb6ec6d84d"));
const getUserDetailAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("User ID is required");
  return parsed;
}).handler(createSsrRpc("e6165ffadd665440f233c6dcdabad7ee5acec2dddf768cad9cbd3263669f5f31"));
const createUserAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createUserSchema.parse(data)).handler(createSsrRpc("3051a517b703384fb169c2458f9993be9e13aeef758c48f794f23cc3e01ee64b"));
const updateUserAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateUserSchema.parse(data)).handler(createSsrRpc("3a59b41934309245ebe39c5ffc725bce70819d69088f9c7c32959f9b958a2f93"));
const deactivateUserAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("User ID is required");
  return parsed;
}).handler(createSsrRpc("d8fd2a3b13c2cd23962fa7e7d22eaab6db1db56576ea23ad049142f16c69c5c3"));
const updateProfileAction = createServerFn({
  method: "POST"
}).middleware([authMiddleware]).inputValidator((data) => updateProfileSchema.parse(data)).handler(createSsrRpc("6f44cebbfa92944baa2c11f0a67a9a9c62430b1ff9353369b7ad7ce54f12e3af"));
const listInstructorsAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(createSsrRpc("ff0b6c6a19031f0571921308251dc45447ba423cb1dc67f2e04eabd66b402550"));
const $$splitComponentImporter$d = () => import("./transcripts-B9ivMysM.mjs");
const Route$f = createFileRoute("/admin/transcripts")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const data = await listUsersAction({
      data: {
        page: 1,
        pageSize: 100,
        role: "STUDENT"
      }
    });
    return {
      students: data
    };
  },
  component: lazyRouteComponent($$splitComponentImporter$d, "component")
});
const $$splitComponentImporter$c = () => import("./semesters-BFsOu0JM.mjs");
const Route$e = createFileRoute("/admin/semesters")({
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./courses-DWQrCpgz.mjs");
const Route$d = createFileRoute("/admin/courses")({
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
const $$splitComponentImporter$a = () => import("./calendar-C4L9aysd.mjs");
const Route$c = createFileRoute("/admin/calendar")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const semesters = await listSemestersAction();
    return {
      semesters
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-8 space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardSkeleton, {})
  ] }),
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./announcements-Dc2VUBhT.mjs");
const Route$b = createFileRoute("/admin/announcements")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const announcements = await listAllAnnouncementsAction();
    return {
      announcements
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 5, cols: 5 }) }),
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./courses.index-tTW3h1f2.mjs");
const Route$a = createFileRoute("/instructor/courses/")({
  beforeLoad: async () => ({
    user: await requireInstructor()
  }),
  loader: async () => {
    const courses = await getInstructorCoursesAction();
    return {
      courses
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(StatsSkeleton, { count: 4 }) }),
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./users.index-BXyZ_Rdi.mjs");
const Route$9 = createFileRoute("/admin/users/")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const data = await listUsersAction({
      data: {
        page: 1,
        pageSize: 10
      }
    });
    return {
      users: data
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 8, cols: 5 }) }),
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./semesters.index-By388dj2.mjs");
const Route$8 = createFileRoute("/admin/semesters/")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const semesters = await listSemestersAction();
    return {
      semesters
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 5, cols: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./courses.index-DYzLUlah.mjs");
const Route$7 = createFileRoute("/admin/courses/")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async () => {
    const [courses, semesters] = await Promise.all([listCoursesAction({
      data: {
        page: 1,
        pageSize: 20
      }
    }), listSemestersAction()]);
    return {
      courses,
      semesters
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 8, cols: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./grades._courseId-CdI8mDJh.mjs");
const Route$6 = createFileRoute("/instructor/grades/$courseId")({
  beforeLoad: async () => ({
    user: await requireInstructor()
  }),
  loader: async ({
    params
  }) => {
    const data = await getCourseGradingDataAction({
      data: {
        courseId: params.courseId
      }
    });
    return {
      ...data,
      courseId: params.courseId
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 8, cols: 5 }) }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./courses._id-CJrIHXgm.mjs");
const Route$5 = createFileRoute("/instructor/courses/$id")({
  beforeLoad: async () => ({
    user: await requireInstructor()
  }),
  loader: async ({
    params
  }) => {
    const [course, students] = await Promise.all([getInstructorCourseDetailAction({
      data: {
        id: params.id
      }
    }), getCourseGradesAction({
      data: {
        courseId: params.id
      }
    })]);
    return {
      course,
      students
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TableSkeleton, { rows: 8, cols: 5 }) }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
const apiKey = process.env.CLOUDINARY_API_KEY;
const apiSecret = process.env.CLOUDINARY_API_SECRET;
if (cloudName && apiKey && apiSecret) {
  cloudinaryExports.v2.config({
    cloud_name: cloudName,
    api_key: apiKey,
    api_secret: apiSecret
  });
}
async function uploadToCloudinary(buffer, options = {}) {
  if (!cloudName || !apiKey || !apiSecret) {
    return null;
  }
  try {
    const result = await new Promise((resolve, reject) => {
      cloudinaryExports.v2.uploader.upload_stream(
        {
          resource_type: options.resourceType ?? "auto",
          folder: options.folder ?? "campushub/announcements",
          public_id: options.publicId
        },
        (err, res) => {
          if (err) reject(err);
          else if (res) resolve(res);
          else reject(new Error("Upload failed"));
        }
      ).end(buffer);
    });
    return result.secure_url;
  } catch {
    return null;
  }
}
const MAX_FILE_SIZE = 150 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/webm", "video/quicktime"];
const Route$4 = createFileRoute("/api/upload/file")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const session = await auth.api.getSession({ headers: getRequestHeaders() });
          if (!session?.user) {
            return new Response(JSON.stringify({ error: "Unauthorized" }), {
              status: 401,
              headers: { "Content-Type": "application/json" }
            });
          }
          const user = session.user;
          if (user.role !== "ADMIN") {
            return new Response(JSON.stringify({ error: "Forbidden" }), {
              status: 403,
              headers: { "Content-Type": "application/json" }
            });
          }
          const formData = await request.formData();
          const file = formData.get("file");
          const resourceType = formData.get("resourceType") || "auto";
          if (!file || !(file instanceof File)) {
            return new Response(
              JSON.stringify({ error: "No file provided" }),
              { status: 400, headers: { "Content-Type": "application/json" } }
            );
          }
          if (file.size > MAX_FILE_SIZE) {
            return new Response(
              JSON.stringify({ error: "File too large (max 150MB)" }),
              { status: 400, headers: { "Content-Type": "application/json" } }
            );
          }
          const type = resourceType === "video" ? "video" : "image";
          const allowed = type === "video" ? ALLOWED_VIDEO_TYPES : ALLOWED_IMAGE_TYPES;
          if (!allowed.includes(file.type)) {
            return new Response(
              JSON.stringify({
                error: `Invalid file type. Allowed: ${allowed.join(", ")}`
              }),
              { status: 400, headers: { "Content-Type": "application/json" } }
            );
          }
          const arrayBuffer = await file.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          const url = await uploadToCloudinary(buffer, {
            resourceType: type,
            folder: "campushub/announcements"
          });
          if (!url) {
            return new Response(
              JSON.stringify({ error: "Upload failed. Check Cloudinary configuration." }),
              { status: 500, headers: { "Content-Type": "application/json" } }
            );
          }
          return new Response(JSON.stringify({ url }), {
            status: 200,
            headers: { "Content-Type": "application/json" }
          });
        } catch (err) {
          console.error("[Upload]", err);
          return new Response(
            JSON.stringify({ error: "Upload failed" }),
            { status: 500, headers: { "Content-Type": "application/json" } }
          );
        }
      }
    }
  }
});
const Route$3 = createFileRoute("/api/auth/$")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        return await auth.handler(request);
      },
      POST: async ({ request }) => {
        return await auth.handler(request);
      }
    }
  }
});
const $$splitComponentImporter$2 = () => import("./users._id-jLYvWbIf.mjs");
const Route$2 = createFileRoute("/admin/users/$id")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async ({
    params
  }) => {
    const userDetail = await getUserDetailAction({
      data: {
        id: params.id
      }
    });
    return {
      userDetail
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FormSkeleton, { fields: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./semesters._id-D8x0gruX.mjs");
const Route$1 = createFileRoute("/admin/semesters/$id")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async ({
    params
  }) => {
    const [semester, courses] = await Promise.all([getSemesterDetailAction({
      data: {
        id: params.id
      }
    }), listCoursesAction({
      data: {
        page: 1,
        pageSize: 50,
        semesterId: params.id
      }
    })]);
    return {
      semester,
      courses
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FormSkeleton, { fields: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./courses._id-C9RZylHM.mjs");
const Route = createFileRoute("/admin/courses/$id")({
  beforeLoad: async () => ({
    user: await requireAdmin()
  }),
  loader: async ({
    params
  }) => {
    const [course, instructors] = await Promise.all([getCourseDetailAction({
      data: {
        id: params.id
      }
    }), listInstructorsAction()]);
    return {
      course,
      instructors
    };
  },
  pendingComponent: () => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FormSkeleton, { fields: 6 }) }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const TermsOfServiceRoute = Route$C.update({
  id: "/terms-of-service",
  path: "/terms-of-service",
  getParentRoute: () => Route$D
});
const ResetPasswordRoute = Route$B.update({
  id: "/reset-password",
  path: "/reset-password",
  getParentRoute: () => Route$D
});
const RegisterRoute = Route$A.update({
  id: "/register",
  path: "/register",
  getParentRoute: () => Route$D
});
const PrivacyPolicyRoute = Route$z.update({
  id: "/privacy-policy",
  path: "/privacy-policy",
  getParentRoute: () => Route$D
});
const NewsRoute = Route$y.update({
  id: "/news",
  path: "/news",
  getParentRoute: () => Route$D
});
const LoginRoute = Route$x.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$D
});
const ForgotPasswordRoute = Route$w.update({
  id: "/forgot-password",
  path: "/forgot-password",
  getParentRoute: () => Route$D
});
const DashboardRoute = Route$v.update({
  id: "/dashboard",
  path: "/dashboard",
  getParentRoute: () => Route$D
});
const IndexRoute = Route$u.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$D
});
const StudentIndexRoute = Route$t.update({
  id: "/student/",
  path: "/student/",
  getParentRoute: () => Route$D
});
const ProfileIndexRoute = Route$s.update({
  id: "/profile/",
  path: "/profile/",
  getParentRoute: () => Route$D
});
const InstructorIndexRoute = Route$r.update({
  id: "/instructor/",
  path: "/instructor/",
  getParentRoute: () => Route$D
});
const AdminIndexRoute = Route$q.update({
  id: "/admin/",
  path: "/admin/",
  getParentRoute: () => Route$D
});
const StudentTranscriptRoute = Route$p.update({
  id: "/student/transcript",
  path: "/student/transcript",
  getParentRoute: () => Route$D
});
const StudentGradesRoute = Route$o.update({
  id: "/student/grades",
  path: "/student/grades",
  getParentRoute: () => Route$D
});
const StudentEnrollmentRoute = Route$n.update({
  id: "/student/enrollment",
  path: "/student/enrollment",
  getParentRoute: () => Route$D
});
const StudentCoursesRoute = Route$m.update({
  id: "/student/courses",
  path: "/student/courses",
  getParentRoute: () => Route$D
});
const StudentCalendarRoute = Route$l.update({
  id: "/student/calendar",
  path: "/student/calendar",
  getParentRoute: () => Route$D
});
const ProfilePasswordRoute = Route$k.update({
  id: "/profile/password",
  path: "/profile/password",
  getParentRoute: () => Route$D
});
const InstructorTranscriptsRoute = Route$j.update({
  id: "/instructor/transcripts",
  path: "/instructor/transcripts",
  getParentRoute: () => Route$D
});
const InstructorCoursesRoute = Route$i.update({
  id: "/instructor/courses",
  path: "/instructor/courses",
  getParentRoute: () => Route$D
});
const InstructorCalendarRoute = Route$h.update({
  id: "/instructor/calendar",
  path: "/instructor/calendar",
  getParentRoute: () => Route$D
});
const AdminUsersRoute = Route$g.update({
  id: "/admin/users",
  path: "/admin/users",
  getParentRoute: () => Route$D
});
const AdminTranscriptsRoute = Route$f.update({
  id: "/admin/transcripts",
  path: "/admin/transcripts",
  getParentRoute: () => Route$D
});
const AdminSemestersRoute = Route$e.update({
  id: "/admin/semesters",
  path: "/admin/semesters",
  getParentRoute: () => Route$D
});
const AdminCoursesRoute = Route$d.update({
  id: "/admin/courses",
  path: "/admin/courses",
  getParentRoute: () => Route$D
});
const AdminCalendarRoute = Route$c.update({
  id: "/admin/calendar",
  path: "/admin/calendar",
  getParentRoute: () => Route$D
});
const AdminAnnouncementsRoute = Route$b.update({
  id: "/admin/announcements",
  path: "/admin/announcements",
  getParentRoute: () => Route$D
});
const InstructorCoursesIndexRoute = Route$a.update({
  id: "/",
  path: "/",
  getParentRoute: () => InstructorCoursesRoute
});
const AdminUsersIndexRoute = Route$9.update({
  id: "/",
  path: "/",
  getParentRoute: () => AdminUsersRoute
});
const AdminSemestersIndexRoute = Route$8.update({
  id: "/",
  path: "/",
  getParentRoute: () => AdminSemestersRoute
});
const AdminCoursesIndexRoute = Route$7.update({
  id: "/",
  path: "/",
  getParentRoute: () => AdminCoursesRoute
});
const InstructorGradesCourseIdRoute = Route$6.update({
  id: "/instructor/grades/$courseId",
  path: "/instructor/grades/$courseId",
  getParentRoute: () => Route$D
});
const InstructorCoursesIdRoute = Route$5.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => InstructorCoursesRoute
});
const ApiUploadFileRoute = Route$4.update({
  id: "/api/upload/file",
  path: "/api/upload/file",
  getParentRoute: () => Route$D
});
const ApiAuthSplatRoute = Route$3.update({
  id: "/api/auth/$",
  path: "/api/auth/$",
  getParentRoute: () => Route$D
});
const AdminUsersIdRoute = Route$2.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => AdminUsersRoute
});
const AdminSemestersIdRoute = Route$1.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => AdminSemestersRoute
});
const AdminCoursesIdRoute = Route.update({
  id: "/$id",
  path: "/$id",
  getParentRoute: () => AdminCoursesRoute
});
const AdminCoursesRouteChildren = {
  AdminCoursesIdRoute,
  AdminCoursesIndexRoute
};
const AdminCoursesRouteWithChildren = AdminCoursesRoute._addFileChildren(
  AdminCoursesRouteChildren
);
const AdminSemestersRouteChildren = {
  AdminSemestersIdRoute,
  AdminSemestersIndexRoute
};
const AdminSemestersRouteWithChildren = AdminSemestersRoute._addFileChildren(
  AdminSemestersRouteChildren
);
const AdminUsersRouteChildren = {
  AdminUsersIdRoute,
  AdminUsersIndexRoute
};
const AdminUsersRouteWithChildren = AdminUsersRoute._addFileChildren(
  AdminUsersRouteChildren
);
const InstructorCoursesRouteChildren = {
  InstructorCoursesIdRoute,
  InstructorCoursesIndexRoute
};
const InstructorCoursesRouteWithChildren = InstructorCoursesRoute._addFileChildren(InstructorCoursesRouteChildren);
const rootRouteChildren = {
  IndexRoute,
  DashboardRoute,
  ForgotPasswordRoute,
  LoginRoute,
  NewsRoute,
  PrivacyPolicyRoute,
  RegisterRoute,
  ResetPasswordRoute,
  TermsOfServiceRoute,
  AdminAnnouncementsRoute,
  AdminCalendarRoute,
  AdminCoursesRoute: AdminCoursesRouteWithChildren,
  AdminSemestersRoute: AdminSemestersRouteWithChildren,
  AdminTranscriptsRoute,
  AdminUsersRoute: AdminUsersRouteWithChildren,
  InstructorCalendarRoute,
  InstructorCoursesRoute: InstructorCoursesRouteWithChildren,
  InstructorTranscriptsRoute,
  ProfilePasswordRoute,
  StudentCalendarRoute,
  StudentCoursesRoute,
  StudentEnrollmentRoute,
  StudentGradesRoute,
  StudentTranscriptRoute,
  AdminIndexRoute,
  InstructorIndexRoute,
  ProfileIndexRoute,
  StudentIndexRoute,
  ApiAuthSplatRoute,
  ApiUploadFileRoute,
  InstructorGradesCourseIdRoute
};
const routeTree = Route$D._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const router2 = createRouter({
    routeTree,
    context: {},
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  useTheme as $,
  cn as A,
  Button as B,
  buttonVariants as C,
  Route$h as D,
  Route$f as E,
  listUsersAction as F,
  Route$c as G,
  Route$a as H,
  Route$9 as I,
  createUserAction as J,
  updateUserAction as K,
  Route$8 as L,
  createSemesterAction as M,
  updateSemesterAction as N,
  listSemestersAction as O,
  Route$7 as P,
  createCourseAction as Q,
  Route$C as R,
  listCoursesAction as S,
  Route$5 as T,
  Route$2 as U,
  getUserDetailAction as V,
  deactivateUserAction as W,
  Route$1 as X,
  getSemesterDetailAction as Y,
  logoutAction as Z,
  Route$t as _,
  ROLE_DASHBOARD_PATHS as a,
  Route$b as a0,
  updateAnnouncementAction as a1,
  createAnnouncementAction as a2,
  deleteAnnouncementAction as a3,
  listAllAnnouncementsAction as a4,
  Route$6 as a5,
  bulkSubmitGradesAction as a6,
  saveCourseAssessmentsAction as a7,
  saveAssessmentScoresAction as a8,
  updateGradeAction as a9,
  submitGradeAction as aa,
  getCourseGradingDataAction as ab,
  createSsrRpc as ac,
  Route as ad,
  assignInstructorAction as ae,
  updateCourseAction as af,
  removeInstructorAction as ag,
  getCourseDetailAction as ah,
  getNotificationsAction as ai,
  getUnreadCountAction as aj,
  markAllNotificationsReadAction as ak,
  markNotificationReadAction as al,
  resendVerificationEmailAction as am,
  Route$u as an,
  router as ao,
  Route$B as b,
  registerAction as c,
  Route$z as d,
  Route$y as e,
  forgotPasswordAction as f,
  Route$s as g,
  ROLE_LABELS as h,
  Route$r as i,
  Route$q as j,
  Route$p as k,
  loginAction as l,
  Route$o as m,
  Route$n as n,
  dropAction as o,
  getStudentEnrollmentsAction as p,
  Route$m as q,
  resetPasswordAction as r,
  getCourseCatalogAction as s,
  enrollAction as t,
  updateProfileAction as u,
  Route$l as v,
  Route$k as w,
  changePasswordAction as x,
  Route$j as y,
  getStudentTranscriptAction as z
};
