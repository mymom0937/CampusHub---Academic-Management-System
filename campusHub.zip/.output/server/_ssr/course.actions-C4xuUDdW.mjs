import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { a as adminMiddleware, t as toAppError, i as instructorMiddleware, s as studentMiddleware, A as AppError, p as prisma } from "./middleware-DiEMT5y4.mjs";
import { l as listCourses$1, c as createCourse$1, f as findCourseById, u as updateCourse$1, a as assignInstructor$1, r as removeInstructor$1, b as archiveCourse$1, d as findCoursesByInstructor, e as findCourseCatalog } from "./course.repository-DNbUwZlZ.mjs";
import { f as findSemesterById, a as findActiveSemester, l as listSemesters$1, b as findSemesterByCode, c as createSemester$1, u as updateSemester$1 } from "./semester.repository-wa0iGq7i.mjs";
import { findUserById } from "./user.repository-02e89y02.mjs";
import { c as courseListFiltersSchema, a as createCourseSchema, u as updateCourseSchema, b as assignInstructorSchema, d as createSemesterSchema, e as updateSemesterSchema } from "./course.schema-DAXkVW6U.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
async function createCourse(input) {
  const semester = await findSemesterById(input.semesterId);
  if (!semester) {
    throw new AppError("NOT_FOUND", "Semester not found");
  }
  const course = await createCourse$1(input);
  const full = await findCourseById(course.id);
  if (!full) throw new AppError("INTERNAL_ERROR", "Failed to create course");
  return mapCourseToDto(full);
}
async function updateCourse(input) {
  const existing = await findCourseById(input.id);
  if (!existing) {
    throw new AppError("NOT_FOUND", "Course not found");
  }
  await updateCourse$1(input.id, {
    ...input.name && { name: input.name },
    ...input.description !== void 0 && { description: input.description },
    ...input.credits && { credits: input.credits },
    ...input.capacity && { capacity: input.capacity }
  });
  const updated = await findCourseById(input.id);
  if (!updated) throw new AppError("INTERNAL_ERROR", "Failed to update course");
  return mapCourseToDto(updated);
}
async function listCourses(params) {
  const { items, total } = await listCourses$1(params);
  return {
    items: items.map(mapCourseToDto),
    total,
    page: params.page,
    pageSize: params.pageSize,
    totalPages: Math.ceil(total / params.pageSize)
  };
}
async function assignInstructor(input) {
  const course = await findCourseById(input.courseId);
  if (!course) throw new AppError("NOT_FOUND", "Course not found");
  const instructor = await findUserById(input.instructorId);
  if (!instructor || instructor.role !== "INSTRUCTOR") {
    throw new AppError("NOT_FOUND", "Instructor not found");
  }
  try {
    await assignInstructor$1(input);
  } catch {
    throw new AppError("CONFLICT", "Instructor is already assigned to this course");
  }
}
async function removeInstructor(courseId, instructorId) {
  try {
    await removeInstructor$1(courseId, instructorId);
  } catch {
    throw new AppError("NOT_FOUND", "Assignment not found");
  }
}
async function archiveCourse(id) {
  const existing = await findCourseById(id);
  if (!existing) {
    throw new AppError("NOT_FOUND", "Course not found");
  }
  await archiveCourse$1(id);
}
async function getCourseDetail(id) {
  const course = await findCourseById(id);
  if (!course) throw new AppError("NOT_FOUND", "Course not found");
  return mapCourseToDto(course);
}
async function getInstructorCourses(instructorId) {
  const courses = await findCoursesByInstructor(instructorId);
  return courses.map(mapCourseToDto);
}
async function getInstructorCourseDetail(instructorId, courseId) {
  const course = await findCourseById(courseId);
  if (!course) throw new AppError("NOT_FOUND", "Course not found");
  const isAssigned = course.instructorAssignments.some(
    (a) => a.instructor.id === instructorId
  );
  if (!isAssigned) {
    throw new AppError("FORBIDDEN", "You are not assigned to this course");
  }
  return mapCourseToDto(course);
}
async function getCourseCatalog(search, studentId) {
  const activeSemester = await findActiveSemester();
  if (!activeSemester) return [];
  const courses = await findCourseCatalog(activeSemester.id, search);
  let enrolledCourseIds = /* @__PURE__ */ new Set();
  let waitlistedMap = /* @__PURE__ */ new Map();
  let waitlistCounts = /* @__PURE__ */ new Map();
  if (studentId) {
    const courseIds = courses.map((c) => c.id);
    const studentEnrollments = await prisma.enrollment.findMany({
      where: {
        studentId,
        status: { in: ["ENROLLED", "WAITLISTED"] },
        courseId: { in: courseIds }
      },
      select: { courseId: true, status: true }
    });
    enrolledCourseIds = new Set(
      studentEnrollments.filter((e) => e.status === "ENROLLED").map((e) => e.courseId)
    );
    const waitlistedCourseIds = studentEnrollments.filter((e) => e.status === "WAITLISTED").map((e) => e.courseId);
    for (const cId of waitlistedCourseIds) {
      const allWaitlisted = await prisma.enrollment.findMany({
        where: { courseId: cId, status: "WAITLISTED" },
        orderBy: { enrolledAt: "asc" },
        select: { studentId: true }
      });
      const pos = allWaitlisted.findIndex((w) => w.studentId === studentId);
      if (pos >= 0) waitlistedMap.set(cId, pos + 1);
    }
    const waitlistCountsRaw = await prisma.enrollment.groupBy({
      by: ["courseId"],
      where: { courseId: { in: courseIds }, status: "WAITLISTED" },
      _count: { courseId: true }
    });
    for (const wc of waitlistCountsRaw) {
      waitlistCounts.set(wc.courseId, wc._count.courseId);
    }
  }
  return courses.map((course) => ({
    ...mapCourseToDto(course),
    isEnrolled: enrolledCourseIds.has(course.id),
    isWaitlisted: waitlistedMap.has(course.id),
    waitlistPosition: waitlistedMap.get(course.id),
    waitlistCount: waitlistCounts.get(course.id) || 0
  }));
}
async function getSemesterDetail(id) {
  const semester = await findSemesterById(id);
  if (!semester) throw new AppError("NOT_FOUND", "Semester not found");
  return mapSemesterToDto(semester);
}
async function createSemester(input) {
  const existing = await findSemesterByCode(input.code);
  if (existing) {
    throw new AppError("CONFLICT", "A semester with this code already exists");
  }
  const semester = await createSemester$1(input);
  const full = await findSemesterById(semester.id);
  if (!full) throw new AppError("INTERNAL_ERROR", "Failed to create semester");
  return mapSemesterToDto(full);
}
async function updateSemester(input) {
  const existing = await findSemesterById(input.id);
  if (!existing) {
    throw new AppError("NOT_FOUND", "Semester not found");
  }
  await updateSemester$1(input.id, {
    ...input.name && { name: input.name },
    ...input.startDate && { startDate: input.startDate },
    ...input.endDate && { endDate: input.endDate },
    ...input.enrollmentStart && { enrollmentStart: input.enrollmentStart },
    ...input.enrollmentEnd && { enrollmentEnd: input.enrollmentEnd },
    ...input.dropDeadline && { dropDeadline: input.dropDeadline },
    ...input.isActive !== void 0 && { isActive: input.isActive }
  });
  const updated = await findSemesterById(input.id);
  if (!updated) throw new AppError("INTERNAL_ERROR", "Failed to update semester");
  return mapSemesterToDto(updated);
}
async function listSemesters() {
  const semesters = await listSemesters$1();
  return semesters.map(mapSemesterToDto);
}
function mapCourseToDto(course) {
  return {
    id: course.id,
    code: course.code,
    name: course.name,
    description: course.description,
    credits: course.credits,
    capacity: course.capacity,
    enrolledCount: course._count.enrollments,
    semesterName: course.semester.name,
    semesterId: course.semester.id,
    instructors: course.instructorAssignments.map((a) => ({
      id: a.instructor.id,
      firstName: a.instructor.firstName,
      lastName: a.instructor.lastName,
      isPrimary: a.isPrimary
    }))
  };
}
function mapSemesterToDto(semester) {
  return {
    id: semester.id,
    name: semester.name,
    code: semester.code,
    startDate: semester.startDate.toISOString(),
    endDate: semester.endDate.toISOString(),
    isActive: semester.isActive,
    enrollmentStart: semester.enrollmentStart.toISOString(),
    enrollmentEnd: semester.enrollmentEnd.toISOString(),
    dropDeadline: semester.dropDeadline.toISOString(),
    courseCount: semester._count.courses
  };
}
const listCoursesAction_createServerFn_handler = createServerRpc({
  id: "89d0eac46cf2a30cbefcdf12bb8e1589afb4c47fe34188957786a61fb4d0e772",
  name: "listCoursesAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => listCoursesAction.__executeServer(opts));
const listCoursesAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => courseListFiltersSchema.parse(data)).handler(listCoursesAction_createServerFn_handler, async ({
  data
}) => {
  return listCourses(data);
});
const createCourseAction_createServerFn_handler = createServerRpc({
  id: "2d91f84c7988949e1a65bf760d8d1d390a00d22b37c6d97619e3634ec398e6de",
  name: "createCourseAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => createCourseAction.__executeServer(opts));
const createCourseAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createCourseSchema.parse(data)).handler(createCourseAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const course = await createCourse(data);
    return {
      success: true,
      data: course
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const updateCourseAction_createServerFn_handler = createServerRpc({
  id: "b6bd1bbb785f2cf30fec61de7100948c6d4a937f50a3f790801f8a2d13957915",
  name: "updateCourseAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => updateCourseAction.__executeServer(opts));
const updateCourseAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateCourseSchema.parse(data)).handler(updateCourseAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const course = await updateCourse(data);
    return {
      success: true,
      data: course
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const assignInstructorAction_createServerFn_handler = createServerRpc({
  id: "9f8deeee7f16bc119fb2f3707ecfc4cd38916b864aff013e6e5e9450fbebaade",
  name: "assignInstructorAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => assignInstructorAction.__executeServer(opts));
const assignInstructorAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => assignInstructorSchema.parse(data)).handler(assignInstructorAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await assignInstructor(data);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const removeInstructorAction_createServerFn_handler = createServerRpc({
  id: "41b7c5098198af2a6b787a7080cbb18c5575f37dda4f846e3d8484cdef61a68c",
  name: "removeInstructorAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => removeInstructorAction.__executeServer(opts));
const removeInstructorAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseId || !parsed.instructorId) throw new Error("Invalid input");
  return parsed;
}).handler(removeInstructorAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await removeInstructor(data.courseId, data.instructorId);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const archiveCourseAction_createServerFn_handler = createServerRpc({
  id: "6d4db7a6f0e17194c8160ba6d1d3f3d5cf5e1d691d8813f10a86f2e9e03613e4",
  name: "archiveCourseAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => archiveCourseAction.__executeServer(opts));
const archiveCourseAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Course ID is required");
  return parsed;
}).handler(archiveCourseAction_createServerFn_handler, async ({
  data
}) => {
  try {
    await archiveCourse(data.id);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const getCourseDetailAction_createServerFn_handler = createServerRpc({
  id: "791591abb8f80b9b64c72cff0785b1fa2d92ea7d40b7ebbe8a3af1a65b99c2fe",
  name: "getCourseDetailAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => getCourseDetailAction.__executeServer(opts));
const getCourseDetailAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Course ID is required");
  return parsed;
}).handler(getCourseDetailAction_createServerFn_handler, async ({
  data
}) => {
  return getCourseDetail(data.id);
});
const getInstructorCoursesAction_createServerFn_handler = createServerRpc({
  id: "3935a70ea8d99a1fa3ff30072b2ce5527569aae6f2495750944fd04685201fb3",
  name: "getInstructorCoursesAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => getInstructorCoursesAction.__executeServer(opts));
const getInstructorCoursesAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).handler(getInstructorCoursesAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getInstructorCourses(user.id);
});
const getInstructorCourseDetailAction_createServerFn_handler = createServerRpc({
  id: "1b0dbefaa552c4d1b08293494fd27ca0d49ec3c7e0d5ad57fb1ad886bea4f5a8",
  name: "getInstructorCourseDetailAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => getInstructorCourseDetailAction.__executeServer(opts));
const getInstructorCourseDetailAction = createServerFn({
  method: "GET"
}).middleware([instructorMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Course ID is required");
  return parsed;
}).handler(getInstructorCourseDetailAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  return getInstructorCourseDetail(user.id, data.id);
});
const getCourseCatalogAction_createServerFn_handler = createServerRpc({
  id: "e6e42c858ab32014e131535b48a33a6ec98e42edcf1d6ec932e68fe2b08ee400",
  name: "getCourseCatalogAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => getCourseCatalogAction.__executeServer(opts));
const getCourseCatalogAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).inputValidator((data) => {
  const parsed = data;
  return parsed || {};
}).handler(getCourseCatalogAction_createServerFn_handler, async ({
  data,
  context
}) => {
  const user = context.user;
  return getCourseCatalog(data?.search, user.id);
});
const listSemestersAction_createServerFn_handler = createServerRpc({
  id: "2ad86fda792ecbf3746de0cfafeb88b95b4cdf238c34c6101110d54c953c28eb",
  name: "listSemestersAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => listSemestersAction.__executeServer(opts));
const listSemestersAction = createServerFn({
  method: "GET"
}).handler(listSemestersAction_createServerFn_handler, async () => {
  return listSemesters();
});
const getSemesterDetailAction_createServerFn_handler = createServerRpc({
  id: "953e31a563fd7cde17d3b4ef3f36b85ddbff8a70595ce02610470cc666ba9dc8",
  name: "getSemesterDetailAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => getSemesterDetailAction.__executeServer(opts));
const getSemesterDetailAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Semester ID is required");
  return parsed;
}).handler(getSemesterDetailAction_createServerFn_handler, async ({
  data
}) => {
  return getSemesterDetail(data.id);
});
const createSemesterAction_createServerFn_handler = createServerRpc({
  id: "584b6aa9638085acb6fbcaff9b964237c4777b6cbe2d4b70ac329e9972b92f23",
  name: "createSemesterAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => createSemesterAction.__executeServer(opts));
const createSemesterAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => createSemesterSchema.parse(data)).handler(createSemesterAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const semester = await createSemester(data);
    return {
      success: true,
      data: semester
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const updateSemesterAction_createServerFn_handler = createServerRpc({
  id: "2a93a65798c00954ca1e2744b9899351b5a1ba5e496c457079ad4a75ef6a7004",
  name: "updateSemesterAction",
  filename: "src/server/actions/course.actions.ts"
}, (opts) => updateSemesterAction.__executeServer(opts));
const updateSemesterAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => updateSemesterSchema.parse(data)).handler(updateSemesterAction_createServerFn_handler, async ({
  data
}) => {
  try {
    const semester = await updateSemester(data);
    return {
      success: true,
      data: semester
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
export {
  archiveCourseAction_createServerFn_handler,
  assignInstructorAction_createServerFn_handler,
  createCourseAction_createServerFn_handler,
  createSemesterAction_createServerFn_handler,
  getCourseCatalogAction_createServerFn_handler,
  getCourseDetailAction_createServerFn_handler,
  getInstructorCourseDetailAction_createServerFn_handler,
  getInstructorCoursesAction_createServerFn_handler,
  getSemesterDetailAction_createServerFn_handler,
  listCoursesAction_createServerFn_handler,
  listSemestersAction_createServerFn_handler,
  removeInstructorAction_createServerFn_handler,
  updateCourseAction_createServerFn_handler,
  updateSemesterAction_createServerFn_handler
};
