import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { B as Button } from "./router-DhCkpF2X.mjs";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription } from "./dialog-bXLpXEvc.mjs";
import { C as Card, e as CardContent, a as CardHeader, b as CardTitle } from "./card-QCkASOp1.mjs";
import { S as Separator } from "./separator-BT66itnq.mjs";
import { b as GRADE_LABELS } from "./constants-DoiYt0dc.mjs";
import { o as FileText, P as Printer, Q as Download } from "../_libs/lucide-react.mjs";
const DEFAULT_SUMMARY = {
  cumulativeGpa: null,
  totalCredits: 0,
  academicStanding: "N/A"
};
function TranscriptViewDialog({
  open,
  onOpenChange,
  student,
  preloadedData,
  onFetchTranscript
}) {
  const [loading, setLoading] = reactExports.useState(false);
  const [fetchedData, setFetchedData] = reactExports.useState(null);
  const data = preloadedData ?? fetchedData;
  reactExports.useEffect(() => {
    if (!open) {
      setFetchedData(null);
      return;
    }
    if (student.id && !data && onFetchTranscript) {
      setLoading(true);
      onFetchTranscript(student.id).then(setFetchedData).catch(() => {
        toast.error("Failed to load transcript");
        onOpenChange(false);
      }).finally(() => setLoading(false));
    }
  }, [open, student.id]);
  const handleOpen = async (isOpen) => {
    if (isOpen && student.id && !data && onFetchTranscript) {
      setLoading(true);
      try {
        const result = await onFetchTranscript(student.id);
        setFetchedData(result);
      } catch {
        toast.error("Failed to load transcript");
        onOpenChange(false);
      } finally {
        setLoading(false);
      }
    } else if (!isOpen) {
      setFetchedData(null);
    }
    onOpenChange(isOpen);
  };
  const handleDownloadPdf = async () => {
    if (!data) return;
    const d = data;
    try {
      const { generateTranscriptPdf } = await import("./generate-transcript-pdf-C6jFWBxb.mjs");
      generateTranscriptPdf({
        user: { ...d.student, id: d.student.id, role: "STUDENT", isActive: true, emailVerified: false },
        entries: d.transcript.entries,
        summary: d.transcript.summary
      });
      toast.success("Transcript PDF downloaded!");
    } catch {
      toast.error("Failed to generate PDF. Please try again.");
    }
  };
  const handlePrint = () => {
    if (!data) return;
    window.print();
  };
  const { entries, summary } = data?.transcript ?? { entries: [], summary: DEFAULT_SUMMARY };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange: handleOpen, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-2xl max-h-[85vh] overflow-y-auto print:max-w-full print:max-h-none print:shadow-none print:overflow-visible [&>button.absolute]:print:hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "h-5 w-5" }),
        "Academic Transcript — ",
        student.firstName,
        " ",
        student.lastName
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "View and export this student's official transcript." })
    ] }),
    loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "py-8 text-center text-muted-foreground", children: "Loading transcript..." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-end gap-2 print:hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handlePrint, variant: "outline", size: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Printer, { className: "h-4 w-4 mr-2" }),
          "Print"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: handleDownloadPdf, variant: "outline", size: "sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "h-4 w-4 mr-2" }),
          "Export PDF"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "pt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1 overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground shrink-0", children: "Student Name" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium truncate", title: `${student.firstName} ${student.lastName}`, children: [
            student.firstName,
            " ",
            student.lastName
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1 overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground shrink-0", children: "Email" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium truncate", title: student.email, children: student.email })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1 overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground shrink-0", children: "Cumulative GPA" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-bold text-lg", children: summary.cumulativeGpa !== null ? summary.cumulativeGpa.toFixed(3) : "N/A" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-1 overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground shrink-0", children: "Academic Standing" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Badge,
            {
              variant: summary.academicStanding === "Dean's List" ? "success" : summary.academicStanding === "Good Standing" ? "secondary" : summary.academicStanding === "Academic Probation" ? "destructive" : "outline",
              className: "w-fit",
              children: summary.academicStanding
            }
          )
        ] })
      ] }) }) }),
      entries.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground text-center py-6", children: "No transcript data yet. Student has no completed coursework." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: entries.map((entry) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "py-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: entry.semesterName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground font-mono", children: entry.semesterCode })
          ] }),
          entry.semesterGpa !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-medium", children: [
            "GPA: ",
            entry.semesterGpa.toFixed(3)
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "pt-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-[5rem_1fr_5rem_4rem_5rem] gap-x-2 gap-y-2 text-xs text-muted-foreground font-medium mb-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Code" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Course Title" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: "Credit Hr" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: "Grade" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-right", children: "Points" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: entry.courses.map((course) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "grid grid-cols-[5rem_1fr_5rem_4rem_5rem] gap-x-2 items-center py-1.5 text-sm",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono font-medium truncate", children: course.courseCode }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate min-w-0", children: course.courseName }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-center text-muted-foreground", children: [
                  course.credits,
                  " cr"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center min-w-0", children: course.grade ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: "outline", className: "justify-center text-xs w-10", children: GRADE_LABELS[course.grade] || course.grade }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "-" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground tabular-nums text-right", children: course.grade && course.gradePoints != null ? course.gradePoints.toFixed(2) : "-" })
              ]
            },
            course.courseCode
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "my-2" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-sm font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Totals: ",
              entry.semesterCredits,
              " cr · ",
              entry.semesterGradePoints.toFixed(2),
              " pts"
            ] }),
            entry.semesterGpa !== null && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Semester GPA: ",
              entry.semesterGpa.toFixed(2)
            ] })
          ] })
        ] })
      ] }, entry.semesterCode)) }),
      entries.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "bg-muted/30", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-base", children: "Academic Summary" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "pt-0", children: summary.progression ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-[1fr_5rem_5rem_5rem] gap-4 font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: "Credit Hrs" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: "Grade Pts" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: "GPA" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-[1fr_5rem_5rem_5rem] gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Previous Total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.previousTotalCredits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.previousTotalGradePoints.toFixed(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.previousGpa !== null ? summary.progression.previousGpa.toFixed(2) : "N/A" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-[1fr_5rem_5rem_5rem] gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Semester Total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.lastSemesterCredits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.lastSemesterGradePoints.toFixed(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.lastSemesterGpa !== null ? summary.progression.lastSemesterGpa.toFixed(2) : "N/A" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-[1fr_5rem_5rem_5rem] gap-4 font-medium", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Cumulative Average" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.cumulativeCredits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.cumulativeGradePoints.toFixed(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-center", children: summary.progression.cumulativeGpa !== null ? summary.progression.cumulativeGpa.toFixed(2) : "N/A" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Academic Status: " }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: summary.progression.academicStatus === "Promoted" ? "success" : "destructive", children: summary.progression.academicStatus })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
            "Total Credits: ",
            summary.totalCredits
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-bold", children: summary.cumulativeGpa !== null ? summary.cumulativeGpa.toFixed(3) : "N/A" })
        ] }) })
      ] })
    ] })
  ] }) });
}
export {
  TranscriptViewDialog as T
};
