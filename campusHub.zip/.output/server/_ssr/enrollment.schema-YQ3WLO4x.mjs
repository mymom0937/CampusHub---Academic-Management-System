import { o as object, _ as _enum, s as string, j as array } from "../_libs/zod.mjs";
const enrollSchema = object({
  courseId: string().min(1, "Course is required")
});
const dropSchema = object({
  enrollmentId: string().min(1, "Enrollment is required")
});
const submitGradeSchema = object({
  enrollmentId: string().min(1, "Enrollment is required"),
  grade: _enum([
    "A_PLUS",
    "A",
    "A_MINUS",
    "B_PLUS",
    "B",
    "B_MINUS",
    "C_PLUS",
    "C",
    "D",
    "F",
    "P",
    "I",
    "W",
    "DO",
    "NG"
  ])
});
const bulkGradeSchema = object({
  courseId: string().min(1),
  grades: array(
    object({
      enrollmentId: string().min(1),
      grade: _enum([
        "A_PLUS",
        "A",
        "A_MINUS",
        "B_PLUS",
        "B",
        "B_MINUS",
        "C_PLUS",
        "C",
        "D",
        "F",
        "P",
        "I",
        "W",
        "DO",
        "NG"
      ])
    })
  )
});
export {
  bulkGradeSchema as b,
  dropSchema as d,
  enrollSchema as e,
  submitGradeSchema as s
};
