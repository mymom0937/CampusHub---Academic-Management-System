import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { A as cn } from "./router-DhCkpF2X.mjs";
import { E as EyeOff, t as Eye } from "../_libs/lucide-react.mjs";
const PasswordInput = reactExports.forwardRef(
  ({ className, error, ...props }, ref) => {
    const [showPassword, setShowPassword] = reactExports.useState(false);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: showPassword ? "text" : "password",
            className: cn(
              "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pr-10 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
              error && "border-destructive focus-visible:ring-destructive",
              className
            ),
            ref,
            ...props
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            tabIndex: -1,
            onClick: () => setShowPassword((prev) => !prev),
            className: "absolute right-0 top-0 flex h-10 w-10 items-center justify-center text-muted-foreground hover:text-foreground transition-colors",
            "aria-label": showPassword ? "Hide password" : "Show password",
            children: showPassword ? /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-4 w-4" })
          }
        )
      ] }),
      error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-destructive", children: error })
    ] });
  }
);
PasswordInput.displayName = "PasswordInput";
export {
  PasswordInput as P
};
