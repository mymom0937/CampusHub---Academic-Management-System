import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { u as useForm } from "../_libs/react-hook-form.mjs";
import { a } from "../_chunks/_libs/@hookform/resolvers.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { ad as Route, B as Button, ae as assignInstructorAction, af as updateCourseAction, ag as removeInstructorAction, ac as createSsrRpc, ah as getCourseDetailAction } from "./router-DhCkpF2X.mjs";
import { I as Input } from "./input-9b2Tum0N.mjs";
import { L as Label } from "./label-DItuXM8a.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { T as Textarea } from "./textarea-V4BEVgvG.mjs";
import { C as Card, a as CardHeader, b as CardTitle, c as CardDescription, e as CardContent, d as CardFooter } from "./card-QCkASOp1.mjs";
import { S as Separator } from "./separator-BT66itnq.mjs";
import { S as Select, a as SelectTrigger, b as SelectValue, c as SelectContent, d as SelectItem } from "./select-D5Fm91vy.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BlCW8AsE.mjs";
import { D as Dialog, e as DialogTrigger, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription, f as DialogFooter } from "./dialog-bXLpXEvc.mjs";
import { A as AlertDialog, a as AlertDialogContent, b as AlertDialogHeader, c as AlertDialogTitle, d as AlertDialogDescription, e as AlertDialogFooter, f as AlertDialogCancel, g as AlertDialogAction } from "./alert-dialog-DTkhQAha.mjs";
import { E as EmptyState } from "./empty-state-D-g1-il0.mjs";
import { a as adminMiddleware } from "./middleware-DiEMT5y4.mjs";
import { a as addPrerequisiteSchema } from "./notification.schema-BWgQdqns.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import { u as updateCourseSchema } from "./course.schema-DAXkVW6U.mjs";
import { A as ArrowLeft, B as BookOpen, U as Users, V as UserPlus, R as Trash2, a2 as Link2 } from "../_libs/lucide-react.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/zod.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./auth.schema-DqwSeq56.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "path";
import "https";
import "http";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@radix-ui/react-label.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "./constants-DoiYt0dc.mjs";
import "../_chunks/_libs/@radix-ui/react-separator.mjs";
import "../_chunks/_libs/@radix-ui/react-select.mjs";
import "../_chunks/_libs/@radix-ui/number.mjs";
import "../_chunks/_libs/@radix-ui/react-use-previous.mjs";
import "../_chunks/_libs/@radix-ui/react-visually-hidden.mjs";
import "../_chunks/_libs/@radix-ui/react-dialog.mjs";
import "../_chunks/_libs/@radix-ui/react-alert-dialog.mjs";
createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).handler(createSsrRpc("d6e6583fcf51ef9f009b45f504c53c7e4fdef7db96ca75b5a5357197719bb165"));
const getCoursePrerequisitesAction = createServerFn({
  method: "GET"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.courseCode) throw new Error("Course code is required");
  return parsed;
}).handler(createSsrRpc("bbf0f5869f50e6e558ed92c1beb5003785691452a4a538307db481cf537fd925"));
const addPrerequisiteAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => addPrerequisiteSchema.parse(data)).handler(createSsrRpc("17a47d1b958d7c69e487d5a096b75f8d7104dde9c2974a6fa14b8705905977d5"));
const removePrerequisiteAction = createServerFn({
  method: "POST"
}).middleware([adminMiddleware]).inputValidator((data) => {
  const parsed = data;
  if (!parsed.id) throw new Error("Prerequisite ID is required");
  return parsed;
}).handler(createSsrRpc("5155cf2b656faf6d7b2694bdfe93afbeae8a055afec5d2b2e8c72b6c05e9864e"));
function AdminCourseDetailPage() {
  const {
    course: initialCourse,
    instructors
  } = Route.useLoaderData();
  const {
    user
  } = Route.useRouteContext();
  const [course, setCourse] = reactExports.useState(initialCourse);
  const [saving, setSaving] = reactExports.useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = reactExports.useState(false);
  const [selectedInstructorId, setSelectedInstructorId] = reactExports.useState("");
  const [assigning, setAssigning] = reactExports.useState(false);
  const [removingInstructor, setRemovingInstructor] = reactExports.useState(null);
  const [prerequisites, setPrerequisites] = reactExports.useState([]);
  const [newPrereqCode, setNewPrereqCode] = reactExports.useState("");
  const [addingPrereq, setAddingPrereq] = reactExports.useState(false);
  const {
    register,
    handleSubmit,
    formState: {
      errors
    }
  } = useForm({
    resolver: a(updateCourseSchema.omit({
      id: true
    })),
    defaultValues: {
      name: course.name,
      description: course.description || "",
      credits: course.credits,
      capacity: course.capacity
    }
  });
  const refreshCourse = async () => {
    const updated = await getCourseDetailAction({
      data: {
        id: course.id
      }
    });
    setCourse(updated);
  };
  const refreshPrerequisites = async () => {
    try {
      const prereqs = await getCoursePrerequisitesAction({
        data: {
          courseCode: course.code
        }
      });
      setPrerequisites(prereqs);
    } catch {
    }
  };
  reactExports.useEffect(() => {
    refreshPrerequisites();
  }, [course.code]);
  const handleAddPrerequisite = async () => {
    if (!newPrereqCode.trim()) {
      toast.error("Enter a prerequisite course code");
      return;
    }
    setAddingPrereq(true);
    try {
      const result = await addPrerequisiteAction({
        data: {
          courseCode: course.code,
          prerequisiteCode: newPrereqCode.toUpperCase().trim()
        }
      });
      if (result.success) {
        toast.success("Prerequisite added");
        setNewPrereqCode("");
        refreshPrerequisites();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to add prerequisite");
    } finally {
      setAddingPrereq(false);
    }
  };
  const handleRemovePrerequisite = async (id) => {
    const result = await removePrerequisiteAction({
      data: {
        id
      }
    });
    if (result.success) {
      toast.success("Prerequisite removed");
      refreshPrerequisites();
    } else {
      toast.error(result.error.message);
    }
  };
  const handleSave = async (data) => {
    setSaving(true);
    try {
      const result = await updateCourseAction({
        data: {
          id: course.id,
          ...data
        }
      });
      if (result.success) {
        toast.success("Course updated successfully");
        refreshCourse();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to update course");
    } finally {
      setSaving(false);
    }
  };
  const handleAssignInstructor = async () => {
    if (!selectedInstructorId) {
      toast.error("Please select an instructor");
      return;
    }
    setAssigning(true);
    try {
      const result = await assignInstructorAction({
        data: {
          courseId: course.id,
          instructorId: selectedInstructorId,
          isPrimary: course.instructors.length === 0
        }
      });
      if (result.success) {
        toast.success("Instructor assigned successfully");
        setAssignDialogOpen(false);
        setSelectedInstructorId("");
        refreshCourse();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to assign instructor");
    } finally {
      setAssigning(false);
    }
  };
  const handleRemoveInstructor = async (instructorId) => {
    try {
      const result = await removeInstructorAction({
        data: {
          courseId: course.id,
          instructorId
        }
      });
      if (result.success) {
        toast.success("Instructor removed successfully");
        setRemovingInstructor(null);
        refreshCourse();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to remove instructor");
    }
  };
  const availableInstructors = instructors.filter((i) => !course.instructors.some((ci) => ci.id === i.id));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Admin",
      href: "/admin"
    }, {
      label: "Courses",
      href: "/admin/courses"
    }, {
      label: `${course.code} - ${course.name}`
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/admin/courses", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4 mr-2" }),
        "Back to Courses"
      ] }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: course.code }),
            " - ",
            course.name
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-muted-foreground mt-1", children: [
            course.semesterName,
            " | ",
            course.credits,
            " credits"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: course.enrolledCount >= course.capacity ? "destructive" : "secondary", children: [
          course.enrolledCount,
          "/",
          course.capacity,
          " enrolled"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-5 w-5" }),
            "Course Information"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Overview and enrollment details." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 min-w-0 sm:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Code" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-mono font-medium", children: course.code })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Credits" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: course.credits })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Capacity" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: course.capacity })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Enrolled" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: course.enrolledCount })
            ] })
          ] }),
          course.description && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Description" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm mt-1", children: course.description })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "flex flex-row items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-5 w-5" }),
              "Assigned Instructors"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Instructors assigned to teach this course." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { open: assignDialogOpen, onOpenChange: setAssignDialogOpen, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { size: "sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "h-4 w-4 mr-2" }),
              "Assign"
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { children: "Assign Instructor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { children: "Select an instructor to assign to this course." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Instructor" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: selectedInstructorId, onValueChange: setSelectedInstructorId, children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "mt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, { placeholder: "Select instructor" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: availableInstructors.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: "_none", disabled: true, children: "No available instructors" }) : availableInstructors.map((i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectItem, { value: i.id, children: [
                    i.firstName,
                    " ",
                    i.lastName
                  ] }, i.id)) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { onClick: handleAssignInstructor, loading: assigning, disabled: !selectedInstructorId, children: assigning ? "Assigning…" : "Assign Instructor" }) })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: course.instructors.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: Users, title: "No instructors assigned", description: "Assign an instructor to this course using the button above." }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: course.instructors.map((instructor) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(TableCell, { className: "font-medium", children: [
              instructor.firstName,
              " ",
              instructor.lastName
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: instructor.isPrimary ? "default" : "outline", children: instructor.isPrimary ? "Primary" : "Co-Instructor" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "ghost", size: "sm", className: "text-destructive hover:text-destructive", onClick: () => setRemovingInstructor({
              id: instructor.id,
              name: `${instructor.firstName} ${instructor.lastName}`
            }), children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-4 w-4 mr-1" }),
              "Remove"
            ] }) })
          ] }, instructor.id)) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link2, { className: "h-5 w-5" }),
            "Course Prerequisites"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardDescription, { children: [
            "Students must complete these courses before enrolling in ",
            course.code,
            "."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
          prerequisites.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: prerequisites.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: "secondary", className: "text-sm gap-1.5 pr-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono", children: p.prerequisiteCode }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => handleRemovePrerequisite(p.id), className: "ml-1 rounded-full p-0.5 hover:bg-destructive/20 hover:text-destructive transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3 w-3" }) })
          ] }, p.id)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Course code (e.g. CS101)", value: newPrereqCode, onChange: (e) => setNewPrereqCode(e.target.value), onKeyDown: (e) => e.key === "Enter" && handleAddPrerequisite(), className: "max-w-xs font-mono" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", size: "sm", onClick: handleAddPrerequisite, disabled: addingPrereq, children: "Add" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit(handleSave), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { children: "Edit Course" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Update course details." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Course Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { ...register("name"), error: errors.name?.message })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Description" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { ...register("description") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Credits" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", ...register("credits"), error: errors.credits?.message })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Capacity" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", ...register("capacity"), error: errors.capacity?.message })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", loading: saving, children: saving ? "Saving…" : "Save Changes" }) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialog, { open: !!removingInstructor, onOpenChange: () => setRemovingInstructor(null), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogContent, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogHeader, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogTitle, { children: "Remove Instructor" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogDescription, { children: [
          "Are you sure you want to remove",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: removingInstructor?.name }),
          " from this course?"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(AlertDialogFooter, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogCancel, { children: "Cancel" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDialogAction, { onClick: () => removingInstructor && handleRemoveInstructor(removingInstructor.id), className: "bg-destructive text-destructive-foreground hover:bg-destructive/90", children: "Remove" })
      ] })
    ] }) })
  ] });
}
export {
  AdminCourseDetailPage as component
};
