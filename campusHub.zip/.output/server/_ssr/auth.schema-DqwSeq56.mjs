import { o as object, s as string } from "../_libs/zod.mjs";
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;
const loginSchema = object({
  email: string().min(1, "Email is required").email("Invalid email address").transform((v) => v.toLowerCase().trim()),
  password: string().min(1, "Password is required")
});
const registerSchema = object({
  email: string().min(1, "Email is required").email("Invalid email address").transform((v) => v.toLowerCase().trim()),
  password: string().min(8, "Password must be at least 8 characters!").regex(
    passwordRegex,
    "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character (!@#$%^&*)"
  ),
  confirmPassword: string().min(1, "Please confirm your password"),
  firstName: string().min(1, "First name is required").max(50, "First name too long").transform((v) => v.trim()),
  lastName: string().min(1, "Last name is required").max(50, "Last name too long").transform((v) => v.trim())
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});
const changePasswordSchema = object({
  currentPassword: string().min(1, "Current password is required"),
  newPassword: string().min(8, "Password must be at least 8 characters").regex(
    passwordRegex,
    "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character"
  ),
  confirmNewPassword: string().min(1, "Please confirm your new password")
}).refine((data) => data.newPassword === data.confirmNewPassword, {
  message: "Passwords don't match",
  path: ["confirmNewPassword"]
});
const forgotPasswordSchema = object({
  email: string().min(1, "Email is required").email("Invalid email address").transform((v) => v.toLowerCase().trim())
});
const resetPasswordSchema = object({
  token: string().min(1, "Reset token is required"),
  newPassword: string().min(8, "Password must be at least 8 characters").regex(
    passwordRegex,
    "Password must contain at least 1 uppercase, 1 lowercase, 1 number, and 1 special character (!@#$%^&*)"
  ),
  confirmPassword: string().min(1, "Please confirm your password")
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});
export {
  resetPasswordSchema as a,
  changePasswordSchema as c,
  forgotPasswordSchema as f,
  loginSchema as l,
  registerSchema as r
};
