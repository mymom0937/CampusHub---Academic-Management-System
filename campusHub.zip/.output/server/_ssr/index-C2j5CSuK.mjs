import { j as jsxRuntimeExports, r as reactExports } from "../_chunks/_libs/react.mjs";
import { L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { an as Route$u, a as ROLE_DASHBOARD_PATHS, B as Button, A as cn } from "./router-DhCkpF2X.mjs";
import { E as ExternalLink } from "./AppFooter-D0WDOsDC.mjs";
import { S as SUPPORT_EMAIL, a as GITHUB_URL } from "./constants-DoiYt0dc.mjs";
import { L as LandingNavbar, a as LandingFooter } from "./LandingFooter-CX6R5oxD.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { I as Input } from "./input-9b2Tum0N.mjs";
import { C as Card, e as CardContent } from "./card-QCkASOp1.mjs";
import { U as Users, d as Award, B as BookOpen, G as GraduationCap, e as ArrowRight, f as ChartColumn, L as LayoutDashboard, c as Mail, g as Globe, h as Github, i as ChevronLeft, j as ChevronRight } from "../_libs/lucide-react.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "../_libs/zod.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./course.schema-DAXkVW6U.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
function LandingAbout() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "about", className: "py-16 md:py-24 px-4 bg-muted/30 scroll-mt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-4xl text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary uppercase tracking-wider mb-2", children: "About" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl md:text-3xl font-bold mb-4", children: "Excellence in Academic Management" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed", children: "CampusHub is a modern academic management platform designed for universities and colleges. We streamline enrollment, grading, and administration so students, instructors, and administrators can focus on what matters most: teaching and learning." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap justify-center gap-3", children: [
      "Course Management",
      "Enrollment",
      "Grading & GPA",
      "Transcripts",
      "Announcements",
      "Role-Based Access"
    ].map((item) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "span",
      {
        className: "inline-flex items-center rounded-full border bg-background px-4 py-1.5 text-sm font-medium",
        children: item
      },
      item
    )) })
  ] }) });
}
const programs = [
  {
    icon: BookOpen,
    title: "Course Catalog",
    description: "Browse and enroll in courses across disciplines."
  },
  {
    icon: GraduationCap,
    title: "Student Portal",
    description: "Track grades, GPA, and your academic transcript."
  },
  {
    icon: Users,
    title: "Instructor Tools",
    description: "Manage rosters and submit grades efficiently."
  },
  {
    icon: ChartColumn,
    title: "Admin Dashboard",
    description: "Oversee semesters, courses, and users."
  }
];
function LandingAcademics() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "academics", className: "py-16 md:py-24 px-4 scroll-mt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-6xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary uppercase tracking-wider mb-2", children: "Academics" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl md:text-3xl font-bold mb-4", children: "Programs & Services" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground max-w-2xl mx-auto", children: "A complete platform for managing academic workflows from enrollment to graduation." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-2 lg:grid-cols-4 gap-6", children: programs.map((p, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "rounded-xl border bg-card p-6 hover:shadow-lg transition-shadow",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(p.icon, { className: "h-6 w-6" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold mb-2", children: p.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: p.description })
        ]
      },
      idx
    )) })
  ] }) });
}
function Carousel({
  children,
  className,
  autoPlay = true,
  interval = 5e3,
  showArrows = true,
  showDots = true,
  dotsVariant = "light"
}) {
  const [activeIndex, setActiveIndex] = reactExports.useState(0);
  const items = reactExports.Children.toArray(children);
  const count = items.length;
  reactExports.useEffect(() => {
    if (!autoPlay || count <= 1) return;
    const id = setInterval(() => {
      setActiveIndex((i) => (i + 1) % count);
    }, interval);
    return () => clearInterval(id);
  }, [autoPlay, interval, count]);
  const goTo = (index) => setActiveIndex((index + count) % count);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: cn("relative w-full overflow-hidden", className), children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "flex w-full transition-transform duration-500 ease-out",
        style: { transform: `translateX(-${activeIndex * 100}%)` },
        children: items.map((child, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-full w-full shrink-0", children: child }, i))
      }
    ),
    showArrows && count > 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => goTo(activeIndex - 1),
          className: "absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-black/40 p-2 text-white hover:bg-black/60 transition-colors",
          "aria-label": "Previous slide",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-6 w-6" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => goTo(activeIndex + 1),
          className: "absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-black/40 p-2 text-white hover:bg-black/60 transition-colors",
          "aria-label": "Next slide",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "h-6 w-6" })
        }
      )
    ] }),
    showDots && count > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10", children: items.map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        type: "button",
        onClick: () => goTo(i),
        className: cn(
          "h-2 rounded-full transition-all",
          dotsVariant === "light" ? i === activeIndex ? "w-6 bg-white" : "w-2 bg-white/50 hover:bg-white/70" : i === activeIndex ? "w-6 bg-foreground" : "w-2 bg-foreground/50 hover:bg-foreground/70"
        ),
        "aria-label": `Go to slide ${i + 1}`
      },
      i
    )) })
  ] });
}
function ImgWithFallback({
  className,
  fallbackClassName,
  onError,
  ...props
}) {
  const [failed, setFailed] = reactExports.useState(false);
  const handleError = (e) => {
    setFailed(true);
    onError?.(e);
  };
  if (failed) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "img",
    {
      ...props,
      className: cn(className, failed && "hidden"),
      onError: handleError
    }
  );
}
const HERO_SLIDES = [
  {
    image: "/Images/hero-1.jpg",
    title: "Seek Wisdom, Elevate Your Intellect and Serve Humanity",
    description: "CampusHub, an institution of educational excellence, empowers students to achieve their academic goals and prepares them for a successful future.",
    cta: "Portal",
    ctaSecondary: "Study at CampusHub"
  },
  {
    image: "/Images/hero-2.jpg",
    title: "Excellence in Education, Innovation in Learning",
    description: "Join a community of scholars dedicated to academic excellence, research, and lifelong learning.",
    cta: "Portal",
    ctaSecondary: "Explore Programs"
  },
  {
    image: "/Images/hero-3.jpg",
    title: "Your Journey to Success Starts Here",
    description: "From enrollment to graduation, CampusHub supports every step of your academic journey with modern tools and dedicated support.",
    cta: "Portal",
    ctaSecondary: "Get Started"
  }
];
const IMPACT_STATS = [
  { value: "10K+", label: "Active Students", description: "Enrolled across programs" },
  { value: "#1", label: "Top Rated", description: "Academic management platform" },
  { value: "500+", label: "Courses", description: "Wide range of programs" },
  { value: "98%", label: "Satisfaction", description: "Student & faculty rated" }
];
const CAMPUS_LIFE_SLIDES = [
  {
    image: "/Images/campus-life-1.jpg",
    title: "Explore Life at CampusHub",
    subtitle: "Events and Activities",
    description: "From orientation to graduation ceremonies, discover a vibrant campus community with clubs, workshops, and cultural events."
  },
  {
    image: "/Images/campus-life-2.jpg",
    title: "Learning Beyond the Classroom",
    subtitle: "Labs & Research",
    description: "State-of-the-art facilities and research opportunities that complement your academic journey."
  },
  {
    image: "/Images/campus-life-3.jpg",
    title: "Connect and Grow",
    subtitle: "Community",
    description: "Build lasting connections with peers, mentors, and industry partners throughout your studies."
  }
];
const CAMPUS_SLIDES = [
  { image: "/Images/campus-1.jpg", name: "Main Campus", description: "Central hub for academics and administration" },
  { image: "/Images/campus-2.jpg", name: "Science Complex", description: "Labs, research centers, and innovation spaces" },
  { image: "/Images/campus-3.jpg", name: "Student Center", description: "Library, cafeteria, and student services" }
];
function CampusLifeSlide({
  image,
  title,
  subtitle,
  description
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-[500px] md:h-[600px] w-full bg-gradient-to-br from-slate-800 to-slate-900", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ImgWithFallback,
      {
        src: image,
        alt: "",
        className: "absolute inset-0 h-full w-full object-cover"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-black/40" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto px-4 flex flex-col md:flex-row gap-8 items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md rounded-xl border bg-card p-6 md:p-8 shadow-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-2xl font-bold mb-2", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-primary mb-3", children: subtitle }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground text-sm mb-6", children: description }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", size: "sm", className: "gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news", children: [
        "Find out More",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
      ] }) })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute bottom-8 left-0 right-0 flex justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-4xl md:text-6xl font-bold text-white/30 tracking-widest", children: "CAMPUS LIFE" }) })
  ] });
}
function LandingCampusLife() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "campus", className: "relative scroll-mt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Carousel, { autoPlay: true, interval: 5500, showArrows: true, showDots: true, children: CAMPUS_LIFE_SLIDES.map((slide, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(CampusLifeSlide, { ...slide }, i)) }) });
}
function LandingContact() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "contact", className: "py-20 md:py-28 px-4 scroll-mt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-4xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-primary uppercase tracking-wider mb-2", children: "Contact" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold mb-4", children: "Get in Touch" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground text-lg max-w-2xl mx-auto", children: "Have questions or feedback? We'd love to hear from you." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        ExternalLink,
        {
          href: `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(SUPPORT_EMAIL)}`,
          className: "block rounded-xl border bg-card p-6 text-center hover:shadow-lg transition-shadow hover:border-primary/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-6 w-6" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold mb-1", children: "Email" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: SUPPORT_EMAIL })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Link,
        {
          to: "/",
          className: "block rounded-xl border bg-card p-6 text-center hover:shadow-lg transition-shadow hover:border-primary/30 text-foreground",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "h-6 w-6" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold mb-1", children: "Website" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "www.campushub.com" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        ExternalLink,
        {
          href: GITHUB_URL,
          className: "block rounded-xl border bg-card p-6 text-center hover:shadow-lg transition-shadow hover:border-primary/30",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Github, { className: "h-6 w-6" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold mb-1", children: "GitHub" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Open Source on GitHub" })
          ]
        }
      )
    ] })
  ] }) });
}
function LandingCta({ user, dashboardPath }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-20 md:py-28 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto max-w-3xl text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl bg-linear-to-br from-primary/10 via-violet-500/10 to-purple-500/10 border p-10 md:p-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold mb-4", children: "Ready to Get Started?" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground text-lg mb-8 max-w-xl mx-auto", children: "Create your free account and explore the full platform. No credit card required." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col sm:flex-row items-center justify-center gap-4", children: user && dashboardPath ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", asChild: true, className: "text-base px-8 h-12 gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: dashboardPath, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-5 w-5" }),
      "Go to Dashboard",
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
    ] }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", asChild: true, className: "text-base px-8 h-12 gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/register", children: [
        "Create Free Account",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", size: "lg", asChild: true, className: "text-base px-8 h-12", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/login", children: "Sign In" }) })
    ] }) })
  ] }) }) });
}
function CampusSlide({
  image,
  name,
  description
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl overflow-hidden border bg-card shadow-lg", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-[16/10] w-full overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      ImgWithFallback,
      {
        src: image,
        alt: name,
        className: "h-full w-full object-cover"
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t bg-card p-4 sm:p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-lg", children: name }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: description })
    ] })
  ] }) });
}
function LandingExploreCampuses() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-16 md:py-24 px-4 bg-muted text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "container mx-auto max-w-6xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-[minmax(280px,1fr)_1.5fr] gap-8 lg:gap-12 items-start", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl md:text-3xl font-bold", children: "Explore Our Campuses" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Discover our main campus and specialized facilities. Each location offers unique resources and learning environments designed to support your academic journey." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "secondary", size: "lg", className: "gap-2 w-fit", children: [
        "Explore the Campus",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": true, children: "→" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative w-full min-w-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Carousel, { autoPlay: true, interval: 5e3, showArrows: true, showDots: true, dotsVariant: "dark", children: CAMPUS_SLIDES.map((slide, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(CampusSlide, { ...slide }, i)) }) })
  ] }) }) });
}
function HeroSlide({
  image,
  title,
  description,
  cta,
  ctaSecondary,
  user,
  dashboardPath
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-[70vh] min-h-[500px] w-full bg-gradient-to-br from-slate-800 to-slate-900", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      ImgWithFallback,
      {
        src: image,
        alt: "",
        className: "absolute inset-0 h-full w-full object-cover",
        loading: "eager"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative flex h-full items-center justify-end pr-4 md:pr-16 lg:pr-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-xl text-right md:max-w-2xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-bold text-white md:text-4xl lg:text-5xl leading-tight mb-4", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white/90 text-base md:text-lg mb-8 leading-relaxed", children: description }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap justify-end gap-3", children: user && dashboardPath ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", asChild: true, className: "gap-2 bg-white text-slate-900 hover:bg-slate-100 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: dashboardPath, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LayoutDashboard, { className: "h-5 w-5" }),
        "Go to Portal",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
      ] }) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", asChild: true, className: "gap-2 bg-white text-slate-900 hover:bg-slate-100 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/login", children: [
          cta,
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "lg", variant: "outline", asChild: true, className: "gap-2 border-white bg-transparent text-white hover:bg-white/10 hover:text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/register", children: ctaSecondary }) })
      ] }) })
    ] }) })
  ] });
}
function LandingHero({ user, dashboardPath }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Carousel, { autoPlay: true, interval: 6e3, showArrows: true, showDots: true, children: HERO_SLIDES.map((slide, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
    HeroSlide,
    {
      ...slide,
      user,
      dashboardPath
    },
    i
  )) }) });
}
const icons = [Users, Award, BookOpen, GraduationCap];
function LandingImpactNumbers() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-16 md:py-24 px-4 bg-muted/30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-6xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl md:text-3xl font-bold text-center mb-2", children: "Our Impact in Numbers" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-1 bg-primary mx-auto mb-12" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8", children: IMPACT_STATS.map((stat, idx) => {
      const Icon = icons[idx] ?? Users;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "rounded-xl border bg-card p-6 text-center hover:shadow-lg transition-shadow",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-full bg-primary/10 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-8 w-8 text-primary" }) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-3xl md:text-4xl font-bold text-primary mb-1", children: stat.value }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-foreground mb-1", children: stat.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: stat.description })
          ]
        },
        idx
      );
    }) })
  ] }) });
}
function LandingNewsletter() {
  const [email, setEmail] = reactExports.useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.trim()) {
      toast.error("Please enter your email");
      return;
    }
    toast.success("Thank you for subscribing! We'll keep you updated.");
    setEmail("");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-16 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-xl text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold mb-2", children: "Subscribe to Our Newsletter" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground text-sm mb-6", children: "Stay informed about campus news, events, and important updates." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "flex gap-2 max-w-md mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Input,
        {
          type: "email",
          placeholder: "Enter your email",
          value: email,
          onChange: (e) => setEmail(e.target.value),
          className: "flex-1"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", children: "Subscribe" })
    ] })
  ] }) });
}
const FEATURED_NEWS = [
  {
    image: "/Images/news-placeholder.jpg",
    title: "CampusHub Hosts Research Planning Workshop to Strengthen Academic Programs",
    description: "Faculty and staff gathered for a two-day workshop focused on curriculum development and research initiatives.",
    date: "January 15, 2025"
  },
  {
    image: "/Images/campus-life-1.jpg",
    title: "Digital Transformation: New Online Course Validation Workshop",
    description: "Advancing our digital learning infrastructure with updated validation processes.",
    date: "January 10, 2025"
  },
  {
    image: "/Images/campus-life-2.jpg",
    title: "Centre for Sustainable Development Hosts International Workshop",
    description: "Experts from across the region gathered to discuss sustainable campus initiatives.",
    date: "January 5, 2025"
  }
];
function LandingWhatsNew() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-16 md:py-24 px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto max-w-6xl", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl md:text-3xl font-bold text-center mb-12", children: "What's New" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "overflow-hidden border-0 shadow-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video overflow-hidden bg-muted", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          ImgWithFallback,
          {
            src: FEATURED_NEWS[0].image,
            alt: "",
            className: "h-full w-full object-cover"
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "p-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-bold mb-2 line-clamp-2", children: FEATURED_NEWS[0].title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground text-sm mb-4 line-clamp-2", children: FEATURED_NEWS[0].description }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: FEATURED_NEWS[0].date })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: FEATURED_NEWS.slice(1).map((item, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-24 h-24 shrink-0 overflow-hidden rounded-md bg-muted", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          ImgWithFallback,
          {
            src: item.image,
            alt: "",
            className: "h-full w-full object-cover"
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-semibold text-sm line-clamp-2 mb-1", children: item.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: item.date })
        ] })
      ] }) }, i)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 text-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, size: "lg", className: "gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/news", children: [
      "View More News",
      /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
    ] }) }) })
  ] }) });
}
function LandingPage() {
  const {
    user
  } = Route$u.useRouteContext();
  const dashboardPath = user ? ROLE_DASHBOARD_PATHS[user.role] : null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingNavbar, { user, dashboardPath }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingHero, { user, dashboardPath }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingImpactNumbers, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingCampusLife, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingWhatsNew, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingExploreCampuses, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingNewsletter, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingAcademics, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingCta, { user, dashboardPath }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingAbout, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingContact, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(LandingFooter, {})
  ] });
}
export {
  LandingPage as component
};
