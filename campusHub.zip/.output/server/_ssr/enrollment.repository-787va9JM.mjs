import { p as prisma } from "./middleware-DiEMT5y4.mjs";
async function findEnrollmentById(id) {
  return prisma.enrollment.findUnique({
    where: { id },
    include: {
      course: {
        include: {
          semester: true
        }
      },
      student: {
        select: { id: true, firstName: true, lastName: true, email: true }
      }
    }
  });
}
async function findEnrollmentByStudentAndCourse(studentId, courseId) {
  return prisma.enrollment.findUnique({
    where: {
      studentId_courseId: { studentId, courseId }
    }
  });
}
async function createEnrollment(data) {
  return prisma.enrollment.create({ data });
}
async function updateEnrollmentStatus(id, status, droppedAt) {
  return prisma.enrollment.update({
    where: { id },
    data: {
      status,
      ...droppedAt && { droppedAt }
    }
  });
}
async function dropWithGrade(id, grade) {
  return prisma.enrollment.update({
    where: { id },
    data: {
      status: "DROPPED",
      droppedAt: /* @__PURE__ */ new Date(),
      grade,
      gradePoints: null,
      gradedAt: /* @__PURE__ */ new Date()
    }
  });
}
async function submitGrade(id, data) {
  return prisma.enrollment.update({
    where: { id },
    data: {
      grade: data.grade,
      gradePoints: data.gradePoints,
      gradedBy: data.gradedBy,
      gradedAt: /* @__PURE__ */ new Date(),
      status: "COMPLETED"
    }
  });
}
async function getStudentEnrollments(studentId, semesterId) {
  return prisma.enrollment.findMany({
    where: {
      studentId,
      ...semesterId && {
        course: { semesterId }
      }
    },
    include: {
      course: {
        include: {
          semester: { select: { id: true, name: true, code: true } },
          instructorAssignments: {
            where: { isPrimary: true },
            include: {
              instructor: {
                select: { firstName: true, lastName: true }
              }
            }
          }
        }
      }
    },
    orderBy: { enrolledAt: "desc" }
  });
}
async function getCourseEnrollments(courseId) {
  return prisma.enrollment.findMany({
    where: { courseId },
    include: {
      student: {
        select: {
          id: true,
          firstName: true,
          lastName: true,
          email: true
        }
      }
    },
    orderBy: { student: { lastName: "asc" } }
  });
}
async function countEnrolledInCourse(courseId) {
  return prisma.enrollment.count({
    where: { courseId, status: "ENROLLED" }
  });
}
async function countStudentCredits(studentId, semesterId) {
  const enrollments = await prisma.enrollment.findMany({
    where: {
      studentId,
      status: "ENROLLED",
      course: { semesterId }
    },
    include: {
      course: { select: { credits: true } }
    }
  });
  return enrollments.reduce((sum, e) => sum + e.course.credits, 0);
}
async function countStudentEnrollments(studentId, semesterId) {
  return prisma.enrollment.count({
    where: {
      studentId,
      status: "ENROLLED",
      course: { semesterId }
    }
  });
}
async function createWaitlistEntry(data) {
  return prisma.enrollment.create({
    data: {
      ...data,
      status: "WAITLISTED"
    }
  });
}
async function getNextWaitlisted(courseId) {
  return prisma.enrollment.findFirst({
    where: { courseId, status: "WAITLISTED" },
    orderBy: { enrolledAt: "asc" }
  });
}
async function promoteFromWaitlist(enrollmentId) {
  return prisma.enrollment.update({
    where: { id: enrollmentId },
    data: {
      status: "ENROLLED",
      enrolledAt: /* @__PURE__ */ new Date()
    }
  });
}
async function getWaitlistPosition(studentId, courseId) {
  const waitlisted = await prisma.enrollment.findMany({
    where: { courseId, status: "WAITLISTED" },
    orderBy: { enrolledAt: "asc" },
    select: { studentId: true }
  });
  const idx = waitlisted.findIndex((w) => w.studentId === studentId);
  return idx >= 0 ? idx + 1 : null;
}
export {
  findEnrollmentByStudentAndCourse as a,
  createWaitlistEntry as b,
  countEnrolledInCourse as c,
  getWaitlistPosition as d,
  countStudentCredits as e,
  findEnrollmentById as f,
  getCourseEnrollments as g,
  createEnrollment as h,
  countStudentEnrollments as i,
  dropWithGrade as j,
  getNextWaitlisted as k,
  getStudentEnrollments as l,
  promoteFromWaitlist as p,
  submitGrade as s,
  updateEnrollmentStatus as u
};
