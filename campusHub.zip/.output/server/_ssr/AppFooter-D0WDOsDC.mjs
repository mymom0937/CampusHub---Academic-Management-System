import { j as jsxRuntimeExports, r as reactExports } from "../_chunks/_libs/react.mjs";
import { L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { A as cn } from "./router-DhCkpF2X.mjs";
import { F as FACEBOOK_URL, I as INSTAGRAM_URL, Y as YOUTUBE_URL, a as GITHUB_URL, S as SUPPORT_EMAIL } from "./constants-DoiYt0dc.mjs";
import { G as GraduationCap, r as Facebook, s as Instagram, h as Github, c as Mail } from "../_libs/lucide-react.mjs";
const ExternalLink = reactExports.forwardRef(
  ({ href, openInNewTab = true, className, children, ...props }, ref) => {
    const isHttp = href?.startsWith("http://") || href?.startsWith("https://");
    const isMailto = href?.startsWith("mailto:");
    const isExternal = isHttp || isMailto;
    const shouldOpenNewTab = openInNewTab && isExternal;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "a",
      {
        ref,
        href,
        target: shouldOpenNewTab ? "_blank" : void 0,
        rel: shouldOpenNewTab ? "noopener noreferrer" : void 0,
        className: cn("text-muted-foreground hover:text-foreground transition-colors", className),
        ...props,
        children
      }
    );
  }
);
ExternalLink.displayName = "ExternalLink";
function AppFooter() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("footer", { className: "border-t bg-background text-foreground mt-auto shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-4 md:px-6 py-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-4 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Link,
        {
          to: "/",
          className: "flex items-center gap-2 text-foreground hover:opacity-90 transition-opacity shrink-0",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "h-6 w-6 text-primary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-lg tracking-tight", children: "CampusHub" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "flex items-center gap-6 text-base", "aria-label": "Footer navigation", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: "/",
            hash: "about",
            className: "text-muted-foreground hover:text-foreground transition-colors font-nav",
            children: "About Us"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: "/privacy-policy",
            className: "text-muted-foreground hover:text-foreground transition-colors font-nav",
            children: "Privacy Policy"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: "/terms-of-service",
            className: "text-muted-foreground hover:text-foreground transition-colors font-nav",
            children: "Terms of Service"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 shrink-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ExternalLink,
          {
            href: FACEBOOK_URL,
            className: "text-muted-foreground hover:text-foreground transition-colors p-1",
            "aria-label": "Facebook",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Facebook, { className: "h-5 w-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ExternalLink,
          {
            href: INSTAGRAM_URL,
            className: "text-muted-foreground hover:text-foreground transition-colors p-1",
            "aria-label": "Instagram",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Instagram, { className: "h-5 w-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ExternalLink,
          {
            href: YOUTUBE_URL,
            className: "text-muted-foreground hover:text-foreground transition-colors p-1",
            "aria-label": "YouTube",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "h-5 w-5", viewBox: "0 0 24 24", fill: "currentColor", "aria-hidden": true, children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" }) })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ExternalLink,
          {
            href: GITHUB_URL,
            className: "text-muted-foreground hover:text-foreground transition-colors p-1",
            "aria-label": "GitHub",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Github, { className: "h-5 w-5" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ExternalLink,
          {
            href: `mailto:${SUPPORT_EMAIL}`,
            className: "text-muted-foreground hover:text-foreground transition-colors p-1",
            "aria-label": "Email",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "h-5 w-5" })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-center text-sm text-muted-foreground mt-4 pt-4 border-t border-border/50", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " CampusHub. All rights reserved."
    ] })
  ] }) });
}
export {
  AppFooter as A,
  ExternalLink as E
};
