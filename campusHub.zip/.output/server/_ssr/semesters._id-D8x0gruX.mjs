import { r as reactExports, j as jsxRuntimeExports } from "../_chunks/_libs/react.mjs";
import { u as useNavigate, L as Link } from "../_chunks/_libs/@tanstack/react-router.mjs";
import { u as useForm } from "../_libs/react-hook-form.mjs";
import { a } from "../_chunks/_libs/@hookform/resolvers.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { X as Route$1, B as Button, N as updateSemesterAction, Y as getSemesterDetailAction } from "./router-DhCkpF2X.mjs";
import { I as Input } from "./input-9b2Tum0N.mjs";
import { L as Label } from "./label-DItuXM8a.mjs";
import { D as DashboardLayout, B as Breadcrumb, a as Badge } from "./Breadcrumb-DLEIemdw.mjs";
import { C as Card, a as CardHeader, b as CardTitle, c as CardDescription, e as CardContent, d as CardFooter } from "./card-QCkASOp1.mjs";
import { S as Separator } from "./separator-BT66itnq.mjs";
import { T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell } from "./table-BlCW8AsE.mjs";
import { E as EmptyState } from "./empty-state-D-g1-il0.mjs";
import { e as updateSemesterSchema } from "./course.schema-DAXkVW6U.mjs";
import { A as ArrowLeft, C as Calendar, B as BookOpen } from "../_libs/lucide-react.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/zod.mjs";
import "../_chunks/_libs/@radix-ui/react-slot.mjs";
import "../_chunks/_libs/@radix-ui/react-compose-refs.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "./server-BubZoQFo.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "./auth.schema-DqwSeq56.mjs";
import "./middleware-DiEMT5y4.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/better-call.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "./notification.schema-BWgQdqns.mjs";
import "./enrollment.schema-YQ3WLO4x.mjs";
import "./assessment.schema-DvXBy4tg.mjs";
import "./user.schema-uS5_1fSq.mjs";
import "../_chunks/_libs/cloudinary.mjs";
import "../_libs/lodash.mjs";
import "url";
import "querystring";
import "fs";
import "https";
import "http";
import "../_chunks/_libs/@radix-ui/react-label.mjs";
import "../_chunks/_libs/@radix-ui/react-primitive.mjs";
import "./ModeToggle-l3F05cxw.mjs";
import "../_chunks/_libs/@radix-ui/react-dropdown-menu.mjs";
import "../_chunks/_libs/@radix-ui/primitive.mjs";
import "../_chunks/_libs/@radix-ui/react-context.mjs";
import "../_chunks/_libs/@radix-ui/react-use-controllable-state.mjs";
import "../_chunks/_libs/@radix-ui/react-use-layout-effect.mjs";
import "../_chunks/_libs/@radix-ui/react-menu.mjs";
import "../_chunks/_libs/@radix-ui/react-collection.mjs";
import "../_chunks/_libs/@radix-ui/react-direction.mjs";
import "../_chunks/_libs/@radix-ui/react-dismissable-layer.mjs";
import "../_chunks/_libs/@radix-ui/react-use-callback-ref.mjs";
import "../_chunks/_libs/@radix-ui/react-use-escape-keydown.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-guards.mjs";
import "../_chunks/_libs/@radix-ui/react-focus-scope.mjs";
import "../_chunks/_libs/@radix-ui/react-popper.mjs";
import "../_chunks/_libs/@floating-ui/react-dom.mjs";
import "../_chunks/_libs/@floating-ui/dom.mjs";
import "../_chunks/_libs/@floating-ui/core.mjs";
import "../_chunks/_libs/@floating-ui/utils.mjs";
import "../_chunks/_libs/@radix-ui/react-arrow.mjs";
import "../_chunks/_libs/@radix-ui/react-use-size.mjs";
import "../_chunks/_libs/@radix-ui/react-portal.mjs";
import "../_chunks/_libs/@radix-ui/react-presence.mjs";
import "../_chunks/_libs/@radix-ui/react-roving-focus.mjs";
import "../_chunks/_libs/@radix-ui/react-id.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/react-remove-scroll.mjs";
import "../_libs/tslib.mjs";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "./AppFooter-D0WDOsDC.mjs";
import "./constants-DoiYt0dc.mjs";
import "../_chunks/_libs/@radix-ui/react-separator.mjs";
function AdminSemesterDetailPage() {
  const {
    semester: initialSemester,
    courses
  } = Route$1.useLoaderData();
  const {
    user
  } = Route$1.useRouteContext();
  const navigate = useNavigate();
  const [semester, setSemester] = reactExports.useState(initialSemester);
  const [saving, setSaving] = reactExports.useState(false);
  const formatDate = (iso) => new Date(iso).toLocaleDateString();
  const toInputDate = (iso) => new Date(iso).toISOString().split("T")[0];
  const {
    register,
    handleSubmit,
    formState: {
      errors
    }
  } = useForm({
    resolver: a(updateSemesterSchema.omit({
      id: true
    })),
    defaultValues: {
      name: semester.name,
      startDate: toInputDate(semester.startDate),
      endDate: toInputDate(semester.endDate),
      enrollmentStart: toInputDate(semester.enrollmentStart),
      enrollmentEnd: toInputDate(semester.enrollmentEnd),
      dropDeadline: toInputDate(semester.dropDeadline)
    }
  });
  const refreshSemester = async () => {
    const updated = await getSemesterDetailAction({
      data: {
        id: semester.id
      }
    });
    setSemester(updated);
  };
  const handleSave = async (data) => {
    setSaving(true);
    try {
      const result = await updateSemesterAction({
        data: {
          id: semester.id,
          ...data
        }
      });
      if (result.success) {
        toast.success("Semester updated successfully");
        refreshSemester();
      } else {
        toast.error(result.error.message);
      }
    } catch {
      toast.error("Failed to update semester");
    } finally {
      setSaving(false);
    }
  };
  const handleSetActive = async () => {
    const result = await updateSemesterAction({
      data: {
        id: semester.id,
        isActive: true
      }
    });
    if (result.success) {
      toast.success("Semester set as active");
      refreshSemester();
    } else {
      toast.error(result.error.message);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DashboardLayout, { user, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Breadcrumb, { items: [{
      label: "Admin",
      href: "/admin"
    }, {
      label: "Semesters",
      href: "/admin/semesters"
    }, {
      label: semester.name
    }] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl space-y-6 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/admin/semesters", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "h-4 w-4 mr-2" }),
        "Back to Semesters"
      ] }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold tracking-tight break-words sm:text-3xl", children: semester.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mt-1 font-mono", children: semester.code })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { variant: semester.isActive ? "success" : "secondary", children: semester.isActive ? "Active" : "Inactive" }),
          !semester.isActive && /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", onClick: handleSetActive, children: "Set Active" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-5 w-5" }),
            "Semester Details"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Dates and enrollment periods." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Semester Period" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium", children: [
              formatDate(semester.startDate),
              " -",
              " ",
              formatDate(semester.endDate)
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Enrollment Period" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium", children: [
              formatDate(semester.enrollmentStart),
              " -",
              " ",
              formatDate(semester.enrollmentEnd)
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Drop Deadline" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: formatDate(semester.dropDeadline) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "Courses" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium", children: semester.courseCount })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "h-5 w-5" }),
            "Courses (",
            courses.total,
            ")"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Courses offered in this semester." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { children: courses.items.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { icon: BookOpen, title: "No courses", description: "No courses have been added to this semester yet.", action: {
          label: "Go to Courses",
          onClick: () => navigate({
            to: "/admin/courses"
          })
        } }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Code" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Credits" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Enrollment" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { children: "Instructor(s)" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right", children: "Actions" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { children: courses.items.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "font-mono font-medium", children: c.code }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: c.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: c.credits }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { variant: c.enrolledCount >= c.capacity ? "destructive" : "secondary", children: [
              c.enrolledCount,
              "/",
              c.capacity
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { children: c.instructors.length > 0 ? c.instructors.map((i) => `${i.firstName} ${i.lastName}`).join(", ") : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "Unassigned" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "ghost", size: "sm", asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/admin/courses/$id", params: {
              id: c.id
            }, children: "View" }) }) })
          ] }, c.id)) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit(handleSave), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { children: "Edit Semester" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { children: "Update semester dates and settings." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Semester Name" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { ...register("name"), error: errors.name?.message })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Start Date" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", ...register("startDate") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "End Date" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", ...register("endDate") })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Enrollment Start" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", ...register("enrollmentStart") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Enrollment End" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", ...register("enrollmentEnd") })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { children: "Drop Deadline" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", ...register("dropDeadline") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardFooter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", loading: saving, children: saving ? "Saving…" : "Save Changes" }) })
      ] }) })
    ] })
  ] });
}
export {
  AdminSemesterDetailPage as component
};
