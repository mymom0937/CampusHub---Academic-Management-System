import { c as createServerRpc } from "./createServerRpc-29xaFZcb.mjs";
import { s as studentMiddleware, t as toAppError, A as AppError } from "./middleware-DiEMT5y4.mjs";
import { M as MAX_CREDITS_PER_SEMESTER } from "./constants-DoiYt0dc.mjs";
import { a as findEnrollmentByStudentAndCourse, c as countEnrolledInCourse, b as createWaitlistEntry, d as getWaitlistPosition, e as countStudentCredits, h as createEnrollment, f as findEnrollmentById, i as countStudentEnrollments, j as dropWithGrade, u as updateEnrollmentStatus, k as getNextWaitlisted, p as promoteFromWaitlist, l as getStudentEnrollments$1 } from "./enrollment.repository-787va9JM.mjs";
import { f as findCourseById } from "./course.repository-DNbUwZlZ.mjs";
import { a as findActiveSemester } from "./semester.repository-wa0iGq7i.mjs";
import { c as checkPrerequisitesMet } from "./prerequisite.service-C4RHxalx.mjs";
import { e as enrollSchema, d as dropSchema } from "./enrollment.schema-YQ3WLO4x.mjs";
import { c as createServerFn } from "./server-BubZoQFo.mjs";
import "../_chunks/_libs/@better-auth/utils.mjs";
import "../_chunks/_libs/@better-auth/core.mjs";
import "../_libs/zod.mjs";
import "../_libs/better-call.mjs";
import "../_libs/rou3.mjs";
import "../_chunks/_libs/@better-fetch/fetch.mjs";
import "../_libs/jose.mjs";
import "../_chunks/_libs/@noble/ciphers.mjs";
import "../_chunks/_libs/@noble/hashes.mjs";
import "../_libs/defu.mjs";
import "../_chunks/_libs/@better-auth/telemetry.mjs";
import "../_libs/resend.mjs";
import "../_libs/mailparser.mjs";
import "../_chunks/_libs/@zone-eu/mailsplit.mjs";
import "stream";
import "../_chunks/_libs/libmime.mjs";
import "node:buffer";
import "../_chunks/_libs/iconv-lite.mjs";
import "../_chunks/_libs/safer-buffer.mjs";
import "buffer";
import "string_decoder";
import "../_libs/encoding-japanese.mjs";
import "../_chunks/_libs/libbase64.mjs";
import "node:stream";
import "../_libs/libqp.mjs";
import "path";
import "../_libs/nodemailer.mjs";
import "../_libs/punycode.js.mjs";
import "../_chunks/_libs/react.mjs";
import "crypto";
import "../_libs/html-to-text.mjs";
import "../_chunks/_libs/@selderee/plugin-htmlparser2.mjs";
import "../_libs/selderee.mjs";
import "../_libs/parseley.mjs";
import "../_libs/leac.mjs";
import "../_libs/peberminta.mjs";
import "../_libs/domhandler.mjs";
import "../_libs/domelementtype.mjs";
import "../_libs/htmlparser2.mjs";
import "../_libs/entities.mjs";
import "../_libs/deepmerge.mjs";
import "../_libs/dom-serializer.mjs";
import "../_libs/he.mjs";
import "../_libs/linkify-it.mjs";
import "../_libs/uc.micro.mjs";
import "../_libs/tlds.mjs";
import "../_libs/svix.mjs";
import "../_libs/uuid.mjs";
import "node:crypto";
import "../_libs/standardwebhooks.mjs";
import "../_chunks/_libs/@stablelib/base64.mjs";
import "../_libs/fast-sha256.mjs";
import "node:path";
import "node:url";
import "@prisma/client/runtime/client";
import "../_chunks/_libs/@prisma/adapter-pg.mjs";
import "../_chunks/_libs/@prisma/driver-adapter-utils.mjs";
import "../_chunks/_libs/@prisma/debug.mjs";
import "pg";
import "../_libs/postgres-array.mjs";
import "../_libs/kysely.mjs";
import "../_chunks/_libs/@tanstack/history.mjs";
import "../_chunks/_libs/@tanstack/router-core.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/tiny-invariant.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:https";
import "node:http2";
import "../_chunks/_libs/@tanstack/react-router.mjs";
import "../_libs/tiny-warning.mjs";
import "../_chunks/_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "../_libs/isbot.mjs";
async function enrollStudent(studentId, courseId) {
  const course = await findCourseById(courseId);
  if (!course) {
    throw new AppError("NOT_FOUND", "Course not found");
  }
  const semester = course.semester;
  const now = /* @__PURE__ */ new Date();
  if (now < semester.enrollmentStart || now > semester.enrollmentEnd) {
    throw new AppError(
      "ENROLLMENT_CLOSED",
      "Enrollment period has ended for this semester"
    );
  }
  const existing = await findEnrollmentByStudentAndCourse(
    studentId,
    courseId
  );
  if (existing && existing.status === "ENROLLED") {
    throw new AppError("CONFLICT", "You are already enrolled in this course");
  }
  if (existing && existing.status === "WAITLISTED") {
    throw new AppError("CONFLICT", "You are already on the waitlist for this course");
  }
  const enrolledCount = await countEnrolledInCourse(courseId);
  if (enrolledCount >= course.capacity) {
    await createWaitlistEntry({ studentId, courseId });
    const position = await getWaitlistPosition(studentId, courseId);
    return { status: "waitlisted", waitlistPosition: position ?? void 0 };
  }
  const prereqCheck = await checkPrerequisitesMet(
    studentId,
    course.code
  );
  if (!prereqCheck.met) {
    throw new AppError(
      "VALIDATION_ERROR",
      `Missing prerequisites: ${prereqCheck.missing.join(", ")}`,
      { missingPrerequisites: prereqCheck.missing }
    );
  }
  const currentCredits = await countStudentCredits(
    studentId,
    semester.id
  );
  if (currentCredits + course.credits > MAX_CREDITS_PER_SEMESTER) {
    throw new AppError(
      "CREDIT_LIMIT_EXCEEDED",
      `Enrolling would exceed the maximum of ${MAX_CREDITS_PER_SEMESTER} credits per semester`
    );
  }
  await createEnrollment({ studentId, courseId });
  return { status: "enrolled" };
}
async function dropCourse(studentId, enrollmentId) {
  const enrollment = await findEnrollmentById(enrollmentId);
  if (!enrollment) {
    throw new AppError("NOT_FOUND", "Enrollment not found");
  }
  if (enrollment.studentId !== studentId) {
    throw new AppError("FORBIDDEN", "You can only drop your own enrollments");
  }
  if (enrollment.status !== "ENROLLED") {
    throw new AppError("VALIDATION_ERROR", "Can only drop active enrollments");
  }
  const semesterId = enrollment.course.semesterId;
  const enrollmentCount = await countStudentEnrollments(
    studentId,
    semesterId
  );
  if (enrollmentCount <= 1) {
    throw new AppError(
      "VALIDATION_ERROR",
      "Cannot drop your last enrolled course"
    );
  }
  const now = /* @__PURE__ */ new Date();
  const dropDeadline = enrollment.course.semester.dropDeadline;
  if (now > dropDeadline) {
    await dropWithGrade(enrollmentId, "W");
  } else {
    await updateEnrollmentStatus(
      enrollmentId,
      "DROPPED",
      /* @__PURE__ */ new Date()
    );
  }
  const nextWaitlisted = await getNextWaitlisted(enrollment.courseId);
  if (nextWaitlisted) {
    await promoteFromWaitlist(nextWaitlisted.id);
  }
}
async function leaveWaitlist(studentId, enrollmentId) {
  const enrollment = await findEnrollmentById(enrollmentId);
  if (!enrollment) {
    throw new AppError("NOT_FOUND", "Waitlist entry not found");
  }
  if (enrollment.studentId !== studentId) {
    throw new AppError("FORBIDDEN", "You can only remove your own waitlist entries");
  }
  if (enrollment.status !== "WAITLISTED") {
    throw new AppError("VALIDATION_ERROR", "This enrollment is not waitlisted");
  }
  await updateEnrollmentStatus(
    enrollmentId,
    "DROPPED",
    /* @__PURE__ */ new Date()
  );
}
async function getStudentEnrollments(studentId, semesterId) {
  let targetSemesterId = semesterId;
  if (!targetSemesterId) {
    const activeSemester = await findActiveSemester();
    targetSemesterId = activeSemester?.id;
  }
  const enrollments = await getStudentEnrollments$1(
    studentId,
    targetSemesterId
  );
  return enrollments.map((e) => ({
    id: e.id,
    courseCode: e.course.code,
    courseName: e.course.name,
    credits: e.course.credits,
    status: e.status,
    enrolledAt: e.enrolledAt.toISOString(),
    droppedAt: e.droppedAt?.toISOString() || null,
    grade: e.grade,
    gradePoints: e.gradePoints,
    instructorName: e.course.instructorAssignments[0] ? `${e.course.instructorAssignments[0].instructor.firstName} ${e.course.instructorAssignments[0].instructor.lastName}` : null,
    semesterName: e.course.semester.name
  }));
}
const enrollAction_createServerFn_handler = createServerRpc({
  id: "cd24a0e03c85684621d7bd04bc76038683585685ff88cb6b8d43cd978f052788",
  name: "enrollAction",
  filename: "src/server/actions/enrollment.actions.ts"
}, (opts) => enrollAction.__executeServer(opts));
const enrollAction = createServerFn({
  method: "POST"
}).middleware([studentMiddleware]).inputValidator((data) => enrollSchema.parse(data)).handler(enrollAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    const result = await enrollStudent(user.id, data.courseId);
    return {
      success: true,
      data: result
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const dropAction_createServerFn_handler = createServerRpc({
  id: "31056efa21668ce31615531eb3d83fb427bf95dfa2c445b79413bf0e95a8e715",
  name: "dropAction",
  filename: "src/server/actions/enrollment.actions.ts"
}, (opts) => dropAction.__executeServer(opts));
const dropAction = createServerFn({
  method: "POST"
}).middleware([studentMiddleware]).inputValidator((data) => dropSchema.parse(data)).handler(dropAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    await dropCourse(user.id, data.enrollmentId);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const leaveWaitlistAction_createServerFn_handler = createServerRpc({
  id: "c93562cbf035e3663ab758a7d4563f23de1f488d0a39227a10a50f48881f3266",
  name: "leaveWaitlistAction",
  filename: "src/server/actions/enrollment.actions.ts"
}, (opts) => leaveWaitlistAction.__executeServer(opts));
const leaveWaitlistAction = createServerFn({
  method: "POST"
}).middleware([studentMiddleware]).inputValidator((data) => dropSchema.parse(data)).handler(leaveWaitlistAction_createServerFn_handler, async ({
  data,
  context
}) => {
  try {
    const user = context.user;
    await leaveWaitlist(user.id, data.enrollmentId);
    return {
      success: true
    };
  } catch (error) {
    const appError = toAppError(error);
    return {
      success: false,
      error: {
        code: appError.code,
        message: appError.message
      }
    };
  }
});
const getStudentEnrollmentsAction_createServerFn_handler = createServerRpc({
  id: "7974daa4b3e3b441dd33de5179985efe805d23c565c078507d0892187ca702ba",
  name: "getStudentEnrollmentsAction",
  filename: "src/server/actions/enrollment.actions.ts"
}, (opts) => getStudentEnrollmentsAction.__executeServer(opts));
const getStudentEnrollmentsAction = createServerFn({
  method: "GET"
}).middleware([studentMiddleware]).handler(getStudentEnrollmentsAction_createServerFn_handler, async ({
  context
}) => {
  const user = context.user;
  return getStudentEnrollments(user.id);
});
export {
  dropAction_createServerFn_handler,
  enrollAction_createServerFn_handler,
  getStudentEnrollmentsAction_createServerFn_handler,
  leaveWaitlistAction_createServerFn_handler
};
