import require$$0 from "node:buffer";
import require$$1 from "node:stream";
var libqp;
var hasRequiredLibqp;
function requireLibqp() {
  if (hasRequiredLibqp) return libqp;
  hasRequiredLibqp = 1;
  const { Buffer } = require$$0;
  const stream = require$$1;
  const Transform = stream.Transform;
  function encode(buffer) {
    if (typeof buffer === "string") {
      buffer = Buffer.from(buffer, "utf-8");
    }
    let ranges = [
      // https://tools.ietf.org/html/rfc2045#section-6.7
      [9],
      // <TAB>
      [10],
      // <LF>
      [13],
      // <CR>
      [32, 60],
      // <SP>!"#$%&'()*+,-./0123456789:;
      [62, 126]
      // >?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}
    ];
    let result = "";
    let ord;
    for (let i = 0, len = buffer.length; i < len; i++) {
      ord = buffer[i];
      if (checkRanges(ord, ranges) && !((ord === 32 || ord === 9) && (i === len - 1 || buffer[i + 1] === 10 || buffer[i + 1] === 13))) {
        result += String.fromCharCode(ord);
        continue;
      }
      result += "=" + (ord < 16 ? "0" : "") + ord.toString(16).toUpperCase();
    }
    return result;
  }
  function decode(str) {
    str = (str || "").toString().replace(/[\t ]+$/gm, "").replace(/\=(?:\r?\n|$)/g, "");
    let encodedBytesCount = (str.match(/\=[\da-fA-F]{2}/g) || []).length, bufferLength = str.length - encodedBytesCount * 2, chr, hex, buffer = Buffer.alloc(bufferLength), bufferPos = 0;
    for (let i = 0, len = str.length; i < len; i++) {
      chr = str.charAt(i);
      if (chr === "=" && (hex = str.substr(i + 1, 2)) && /[\da-fA-F]{2}/.test(hex)) {
        buffer[bufferPos++] = parseInt(hex, 16);
        i += 2;
        continue;
      }
      buffer[bufferPos++] = chr.charCodeAt(0);
    }
    return buffer;
  }
  function wrap(str, lineLength) {
    str = (str || "").toString();
    lineLength = lineLength || 76;
    if (str.length <= lineLength) {
      return str;
    }
    let pos = 0, len = str.length, match, code, line, lineMargin = Math.floor(lineLength / 3), result = "";
    while (pos < len) {
      line = str.substr(pos, lineLength);
      if (match = line.match(/\r\n/)) {
        line = line.substr(0, match.index + match[0].length);
        result += line;
        pos += line.length;
        continue;
      }
      if (line.substr(-1) === "\n") {
        result += line;
        pos += line.length;
        continue;
      } else if (match = line.substr(-lineMargin).match(/\n.*?$/)) {
        line = line.substr(0, line.length - (match[0].length - 1));
        result += line;
        pos += line.length;
        continue;
      } else if (line.length > lineLength - lineMargin && (match = line.substr(-lineMargin).match(/[ \t\.,!\?][^ \t\.,!\?]*$/))) {
        line = line.substr(0, line.length - (match[0].length - 1));
      } else if (line.match(/\=[\da-f]{0,2}$/i)) {
        if (match = line.match(/\=[\da-f]{0,1}$/i)) {
          line = line.substr(0, line.length - match[0].length);
        }
        while (line.length > 3 && line.length < len - pos && !line.match(/^(?:=[\da-f]{2}){1,4}$/i) && (match = line.match(/\=[\da-f]{2}$/gi))) {
          code = parseInt(match[0].substr(1, 2), 16);
          if (code < 128) {
            break;
          }
          line = line.substr(0, line.length - 3);
          if (code >= 192) {
            break;
          }
        }
      }
      if (pos + line.length < len && line.substr(-1) !== "\n") {
        if (line.length === lineLength && line.match(/\=[\da-f]{2}$/i)) {
          line = line.substr(0, line.length - 3);
        } else if (line.length === lineLength) {
          line = line.substr(0, line.length - 1);
        }
        pos += line.length;
        line += "=\r\n";
      } else {
        pos += line.length;
      }
      result += line;
    }
    return result;
  }
  function checkRanges(nr, ranges) {
    for (let i = ranges.length - 1; i >= 0; i--) {
      if (!ranges[i].length) {
        continue;
      }
      if (ranges[i].length === 1 && nr === ranges[i][0]) {
        return true;
      }
      if (ranges[i].length === 2 && nr >= ranges[i][0] && nr <= ranges[i][1]) {
        return true;
      }
    }
    return false;
  }
  class Encoder extends Transform {
    constructor(options) {
      super();
      this.options = options || {};
      if (this.options.lineLength !== false) {
        this.options.lineLength = this.options.lineLength || 76;
      }
      this._curLine = "";
      this.inputBytes = 0;
      this.outputBytes = 0;
      Transform.call(this, this.options);
    }
    _transform(chunk, encoding, done) {
      let qp;
      if (encoding !== "buffer") {
        chunk = Buffer.from(chunk, encoding);
      }
      if (!chunk || !chunk.length) {
        return done();
      }
      this.inputBytes += chunk.length;
      if (this.options.lineLength) {
        qp = this._curLine + encode(chunk);
        qp = wrap(qp, this.options.lineLength);
        qp = qp.replace(/(^|\n)([^\n]*)$/, (match, lineBreak, lastLine) => {
          this._curLine = lastLine;
          return lineBreak;
        });
        if (qp) {
          this.outputBytes += qp.length;
          this.push(qp);
        }
      } else {
        qp = encode(chunk);
        this.outputBytes += qp.length;
        this.push(qp, "ascii");
      }
      done();
    }
    _flush(done) {
      if (this._curLine) {
        this.outputBytes += this._curLine.length;
        this.push(this._curLine, "ascii");
      }
      done();
    }
  }
  class Decoder extends Transform {
    constructor(options) {
      options = options || {};
      super(options);
      this.options = options;
      this._curLine = "";
      this.inputBytes = 0;
      this.outputBytes = 0;
      this.qpChunks = [];
    }
    _transform(chunk, encoding, done) {
      if (!chunk || !chunk.length) {
        return done();
      }
      if (typeof chunk === "string") {
        chunk = Buffer.from(chunk, encoding);
      }
      this.qpChunks.push(chunk);
      this.inputBytes += chunk.length;
      done();
    }
    _flush(done) {
      if (this.inputBytes) {
        let buf = decode(Buffer.concat(this.qpChunks, this.inputBytes).toString());
        this.outputBytes += buf.length;
        this.push(buf);
      }
      done();
    }
  }
  libqp = {
    encode,
    decode,
    wrap,
    Encoder,
    Decoder
  };
  return libqp;
}
export {
  requireLibqp as r
};
