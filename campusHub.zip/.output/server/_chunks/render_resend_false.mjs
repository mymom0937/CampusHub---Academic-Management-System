const render_resend_false = {};
throw new Error(`Could not resolve "@react-email/render" imported by "resend".`);
export {
  render_resend_false as default
};
