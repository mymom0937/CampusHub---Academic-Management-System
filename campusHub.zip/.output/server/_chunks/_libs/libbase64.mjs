import require$$0 from "node:buffer";
import require$$1 from "node:stream";
var libbase64;
var hasRequiredLibbase64;
function requireLibbase64() {
  if (hasRequiredLibbase64) return libbase64;
  hasRequiredLibbase64 = 1;
  const { Buffer } = require$$0;
  const stream = require$$1;
  const Transform = stream.Transform;
  function encode(buffer) {
    if (typeof buffer === "string") {
      buffer = Buffer.from(buffer, "utf-8");
    }
    return buffer.toString("base64");
  }
  function decode(str) {
    str = str || "";
    return Buffer.from(str, "base64");
  }
  function wrap(str, lineLength) {
    str = (str || "").toString();
    lineLength = lineLength || 76;
    if (str.length <= lineLength) {
      return str;
    }
    let result = [];
    let pos = 0;
    let chunkLength = lineLength * 1024;
    while (pos < str.length) {
      let wrappedLines = str.substr(pos, chunkLength).replace(new RegExp(".{" + lineLength + "}", "g"), "$&\r\n").trim();
      result.push(wrappedLines);
      pos += chunkLength;
    }
    return result.join("\r\n").trim();
  }
  class Encoder extends Transform {
    constructor(options) {
      super();
      this.options = options || {};
      if (this.options.lineLength !== false) {
        this.options.lineLength = Number(this.options.lineLength) || 76;
      }
      this.skipStartBytes = Number(this.options.skipStartBytes) || 0;
      this.limitOutbutBytes = Number(this.options.limitOutbutBytes) || 0;
      this._curLine = this.options.startPadding || "";
      this._remainingBytes = false;
      this.inputBytes = 0;
      this.outputBytes = 0;
    }
    _writeChunk(chunk) {
      if (this.skipStartBytes) {
        if (chunk.length <= this.skipStartBytes) {
          this.skipStartBytes -= chunk.length;
          return;
        }
        chunk = chunk.slice(this.skipStartBytes);
        this.skipStartBytes = 0;
      }
      if (this.limitOutbutBytes) {
        if (this.outputBytes + chunk.length <= this.limitOutbutBytes) ;
        else if (this.outputBytes >= this.limitOutbutBytes) {
          return;
        } else {
          chunk = chunk.slice(0, this.limitOutbutBytes - this.outputBytes);
        }
      }
      this.outputBytes += chunk.length;
      this.push(chunk);
    }
    _getWrapped(str, isFinal) {
      str = wrap(str, this.options.lineLength);
      if (!isFinal && str.length === this.options.lineLength) {
        str += "\r\n";
      }
      return str;
    }
    _transform(chunk, encoding, done) {
      if (encoding !== "buffer") {
        chunk = Buffer.from(chunk, encoding);
      }
      if (!chunk || !chunk.length) {
        return setImmediate(done);
      }
      this.inputBytes += chunk.length;
      if (this._remainingBytes && this._remainingBytes.length) {
        chunk = Buffer.concat([this._remainingBytes, chunk], this._remainingBytes.length + chunk.length);
        this._remainingBytes = false;
      }
      if (chunk.length % 3) {
        this._remainingBytes = chunk.slice(chunk.length - chunk.length % 3);
        chunk = chunk.slice(0, chunk.length - chunk.length % 3);
      } else {
        this._remainingBytes = false;
      }
      let b64 = this._curLine + encode(chunk);
      if (this.options.lineLength) {
        b64 = this._getWrapped(b64);
        let lastLF = b64.lastIndexOf("\n");
        if (lastLF < 0) {
          this._curLine = b64;
          b64 = "";
        } else if (lastLF === b64.length - 1) {
          this._curLine = "";
        } else {
          this._curLine = b64.substr(lastLF + 1);
          b64 = b64.substr(0, lastLF + 1);
        }
      }
      if (b64) {
        this._writeChunk(Buffer.from(b64, "ascii"), false);
      }
      setImmediate(done);
    }
    _flush(done) {
      if (this._remainingBytes && this._remainingBytes.length) {
        this._curLine += encode(this._remainingBytes);
      }
      if (this._curLine) {
        this._curLine = this._getWrapped(this._curLine, true);
        this._writeChunk(Buffer.from(this._curLine, "ascii"), true);
        this._curLine = "";
      }
      done();
    }
  }
  class Decoder extends Transform {
    constructor(options) {
      super();
      this.options = options || {};
      this._curLine = "";
      this.inputBytes = 0;
      this.outputBytes = 0;
    }
    _transform(chunk, encoding, done) {
      if (!chunk || !chunk.length) {
        return setImmediate(done);
      }
      this.inputBytes += chunk.length;
      let b64 = this._curLine + chunk.toString("ascii");
      this._curLine = "";
      if (/[^a-zA-Z0-9+/=]/.test(b64)) {
        b64 = b64.replace(/[^a-zA-Z0-9+/=]/g, "");
      }
      if (b64.length < 4) {
        this._curLine = b64;
        b64 = "";
      } else if (b64.length % 4) {
        this._curLine = b64.substr(-b64.length % 4);
        b64 = b64.substr(0, b64.length - this._curLine.length);
      }
      if (b64) {
        let buf = decode(b64);
        this.outputBytes += buf.length;
        this.push(buf);
      }
      setImmediate(done);
    }
    _flush(done) {
      if (this._curLine) {
        let buf = decode(this._curLine);
        this.outputBytes += buf.length;
        this.push(buf);
        this._curLine = "";
      }
      setImmediate(done);
    }
  }
  libbase64 = {
    encode,
    decode,
    wrap,
    Encoder,
    Decoder
  };
  return libbase64;
}
export {
  requireLibbase64 as r
};
