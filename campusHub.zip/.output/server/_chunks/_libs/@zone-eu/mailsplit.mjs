import require$$0 from "stream";
import { r as requireLibmime } from "../libmime.mjs";
import { r as requireLibqp } from "../../../_libs/libqp.mjs";
import { r as requireLibbase64 } from "../libbase64.mjs";
import require$$1 from "path";
var headers;
var hasRequiredHeaders;
function requireHeaders() {
  if (hasRequiredHeaders) return headers;
  hasRequiredHeaders = 1;
  const libmime = /* @__PURE__ */ requireLibmime();
  class Headers {
    constructor(headers2, config) {
      config = config || {};
      if (Array.isArray(headers2)) {
        this.changed = true;
        this.headers = false;
        this.parsed = true;
        this.lines = headers2;
      } else {
        this.changed = false;
        this.headers = headers2;
        this.parsed = false;
        this.lines = false;
      }
      this.mbox = false;
      this.http = false;
      this.libmime = new libmime.Libmime({ Iconv: config.Iconv });
    }
    hasHeader(key) {
      if (!this.parsed) {
        this._parseHeaders();
      }
      key = this._normalizeHeader(key);
      return typeof this.lines.find((line) => line.key === key) === "object";
    }
    get(key) {
      if (!this.parsed) {
        this._parseHeaders();
      }
      key = this._normalizeHeader(key);
      let lines = this.lines.filter((line) => line.key === key).map((line) => line.line);
      return lines;
    }
    getDecoded(key) {
      return this.get(key).map((line) => this.libmime.decodeHeader(line)).filter((line) => line && line.value);
    }
    getFirst(key) {
      if (!this.parsed) {
        this._parseHeaders();
      }
      key = this._normalizeHeader(key);
      let header = this.lines.find((line) => line.key === key);
      if (!header) {
        return "";
      }
      return ((this.libmime.decodeHeader(header.line) || {}).value || "").toString().trim();
    }
    getList() {
      if (!this.parsed) {
        this._parseHeaders();
      }
      return this.lines;
    }
    add(key, value, index) {
      if (typeof value === "undefined") {
        return;
      }
      if (typeof value === "number") {
        value = value.toString();
      }
      if (typeof value === "string") {
        value = Buffer.from(value);
      }
      value = value.toString("binary");
      this.addFormatted(key, this.libmime.foldLines(key + ": " + value.replace(/\r?\n/g, ""), 76, false), index);
    }
    addFormatted(key, line, index) {
      if (!this.parsed) {
        this._parseHeaders();
      }
      index = index || 0;
      this.changed = true;
      if (!line) {
        return;
      }
      if (typeof line !== "string") {
        line = line.toString("binary");
      }
      let header = {
        key: this._normalizeHeader(key),
        line
      };
      if (index < 1) {
        this.lines.unshift(header);
      } else if (index >= this.lines.length) {
        this.lines.push(header);
      } else {
        this.lines.splice(index, 0, header);
      }
    }
    remove(key) {
      if (!this.parsed) {
        this._parseHeaders();
      }
      key = this._normalizeHeader(key);
      for (let i = this.lines.length - 1; i >= 0; i--) {
        if (this.lines[i].key === key) {
          this.changed = true;
          this.lines.splice(i, 1);
        }
      }
    }
    update(key, value, relativeIndex) {
      if (!this.parsed) {
        this._parseHeaders();
      }
      let keyName = key;
      let index = 0;
      key = this._normalizeHeader(key);
      let relativeIndexCount = 0;
      let relativeMatchFound = false;
      for (let i = this.lines.length - 1; i >= 0; i--) {
        if (this.lines[i].key === key) {
          if (relativeIndex && relativeIndex !== relativeIndexCount) {
            relativeIndexCount++;
            continue;
          }
          index = i;
          this.changed = true;
          this.lines.splice(i, 1);
          if (relativeIndex) {
            relativeMatchFound = true;
            break;
          }
        }
      }
      if (relativeIndex && !relativeMatchFound) {
        return;
      }
      this.add(keyName, value, index);
    }
    build(lineEnd) {
      if (!this.changed && !lineEnd) {
        return typeof this.headers === "string" ? Buffer.from(this.headers, "binary") : this.headers;
      }
      if (!this.parsed) {
        this._parseHeaders();
      }
      lineEnd = lineEnd || "\r\n";
      let headers2 = this.lines.map((line) => line.line.replace(/\r?\n/g, lineEnd)).join(lineEnd) + `${lineEnd}${lineEnd}`;
      if (this.mbox) {
        headers2 = this.mbox + lineEnd + headers2;
      }
      if (this.http) {
        headers2 = this.http + lineEnd + headers2;
      }
      return Buffer.from(headers2, "binary");
    }
    _normalizeHeader(key) {
      return (key || "").toLowerCase().trim();
    }
    _parseHeaders() {
      if (!this.headers) {
        this.lines = [];
        this.parsed = true;
        return;
      }
      let lines = this.headers.toString("binary").replace(/[\r\n]+$/, "").split(/\r?\n/);
      for (let i = lines.length - 1; i >= 0; i--) {
        let chr = lines[i].charAt(0);
        if (i && (chr === " " || chr === "	")) {
          lines[i - 1] += "\r\n" + lines[i];
          lines.splice(i, 1);
        } else {
          let line = lines[i];
          if (!i && /^From /i.test(line)) {
            this.mbox = line;
            lines.splice(i, 1);
            continue;
          } else if (!i && /^POST /i.test(line)) {
            this.http = line;
            lines.splice(i, 1);
            continue;
          }
          let key = this._normalizeHeader(line.substr(0, line.indexOf(":")));
          lines[i] = {
            key,
            line
          };
        }
      }
      this.lines = lines;
      this.parsed = true;
    }
  }
  headers = Headers;
  return headers;
}
var mimeNode;
var hasRequiredMimeNode;
function requireMimeNode() {
  if (hasRequiredMimeNode) return mimeNode;
  hasRequiredMimeNode = 1;
  const Headers = /* @__PURE__ */ requireHeaders();
  const libmime = /* @__PURE__ */ requireLibmime();
  const libqp = /* @__PURE__ */ requireLibqp();
  const libbase64 = /* @__PURE__ */ requireLibbase64();
  const PassThrough = require$$0.PassThrough;
  const pathlib = require$$1;
  class MimeNode {
    constructor(parentNode, config) {
      this.type = "node";
      this.root = !parentNode;
      this.parentNode = parentNode;
      this._parentBoundary = this.parentNode && this.parentNode._boundary;
      this._headersLines = [];
      this._headerlen = 0;
      this._parsedContentType = false;
      this._boundary = false;
      this.multipart = false;
      this.encoding = false;
      this.headers = false;
      this.contentType = false;
      this.flowed = false;
      this.delSp = false;
      this.config = config || {};
      this.libmime = new libmime.Libmime({ Iconv: this.config.Iconv });
      this.parentPartNumber = parentNode && this.partNr || [];
      this.partNr = false;
      this.childPartNumbers = 0;
    }
    getPartNr(provided) {
      if (provided) {
        return [].concat(this.partNr || []).filter((nr) => !isNaN(nr)).concat(provided);
      }
      let childPartNr = ++this.childPartNumbers;
      return [].concat(this.partNr || []).filter((nr) => !isNaN(nr)).concat(childPartNr);
    }
    addHeaderChunk(line) {
      if (!line) {
        return;
      }
      this._headersLines.push(line);
      this._headerlen += line.length;
    }
    parseHeaders() {
      if (this.headers) {
        return;
      }
      this.headers = new Headers(Buffer.concat(this._headersLines, this._headerlen), this.config);
      this._parsedContentDisposition = this.libmime.parseHeaderValue(this.headers.getFirst("Content-Disposition"));
      let contentHeader;
      if (this.headers.get("Content-Type").length) {
        contentHeader = this.headers.getFirst("Content-Type");
      } else {
        if (this._parsedContentDisposition.params.filename) {
          let extension = pathlib.parse(this._parsedContentDisposition.params.filename).ext.replace(/^\./, "");
          if (extension) {
            contentHeader = libmime.detectMimeType(extension);
          }
        }
        if (!contentHeader) {
          if (/^attachment$/i.test(this._parsedContentDisposition.value)) {
            contentHeader = "application/octet-stream";
          } else {
            contentHeader = "text/plain";
          }
        }
      }
      this._parsedContentType = this.libmime.parseHeaderValue(contentHeader);
      this.encoding = this.headers.getFirst("Content-Transfer-Encoding").replace(/\(.*\)/g, "").toLowerCase().trim();
      this.contentType = (this._parsedContentType.value || "").toLowerCase().trim() || false;
      this.charset = this._parsedContentType.params.charset || false;
      this.disposition = (this._parsedContentDisposition.value || "").toLowerCase().trim() || false;
      if (this.disposition) {
        try {
          this.disposition = this.libmime.decodeWords(this.disposition);
        } catch (E) {
        }
      }
      this.filename = this._parsedContentDisposition.params.filename || this._parsedContentType.params.name || false;
      if (this._parsedContentType.params.format && this._parsedContentType.params.format.toLowerCase().trim() === "flowed") {
        this.flowed = true;
        if (this._parsedContentType.params.delsp && this._parsedContentType.params.delsp.toLowerCase().trim() === "yes") {
          this.delSp = true;
        }
      }
      if (this.filename) {
        try {
          this.filename = this.libmime.decodeWords(this.filename);
        } catch (E) {
        }
      }
      this.multipart = this.contentType && this.contentType.substr(0, this.contentType.indexOf("/")) === "multipart" && this.contentType.substr(this.contentType.indexOf("/") + 1) || false;
      this._boundary = this._parsedContentType.params.boundary && Buffer.from(this._parsedContentType.params.boundary) || false;
      this.rfc822 = this.contentType === "message/rfc822";
      if (!this.parentNode || this.parentNode.rfc822) {
        this.partNr = this.parentNode ? this.parentNode.getPartNr("TEXT") : ["TEXT"];
      } else {
        this.partNr = this.parentNode ? this.parentNode.getPartNr() : [];
      }
    }
    getHeaders() {
      if (!this.headers) {
        this.parseHeaders();
      }
      return this.headers.build();
    }
    setContentType(contentType) {
      if (!this.headers) {
        this.parseHeaders();
      }
      contentType = (contentType || "").toLowerCase().trim();
      if (contentType) {
        this._parsedContentType.value = contentType;
      }
      if (!this.flowed && this._parsedContentType.params.format) {
        delete this._parsedContentType.params.format;
      }
      if (!this.delSp && this._parsedContentType.params.delsp) {
        delete this._parsedContentType.params.delsp;
      }
      this.headers.update("Content-Type", this.libmime.buildHeaderValue(this._parsedContentType));
    }
    setCharset(charset) {
      if (!this.headers) {
        this.parseHeaders();
      }
      charset = (charset || "").toLowerCase().trim();
      if (charset === "ascii") {
        charset = "";
      }
      if (!charset) {
        if (!this._parsedContentType.value) {
          return;
        }
        delete this._parsedContentType.params.charset;
      } else {
        this._parsedContentType.params.charset = charset;
      }
      if (!this._parsedContentType.value) {
        this._parsedContentType.value = "text/plain";
      }
      this.headers.update("Content-Type", this.libmime.buildHeaderValue(this._parsedContentType));
    }
    setFilename(filename) {
      if (!this.headers) {
        this.parseHeaders();
      }
      this.filename = (filename || "").toLowerCase().trim();
      if (this._parsedContentType.params.name) {
        delete this._parsedContentType.params.name;
        this.headers.update("Content-Type", this.libmime.buildHeaderValue(this._parsedContentType));
      }
      if (!this.filename) {
        if (!this._parsedContentDisposition.value) {
          return;
        }
        delete this._parsedContentDisposition.params.filename;
      } else {
        this._parsedContentDisposition.params.filename = this.filename;
      }
      if (!this._parsedContentDisposition.value) {
        this._parsedContentDisposition.value = "attachment";
      }
      this.headers.update("Content-Disposition", this.libmime.buildHeaderValue(this._parsedContentDisposition));
    }
    getDecoder() {
      if (!this.headers) {
        this.parseHeaders();
      }
      switch (this.encoding) {
        case "base64":
          return new libbase64.Decoder();
        case "quoted-printable":
          return new libqp.Decoder();
        default:
          return new PassThrough();
      }
    }
    getEncoder(encoding) {
      if (!this.headers) {
        this.parseHeaders();
      }
      encoding = (encoding || "").toString().toLowerCase().trim();
      if (encoding && encoding !== this.encoding) {
        this.headers.update("Content-Transfer-Encoding", encoding);
      } else {
        encoding = this.encoding;
      }
      switch (encoding) {
        case "base64":
          return new libbase64.Encoder();
        case "quoted-printable":
          return new libqp.Encoder();
        default:
          return new PassThrough();
      }
    }
  }
  mimeNode = MimeNode;
  return mimeNode;
}
var messageSplitter;
var hasRequiredMessageSplitter;
function requireMessageSplitter() {
  if (hasRequiredMessageSplitter) return messageSplitter;
  hasRequiredMessageSplitter = 1;
  const Transform = require$$0.Transform;
  const MimeNode = /* @__PURE__ */ requireMimeNode();
  const MAX_HEAD_SIZE = 1 * 1024 * 1024;
  const MAX_CHILD_NODES = 1e3;
  const HEAD = 1;
  const BODY = 2;
  class MessageSplitter extends Transform {
    constructor(config) {
      let options = {
        readableObjectMode: true,
        writableObjectMode: false
      };
      super(options);
      this.config = config || {};
      this.maxHeadSize = this.config.maxHeadSize || MAX_HEAD_SIZE;
      this.maxChildNodes = this.config.maxChildNodes || MAX_CHILD_NODES;
      this.tree = [];
      this.nodeCounter = 0;
      this.newNode();
      this.tree.push(this.node);
      this.line = false;
      this.hasFailed = false;
    }
    _transform(chunk, encoding, callback) {
      let pos = 0;
      let i = 0;
      let group = {
        type: "none"
      };
      let groupstart = this.line ? -this.line.length : 0;
      let groupend = 0;
      let checkTrailingLinebreak = (data) => {
        if (data.type === "body" && data.node.parentNode && data.value && data.value.length) {
          if (data.value[data.value.length - 1] === 10) {
            groupstart--;
            groupend--;
            pos--;
            if (data.value.length > 1 && data.value[data.value.length - 2] === 13) {
              groupstart--;
              groupend--;
              pos--;
              if (groupstart < 0 && !this.line) {
                this.line = Buffer.allocUnsafe(1);
                this.line[0] = 13;
              }
              data.value = data.value.slice(0, data.value.length - 2);
            } else {
              data.value = data.value.slice(0, data.value.length - 1);
            }
          } else if (data.value[data.value.length - 1] === 13) {
            groupstart--;
            groupend--;
            pos--;
            data.value = data.value.slice(0, data.value.length - 1);
          }
        }
      };
      let iterateData = () => {
        for (let len = chunk.length; i < len; i++) {
          if (chunk[i] === 10) {
            let start = Math.max(pos, 0);
            pos = ++i;
            return this.processLine(chunk.slice(start, i), false, (err, data, flush) => {
              if (err) {
                this.hasFailed = true;
                return setImmediate(() => callback(err));
              }
              if (!data) {
                return setImmediate(iterateData);
              }
              if (flush) {
                if (group && group.type !== "none") {
                  if (group.type === "body" && groupend >= groupstart && group.node.parentNode) {
                    if (chunk[groupend - 1] === 10) {
                      groupend--;
                      if (groupend >= groupstart && chunk[groupend - 1] === 13) {
                        groupend--;
                      }
                    }
                  }
                  if (groupstart !== groupend) {
                    group.value = chunk.slice(groupstart, groupend);
                    if (groupend < i) {
                      data.value = chunk.slice(groupend, i);
                    }
                  }
                  this.push(group);
                  group = {
                    type: "none"
                  };
                  groupstart = groupend = i;
                }
                this.push(data);
                groupend = i;
                return setImmediate(iterateData);
              }
              if (data.type === group.type) {
                groupend = i;
              } else {
                if (group.type === "body" && groupend >= groupstart && group.node.parentNode) {
                  if (chunk[groupend - 1] === 10) {
                    groupend--;
                    if (groupend >= groupstart && chunk[groupend - 1] === 13) {
                      groupend--;
                    }
                  }
                }
                if (group.type !== "none" && group.type !== "node") {
                  if (groupstart !== groupend) {
                    group.value = chunk.slice(groupstart, groupend);
                    if (group.value && group.value.length) {
                      this.push(group);
                      group = {
                        type: "none"
                      };
                    }
                  }
                }
                if (data.type === "node") {
                  this.push(data);
                  groupstart = i;
                  groupend = i;
                } else if (groupstart < 0) {
                  groupstart = i;
                  groupend = i;
                  checkTrailingLinebreak(data);
                  if (data.value && data.value.length) {
                    this.push(data);
                  }
                } else {
                  group = data;
                  groupstart = groupend;
                  groupend = i;
                }
              }
              return setImmediate(iterateData);
            });
          }
        }
        if (pos >= groupstart + 1 && group.type === "body" && group.node.parentNode) {
          if (chunk[pos - 1] === 10) {
            pos--;
            if (pos >= groupstart && chunk[pos - 1] === 13) {
              pos--;
            }
          }
        }
        if (group.type !== "none" && group.type !== "node" && pos > groupstart) {
          group.value = chunk.slice(groupstart, pos);
          if (group.value && group.value.length) {
            this.push(group);
            group = {
              type: "none"
            };
          }
        }
        if (pos < chunk.length) {
          if (this.line) {
            this.line = Buffer.concat([this.line, chunk.slice(pos)]);
          } else {
            this.line = chunk.slice(pos);
          }
        }
        callback();
      };
      setImmediate(iterateData);
    }
    _flush(callback) {
      if (this.hasFailed) {
        return callback();
      }
      this.processLine(false, true, (err, data) => {
        if (err) {
          return setImmediate(() => callback(err));
        }
        if (data && (data.type === "node" || data.value && data.value.length)) {
          this.push(data);
        }
        callback();
      });
    }
    compareBoundary(line, startpos, boundary) {
      if (line.length < boundary.length + 3 + startpos || line.length > boundary.length + 6 + startpos) {
        return false;
      }
      for (let i = 0; i < boundary.length; i++) {
        if (line[i + 2 + startpos] !== boundary[i]) {
          return false;
        }
      }
      let pos = 0;
      for (let i = boundary.length + 2 + startpos; i < line.length; i++) {
        let c = line[i];
        if (pos === 0 && (c === 13 || c === 10)) {
          return 1;
        }
        if (pos === 0 && c !== 45) {
          return false;
        }
        if (pos === 1 && c !== 45) {
          return false;
        }
        if (pos === 2 && c !== 13 && c !== 10) {
          return false;
        }
        if (pos === 3 && c !== 10) {
          return false;
        }
        pos++;
      }
      return 2;
    }
    checkBoundary(line) {
      let startpos = 0;
      if (line.length >= 1 && (line[0] === 13 || line[0] === 10)) {
        startpos++;
        if (line.length >= 2 && (line[0] === 13 || line[1] === 10)) {
          startpos++;
        }
      }
      if (line.length < 4 || line[startpos] !== 45 || line[startpos + 1] !== 45) {
        return false;
      }
      let boundary;
      if (this.node._boundary && (boundary = this.compareBoundary(line, startpos, this.node._boundary))) {
        return boundary;
      }
      if (this.node._parentBoundary && (boundary = this.compareBoundary(line, startpos, this.node._parentBoundary))) {
        return boundary + 2;
      }
      return false;
    }
    processLine(line, final, next) {
      let flush = false;
      if (this.line && line) {
        line = Buffer.concat([this.line, line]);
        this.line = false;
      } else if (this.line && !line) {
        line = this.line;
        this.line = false;
      }
      if (!line) {
        line = Buffer.alloc(0);
      }
      if (this.nodeCounter > this.maxChildNodes) {
        let err = new Error("Max allowed child nodes exceeded");
        err.code = "EMAXLEN";
        return next(err);
      }
      let boundary = this.checkBoundary(line);
      if (boundary) {
        switch (boundary) {
          case 1:
            this.newNode(this.node);
            flush = true;
            break;
          case 2:
            break;
          case 3: {
            let parentNode = this.node.parentNode;
            if (parentNode && parentNode.contentType === "message/rfc822") {
              parentNode = parentNode.parentNode;
            }
            this.newNode(parentNode);
            flush = true;
            break;
          }
          case 4:
            if (this.node && this.node._headerlen && !this.node.headers) {
              this.node.parseHeaders();
              this.push(this.node);
            }
            if (this.tree.length) {
              this.node = this.tree.pop();
            }
            this.state = BODY;
            break;
        }
        return next(
          null,
          {
            node: this.node,
            type: "data",
            value: line
          },
          flush
        );
      }
      switch (this.state) {
        case HEAD: {
          this.node.addHeaderChunk(line);
          if (this.node._headerlen > this.maxHeadSize) {
            let err = new Error("Max header size for a MIME node exceeded");
            err.code = "EMAXLEN";
            return next(err);
          }
          if (final || line.length === 1 && line[0] === 10 || line.length === 2 && line[0] === 13 && line[1] === 10) {
            let currentNode = this.node;
            currentNode.parseHeaders();
            if (currentNode.contentType === "message/rfc822" && !this.config.ignoreEmbedded && (!currentNode.encoding || ["7bit", "8bit", "binary"].includes(currentNode.encoding)) && (this.config.defaultInlineEmbedded ? currentNode.disposition !== "attachment" : currentNode.disposition === "inline")) {
              currentNode.messageNode = true;
              this.newNode(currentNode);
              if (currentNode.parentNode) {
                this.node._parentBoundary = currentNode.parentNode._boundary;
              }
            } else {
              if (currentNode.contentType === "message/rfc822") {
                currentNode.messageNode = false;
              }
              this.state = BODY;
              if (currentNode.multipart && currentNode._boundary) {
                this.tree.push(currentNode);
              }
            }
            return next(null, currentNode, flush);
          }
          return next();
        }
        case BODY: {
          return next(
            null,
            {
              node: this.node,
              type: this.node.multipart ? "data" : "body",
              value: line
            },
            flush
          );
        }
      }
      next(null, false);
    }
    newNode(parent) {
      this.node = new MimeNode(parent || false, this.config);
      this.state = HEAD;
      this.nodeCounter++;
    }
  }
  messageSplitter = MessageSplitter;
  return messageSplitter;
}
var messageJoiner;
var hasRequiredMessageJoiner;
function requireMessageJoiner() {
  if (hasRequiredMessageJoiner) return messageJoiner;
  hasRequiredMessageJoiner = 1;
  const Transform = require$$0.Transform;
  class MessageJoiner extends Transform {
    constructor() {
      let options = {
        readableObjectMode: false,
        writableObjectMode: true
      };
      super(options);
    }
    _transform(obj, encoding, callback) {
      if (Buffer.isBuffer(obj)) {
        this.push(obj);
      } else if (obj.type === "node") {
        this.push(obj.getHeaders());
      } else if (obj.value) {
        this.push(obj.value);
      }
      return callback();
    }
    _flush(callback) {
      return callback();
    }
  }
  messageJoiner = MessageJoiner;
  return messageJoiner;
}
var flowedDecoder;
var hasRequiredFlowedDecoder;
function requireFlowedDecoder() {
  if (hasRequiredFlowedDecoder) return flowedDecoder;
  hasRequiredFlowedDecoder = 1;
  const Transform = require$$0.Transform;
  const libmime = /* @__PURE__ */ requireLibmime();
  class FlowedDecoder extends Transform {
    constructor(config) {
      super();
      this.config = config || {};
      this.chunks = [];
      this.chunklen = 0;
      this.libmime = new libmime.Libmime({ Iconv: config.Iconv });
    }
    _transform(chunk, encoding, callback) {
      if (!chunk || !chunk.length) {
        return callback();
      }
      if (!encoding !== "buffer") {
        chunk = Buffer.from(chunk, encoding);
      }
      this.chunks.push(chunk);
      this.chunklen += chunk.length;
      callback();
    }
    _flush(callback) {
      if (this.chunklen) {
        let currentBody = Buffer.concat(this.chunks, this.chunklen);
        if (this.config.encoding === "base64") {
          currentBody = Buffer.from(currentBody.toString("binary"), "base64");
        }
        let content = this.libmime.decodeFlowed(currentBody.toString("binary"), this.config.delSp);
        this.push(Buffer.from(content, "binary"));
      }
      return callback();
    }
  }
  flowedDecoder = FlowedDecoder;
  return flowedDecoder;
}
var nodeRewriter;
var hasRequiredNodeRewriter;
function requireNodeRewriter() {
  if (hasRequiredNodeRewriter) return nodeRewriter;
  hasRequiredNodeRewriter = 1;
  const Transform = require$$0.Transform;
  const FlowedDecoder = /* @__PURE__ */ requireFlowedDecoder();
  class NodeRewriter extends Transform {
    constructor(filterFunc, rewriteAction) {
      let options = {
        readableObjectMode: true,
        writableObjectMode: true
      };
      super(options);
      this.filterFunc = filterFunc;
      this.rewriteAction = rewriteAction;
      this.decoder = false;
      this.encoder = false;
      this.continue = false;
    }
    _transform(data, encoding, callback) {
      this.processIncoming(data, callback);
    }
    _flush(callback) {
      if (this.decoder) {
        return this.processIncoming(
          {
            type: "none"
          },
          callback
        );
      }
      return callback();
    }
    processIncoming(data, callback) {
      if (this.decoder && data.type === "body") {
        if (!this.decoder.write(data.value)) {
          return this.decoder.once("drain", callback);
        } else {
          return callback();
        }
      } else if (this.decoder && data.type !== "body") {
        this.continue = () => {
          this.continue = false;
          this.decoder = false;
          this.encoder = false;
          this.processIncoming(data, callback);
        };
        return this.decoder.end();
      } else if (data.type === "node" && this.filterFunc(data)) {
        this.emit("node", this.createDecodePair(data));
      } else if (this.readable && data.type !== "none") {
        this.push(data);
      }
      callback();
    }
    createDecodePair(node) {
      this.decoder = node.getDecoder();
      if (["base64", "quoted-printable"].includes(node.encoding)) {
        this.encoder = node.getEncoder();
      } else {
        this.encoder = node.getEncoder("quoted-printable");
      }
      let lastByte = false;
      let decoder = this.decoder;
      let encoder = this.encoder;
      let firstChunk = true;
      decoder.$reading = false;
      let readFromEncoder = () => {
        decoder.$reading = true;
        let data = encoder.read();
        if (data === null) {
          decoder.$reading = false;
          return;
        }
        if (firstChunk) {
          firstChunk = false;
          if (this.readable) {
            this.push(node);
            if (node.type === "body") {
              lastByte = node.value && node.value.length && node.value[node.value.length - 1];
            }
          }
        }
        let writeMore = true;
        if (this.readable) {
          writeMore = this.push({
            node,
            type: "body",
            value: data
          });
          lastByte = data && data.length && data[data.length - 1];
        }
        if (writeMore) {
          return setImmediate(readFromEncoder);
        } else {
          encoder.pause();
          setTimeout(() => {
            encoder.resume();
            setImmediate(readFromEncoder);
          }, 100);
        }
      };
      encoder.on("readable", () => {
        if (!decoder.$reading) {
          return readFromEncoder();
        }
      });
      encoder.on("end", () => {
        if (firstChunk) {
          firstChunk = false;
          if (this.readable) {
            this.push(node);
            if (node.type === "body") {
              lastByte = node.value && node.value.length && node.value[node.value.length - 1];
            }
          }
        }
        if (lastByte !== 10) {
          this.push({
            node,
            type: "body",
            value: Buffer.from([10])
          });
        }
        if (this.continue) {
          return this.continue();
        }
      });
      if (/^text\//.test(node.contentType) && node.flowed) {
        let flowDecoder = decoder;
        decoder = new FlowedDecoder({
          delSp: node.delSp,
          encoding: node.encoding
        });
        flowDecoder.on("error", (err) => {
          decoder.emit("error", err);
        });
        flowDecoder.pipe(decoder);
        node.flowed = false;
        node.delSp = false;
        node.setContentType();
      }
      return {
        node,
        decoder,
        encoder
      };
    }
  }
  nodeRewriter = NodeRewriter;
  return nodeRewriter;
}
var nodeStreamer;
var hasRequiredNodeStreamer;
function requireNodeStreamer() {
  if (hasRequiredNodeStreamer) return nodeStreamer;
  hasRequiredNodeStreamer = 1;
  const Transform = require$$0.Transform;
  const FlowedDecoder = /* @__PURE__ */ requireFlowedDecoder();
  class NodeStreamer extends Transform {
    constructor(filterFunc, streamAction) {
      let options = {
        readableObjectMode: true,
        writableObjectMode: true
      };
      super(options);
      this.filterFunc = filterFunc;
      this.streamAction = streamAction;
      this.decoder = false;
      this.canContinue = false;
      this.continue = false;
    }
    _transform(data, encoding, callback) {
      this.processIncoming(data, callback);
    }
    _flush(callback) {
      if (this.decoder) {
        return this.processIncoming(
          {
            type: "none"
          },
          callback
        );
      }
      return callback();
    }
    processIncoming(data, callback) {
      if (this.decoder && data.type === "body") {
        this.push(data);
        if (!this.decoder.write(data.value)) {
          return this.decoder.once("drain", callback);
        } else {
          return callback();
        }
      } else if (this.decoder && data.type !== "body") {
        let doContinue = () => {
          this.continue = false;
          this.decoder = false;
          this.canContinue = false;
          this.processIncoming(data, callback);
        };
        if (this.canContinue) {
          setImmediate(doContinue);
        } else {
          this.continue = () => doContinue();
        }
        return this.decoder.end();
      } else if (data.type === "node" && this.filterFunc(data)) {
        this.push(data);
        this.emit("node", this.createDecoder(data));
      } else if (this.readable && data.type !== "none") {
        this.push(data);
      }
      callback();
    }
    createDecoder(node) {
      this.decoder = node.getDecoder();
      let decoder = this.decoder;
      decoder.$reading = false;
      if (/^text\//.test(node.contentType) && node.flowed) {
        let flowDecoder = decoder;
        decoder = new FlowedDecoder({
          delSp: node.delSp
        });
        flowDecoder.on("error", (err) => {
          decoder.emit("error", err);
        });
        flowDecoder.pipe(decoder);
      }
      return {
        node,
        decoder,
        done: () => {
          if (typeof this.continue === "function") {
            this.continue();
          } else {
            this.canContinue = true;
          }
        }
      };
    }
  }
  nodeStreamer = NodeStreamer;
  return nodeStreamer;
}
var chunkedPassthrough;
var hasRequiredChunkedPassthrough;
function requireChunkedPassthrough() {
  if (hasRequiredChunkedPassthrough) return chunkedPassthrough;
  hasRequiredChunkedPassthrough = 1;
  const { Transform } = require$$0;
  class ChunkedPassthrough extends Transform {
    constructor(options = {}) {
      let config = {
        readableObjectMode: true,
        writableObjectMode: false
      };
      super(config);
      this.chunkSize = options.chunkSize || 64 * 1024;
      this.buffer = Buffer.alloc(0);
    }
    _transform(chunk, encoding, callback) {
      this.buffer = Buffer.concat([this.buffer, chunk]);
      if (this.buffer.length >= this.chunkSize) {
        this.push(this.buffer);
        this.buffer = Buffer.alloc(0);
      }
      callback();
    }
    _flush(callback) {
      if (this.buffer.length > 0) {
        this.push(this.buffer);
        this.buffer = Buffer.alloc(0);
      }
      callback();
    }
  }
  chunkedPassthrough = ChunkedPassthrough;
  return chunkedPassthrough;
}
var mailsplit;
var hasRequiredMailsplit;
function requireMailsplit() {
  if (hasRequiredMailsplit) return mailsplit;
  hasRequiredMailsplit = 1;
  const MessageSplitter = /* @__PURE__ */ requireMessageSplitter();
  const MessageJoiner = /* @__PURE__ */ requireMessageJoiner();
  const NodeRewriter = /* @__PURE__ */ requireNodeRewriter();
  const NodeStreamer = /* @__PURE__ */ requireNodeStreamer();
  const Headers = /* @__PURE__ */ requireHeaders();
  const ChunkedPassthrough = /* @__PURE__ */ requireChunkedPassthrough();
  mailsplit = {
    Splitter: MessageSplitter,
    Joiner: MessageJoiner,
    Rewriter: NodeRewriter,
    Streamer: NodeStreamer,
    ChunkedPassthrough,
    Headers
  };
  return mailsplit;
}
export {
  requireFlowedDecoder as a,
  requireMailsplit as r
};
