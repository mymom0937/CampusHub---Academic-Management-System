import { r as reactExports } from "../react.mjs";
var useLayoutEffect2 = globalThis?.document ? reactExports.useLayoutEffect : () => {
};
export {
  useLayoutEffect2 as u
};
