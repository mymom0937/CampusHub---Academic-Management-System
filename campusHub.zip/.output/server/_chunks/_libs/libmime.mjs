import require$$0 from "node:buffer";
import { r as requireLib } from "./iconv-lite.mjs";
import { r as requireSrc } from "../../_libs/encoding-japanese.mjs";
import { r as requireLibbase64 } from "./libbase64.mjs";
import { r as requireLibqp } from "../../_libs/libqp.mjs";
var libmime = { exports: {} };
var charset = { exports: {} };
var charsets;
var hasRequiredCharsets;
function requireCharsets() {
  if (hasRequiredCharsets) return charsets;
  hasRequiredCharsets = 1;
  charsets = {
    "866": "IBM866",
    "unicode-1-1-utf-8": "UTF-8",
    "utf-8": "UTF-8",
    utf8: "UTF-8",
    cp866: "IBM866",
    csibm866: "IBM866",
    ibm866: "IBM866",
    csisolatin2: "ISO-8859-2",
    "iso-8859-2": "ISO-8859-2",
    "iso-ir-101": "ISO-8859-2",
    "iso8859-2": "ISO-8859-2",
    iso88592: "ISO-8859-2",
    "iso_8859-2": "ISO-8859-2",
    "iso_8859-2:1987": "ISO-8859-2",
    l2: "ISO-8859-2",
    latin2: "ISO-8859-2",
    csisolatin3: "ISO-8859-3",
    "iso-8859-3": "ISO-8859-3",
    "iso-ir-109": "ISO-8859-3",
    "iso8859-3": "ISO-8859-3",
    iso88593: "ISO-8859-3",
    "iso_8859-3": "ISO-8859-3",
    "iso_8859-3:1988": "ISO-8859-3",
    l3: "ISO-8859-3",
    latin3: "ISO-8859-3",
    csisolatin4: "ISO-8859-4",
    "iso-8859-4": "ISO-8859-4",
    "iso-ir-110": "ISO-8859-4",
    "iso8859-4": "ISO-8859-4",
    iso88594: "ISO-8859-4",
    "iso_8859-4": "ISO-8859-4",
    "iso_8859-4:1988": "ISO-8859-4",
    l4: "ISO-8859-4",
    latin4: "ISO-8859-4",
    csisolatincyrillic: "ISO-8859-5",
    cyrillic: "ISO-8859-5",
    "iso-8859-5": "ISO-8859-5",
    "iso-ir-144": "ISO-8859-5",
    "iso8859-5": "ISO-8859-5",
    iso88595: "ISO-8859-5",
    "iso_8859-5": "ISO-8859-5",
    "iso_8859-5:1988": "ISO-8859-5",
    arabic: "ISO-8859-6",
    "asmo-708": "ISO-8859-6",
    csiso88596e: "ISO-8859-6",
    csiso88596i: "ISO-8859-6",
    csisolatinarabic: "ISO-8859-6",
    "ecma-114": "ISO-8859-6",
    "iso-8859-6": "ISO-8859-6",
    "iso-8859-6-e": "ISO-8859-6",
    "iso-8859-6-i": "ISO-8859-6",
    "iso-ir-127": "ISO-8859-6",
    "iso8859-6": "ISO-8859-6",
    iso88596: "ISO-8859-6",
    "iso_8859-6": "ISO-8859-6",
    "iso_8859-6:1987": "ISO-8859-6",
    csisolatingreek: "ISO-8859-7",
    "ecma-118": "ISO-8859-7",
    elot_928: "ISO-8859-7",
    greek: "ISO-8859-7",
    greek8: "ISO-8859-7",
    "iso-8859-7": "ISO-8859-7",
    "iso-ir-126": "ISO-8859-7",
    "iso8859-7": "ISO-8859-7",
    iso88597: "ISO-8859-7",
    "iso_8859-7": "ISO-8859-7",
    "iso_8859-7:1987": "ISO-8859-7",
    sun_eu_greek: "ISO-8859-7",
    csiso88598e: "ISO-8859-8",
    csisolatinhebrew: "ISO-8859-8",
    hebrew: "ISO-8859-8",
    "iso-8859-8": "ISO-8859-8",
    "iso-8859-8-e": "ISO-8859-8",
    "iso-8859-8-i": "ISO-8859-8",
    "iso-ir-138": "ISO-8859-8",
    "iso8859-8": "ISO-8859-8",
    iso88598: "ISO-8859-8",
    "iso_8859-8": "ISO-8859-8",
    "iso_8859-8:1988": "ISO-8859-8",
    visual: "ISO-8859-8",
    csisolatin6: "ISO-8859-10",
    "iso-8859-10": "ISO-8859-10",
    "iso-ir-157": "ISO-8859-10",
    "iso8859-10": "ISO-8859-10",
    iso885910: "ISO-8859-10",
    l6: "ISO-8859-10",
    latin6: "ISO-8859-10",
    "iso-8859-13": "ISO-8859-13",
    "iso8859-13": "ISO-8859-13",
    iso885913: "ISO-8859-13",
    "iso-8859-14": "ISO-8859-14",
    "iso8859-14": "ISO-8859-14",
    iso885914: "ISO-8859-14",
    csisolatin9: "ISO-8859-15",
    "iso-8859-15": "ISO-8859-15",
    "iso8859-15": "ISO-8859-15",
    iso885915: "ISO-8859-15",
    "iso_8859-15": "ISO-8859-15",
    l9: "ISO-8859-15",
    "iso-8859-16": "ISO-8859-16",
    cskoi8r: "KOI8-R",
    koi: "KOI8-R",
    koi8: "KOI8-R",
    "koi8-r": "KOI8-R",
    koi8_r: "KOI8-R",
    "koi8-ru": "KOI8-U",
    "koi8-u": "KOI8-U",
    csmacintosh: "macintosh",
    mac: "macintosh",
    macintosh: "macintosh",
    "x-mac-roman": "macintosh",
    "dos-874": "windows-874",
    "iso-8859-11": "windows-874",
    "iso8859-11": "windows-874",
    iso885911: "windows-874",
    "tis-620": "windows-874",
    "windows-874": "windows-874",
    cp1250: "windows-1250",
    "windows-1250": "windows-1250",
    "x-cp1250": "windows-1250",
    cp1251: "windows-1251",
    "windows-1251": "windows-1251",
    "x-cp1251": "windows-1251",
    "ansi_x3.4-1968": "windows-1252",
    ascii: "windows-1252",
    cp1252: "windows-1252",
    cp819: "windows-1252",
    csisolatin1: "windows-1252",
    ibm819: "windows-1252",
    "iso-8859-1": "windows-1252",
    "iso-ir-100": "windows-1252",
    "iso8859-1": "windows-1252",
    iso88591: "windows-1252",
    "iso_8859-1": "windows-1252",
    "iso_8859-1:1987": "windows-1252",
    l1: "windows-1252",
    latin1: "windows-1252",
    "us-ascii": "windows-1252",
    "windows-1252": "windows-1252",
    "x-cp1252": "windows-1252",
    cp1253: "windows-1253",
    "windows-1253": "windows-1253",
    "x-cp1253": "windows-1253",
    cp1254: "windows-1254",
    csisolatin5: "windows-1254",
    "iso-8859-9": "windows-1254",
    "iso-ir-148": "windows-1254",
    "iso8859-9": "windows-1254",
    iso88599: "windows-1254",
    "iso_8859-9": "windows-1254",
    "iso_8859-9:1989": "windows-1254",
    l5: "windows-1254",
    latin5: "windows-1254",
    "windows-1254": "windows-1254",
    "x-cp1254": "windows-1254",
    cp1255: "windows-1255",
    "windows-1255": "windows-1255",
    "x-cp1255": "windows-1255",
    cp1256: "windows-1256",
    "windows-1256": "windows-1256",
    "x-cp1256": "windows-1256",
    cp1257: "windows-1257",
    "windows-1257": "windows-1257",
    "x-cp1257": "windows-1257",
    cp1258: "windows-1258",
    "windows-1258": "windows-1258",
    "x-cp1258": "windows-1258",
    chinese: "GBK",
    csgb2312: "GBK",
    csiso58gb231280: "GBK",
    gb2312: "GBK",
    gb_2312: "GBK",
    "gb_2312-80": "GBK",
    gbk: "GBK",
    "iso-ir-58": "GBK",
    "x-gbk": "GBK",
    gb18030: "gb18030",
    big5: "Big5",
    "big5-hkscs": "Big5",
    "cn-big5": "Big5",
    csbig5: "Big5",
    "x-x-big5": "Big5",
    cseucpkdfmtjapanese: "EUC-JP",
    "euc-jp": "EUC-JP",
    "x-euc-jp": "EUC-JP",
    csshiftjis: "Shift_JIS",
    ms932: "Shift_JIS",
    ms_kanji: "Shift_JIS",
    "shift-jis": "Shift_JIS",
    shift_jis: "Shift_JIS",
    sjis: "Shift_JIS",
    "windows-31j": "Shift_JIS",
    "x-sjis": "Shift_JIS",
    cseuckr: "EUC-KR",
    csksc56011987: "EUC-KR",
    "euc-kr": "EUC-KR",
    "iso-ir-149": "EUC-KR",
    korean: "EUC-KR",
    "ks_c_5601-1987": "EUC-KR",
    "ks_c_5601-1989": "EUC-KR",
    ksc5601: "EUC-KR",
    ksc_5601: "EUC-KR",
    "windows-949": "EUC-KR",
    "utf-16be": "UTF-16BE",
    "utf-16": "UTF-16LE",
    "utf-16le": "UTF-16LE"
  };
  return charsets;
}
var hasRequiredCharset;
function requireCharset() {
  if (hasRequiredCharset) return charset.exports;
  hasRequiredCharset = 1;
  const { Buffer } = require$$0;
  const iconv = /* @__PURE__ */ requireLib();
  const encodingJapanese = /* @__PURE__ */ requireSrc();
  const charsets2 = /* @__PURE__ */ requireCharsets();
  const charset$1 = charset.exports = {
    /**
     * Encodes an unicode string into an Buffer object as UTF-8
     *
     * We force UTF-8 here, no strange encodings allowed.
     *
     * @param {String} str String to be encoded
     * @return {Buffer} UTF-8 encoded typed array
     */
    encode(str) {
      return Buffer.from(str, "utf-8");
    },
    /**
     * Decodes a string from Buffer to an unicode string using specified encoding
     * NB! Throws if unknown charset is used
     *
     * @param {Buffer} buf Binary data to be decoded
     * @param {String} [fromCharset='UTF-8'] Binary data is decoded into string using this charset
     * @return {String} Decded string
     */
    decode(buf, fromCharset) {
      fromCharset = charset$1.normalizeCharset(fromCharset || "UTF-8");
      if (/^(us-)?ascii|utf-8|7bit$/i.test(fromCharset)) {
        return buf.toString("utf-8");
      }
      try {
        if (/^jis|^iso-?2022-?jp|^EUCJP/i.test(fromCharset)) {
          if (typeof buf === "string") {
            buf = Buffer.from(buf);
          }
          try {
            let output = encodingJapanese.convert(buf, {
              to: "UNICODE",
              from: fromCharset,
              type: "string"
            });
            if (typeof output === "string") {
              output = Buffer.from(output);
            }
            return output;
          } catch (err) {
          }
        }
        return iconv.decode(buf, fromCharset);
      } catch (err) {
        return buf.toString();
      }
    },
    /**
     * Convert a string from specific encoding to UTF-8 Buffer
     *
     * @param {String|Buffer} str String to be encoded
     * @param {String} [fromCharset='UTF-8'] Source encoding for the string
     * @return {Buffer} UTF-8 encoded typed array
     */
    convert(data, fromCharset) {
      fromCharset = charset$1.normalizeCharset(fromCharset || "UTF-8");
      let bufString;
      if (typeof data !== "string") {
        if (/^(us-)?ascii|utf-8|7bit$/i.test(fromCharset)) {
          return data;
        }
        bufString = charset$1.decode(data, fromCharset);
        return charset$1.encode(bufString);
      }
      return charset$1.encode(data);
    },
    /**
     * Converts well known invalid character set names to proper names.
     * eg. win-1257 will be converted to WINDOWS-1257
     *
     * @param {String} charset Charset name to convert
     * @return {String} Canoninicalized charset name
     */
    normalizeCharset(charset2) {
      charset2 = charset2.toLowerCase().trim();
      if (charsets2.hasOwnProperty(charset2) && charsets2[charset2]) {
        return charsets2[charset2];
      }
      charset2 = charset2.replace(/^utf[-_]?(\d+)/, "utf-$1").replace(/^(?:us[-_]?)ascii/, "windows-1252").replace(/^win(?:dows)?[-_]?(\d+)/, "windows-$1").replace(/^(?:latin|iso[-_]?8859)?[-_]?(\d+)/, "iso-8859-$1").replace(/^l[-_]?(\d+)/, "iso-8859-$1");
      if (charsets2.hasOwnProperty(charset2) && charsets2[charset2]) {
        return charsets2[charset2];
      }
      return charset2.toUpperCase();
    }
  };
  return charset.exports;
}
var mimetypes;
var hasRequiredMimetypes;
function requireMimetypes() {
  if (hasRequiredMimetypes) return mimetypes;
  hasRequiredMimetypes = 1;
  mimetypes = {
    list: {
      "application/acad": "dwg",
      "application/applixware": "aw",
      "application/arj": "arj",
      "application/atom+xml": "xml",
      "application/atomcat+xml": "atomcat",
      "application/atomsvc+xml": "atomsvc",
      "application/base64": ["mm", "mme"],
      "application/binhex": "hqx",
      "application/binhex4": "hqx",
      "application/book": ["book", "boo"],
      "application/ccxml+xml,": "ccxml",
      "application/cdf": "cdf",
      "application/cdmi-capability": "cdmia",
      "application/cdmi-container": "cdmic",
      "application/cdmi-domain": "cdmid",
      "application/cdmi-object": "cdmio",
      "application/cdmi-queue": "cdmiq",
      "application/clariscad": "ccad",
      "application/commonground": "dp",
      "application/cu-seeme": "cu",
      "application/davmount+xml": "davmount",
      "application/drafting": "drw",
      "application/dsptype": "tsp",
      "application/dssc+der": "dssc",
      "application/dssc+xml": "xdssc",
      "application/dxf": "dxf",
      "application/ecmascript": ["js", "es"],
      "application/emma+xml": "emma",
      "application/envoy": "evy",
      "application/epub+zip": "epub",
      "application/excel": ["xls", "xl", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw"],
      "application/exi": "exi",
      "application/font-tdpfr": "pfr",
      "application/fractals": "fif",
      "application/freeloader": "frl",
      "application/futuresplash": "spl",
      "application/gnutar": "tgz",
      "application/groupwise": "vew",
      "application/hlp": "hlp",
      "application/hta": "hta",
      "application/hyperstudio": "stk",
      "application/i-deas": "unv",
      "application/iges": ["iges", "igs"],
      "application/inf": "inf",
      "application/internet-property-stream": "acx",
      "application/ipfix": "ipfix",
      "application/java": "class",
      "application/java-archive": "jar",
      "application/java-byte-code": "class",
      "application/java-serialized-object": "ser",
      "application/java-vm": "class",
      "application/javascript": "js",
      "application/json": "json",
      "application/lha": "lha",
      "application/lzx": "lzx",
      "application/mac-binary": "bin",
      "application/mac-binhex": "hqx",
      "application/mac-binhex40": "hqx",
      "application/mac-compactpro": "cpt",
      "application/macbinary": "bin",
      "application/mads+xml": "mads",
      "application/marc": "mrc",
      "application/marcxml+xml": "mrcx",
      "application/mathematica": "ma",
      "application/mathml+xml": "mathml",
      "application/mbedlet": "mbd",
      "application/mbox": "mbox",
      "application/mcad": "mcd",
      "application/mediaservercontrol+xml": "mscml",
      "application/metalink4+xml": "meta4",
      "application/mets+xml": "mets",
      "application/mime": "aps",
      "application/mods+xml": "mods",
      "application/mp21": "m21",
      "application/mp4": "mp4",
      "application/mspowerpoint": ["ppt", "pot", "pps", "ppz"],
      "application/msword": ["doc", "dot", "w6w", "wiz", "word"],
      "application/mswrite": "wri",
      "application/mxf": "mxf",
      "application/netmc": "mcp",
      "application/octet-stream": ["*"],
      "application/oda": "oda",
      "application/oebps-package+xml": "opf",
      "application/ogg": "ogx",
      "application/olescript": "axs",
      "application/onenote": "onetoc",
      "application/patch-ops-error+xml": "xer",
      "application/pdf": "pdf",
      "application/pgp-encrypted": "asc",
      "application/pgp-signature": "pgp",
      "application/pics-rules": "prf",
      "application/pkcs-12": "p12",
      "application/pkcs-crl": "crl",
      "application/pkcs10": "p10",
      "application/pkcs7-mime": ["p7c", "p7m"],
      "application/pkcs7-signature": "p7s",
      "application/pkcs8": "p8",
      "application/pkix-attr-cert": "ac",
      "application/pkix-cert": ["cer", "crt"],
      "application/pkix-crl": "crl",
      "application/pkix-pkipath": "pkipath",
      "application/pkixcmp": "pki",
      "application/plain": "text",
      "application/pls+xml": "pls",
      "application/postscript": ["ps", "ai", "eps"],
      "application/powerpoint": "ppt",
      "application/pro_eng": ["part", "prt"],
      "application/prs.cww": "cww",
      "application/pskc+xml": "pskcxml",
      "application/rdf+xml": "rdf",
      "application/reginfo+xml": "rif",
      "application/relax-ng-compact-syntax": "rnc",
      "application/resource-lists+xml": "rl",
      "application/resource-lists-diff+xml": "rld",
      "application/ringing-tones": "rng",
      "application/rls-services+xml": "rs",
      "application/rsd+xml": "rsd",
      "application/rss+xml": "xml",
      "application/rtf": ["rtf", "rtx"],
      "application/sbml+xml": "sbml",
      "application/scvp-cv-request": "scq",
      "application/scvp-cv-response": "scs",
      "application/scvp-vp-request": "spq",
      "application/scvp-vp-response": "spp",
      "application/sdp": "sdp",
      "application/sea": "sea",
      "application/set": "set",
      "application/set-payment-initiation": "setpay",
      "application/set-registration-initiation": "setreg",
      "application/shf+xml": "shf",
      "application/sla": "stl",
      "application/smil": ["smi", "smil"],
      "application/smil+xml": "smi",
      "application/solids": "sol",
      "application/sounder": "sdr",
      "application/sparql-query": "rq",
      "application/sparql-results+xml": "srx",
      "application/srgs": "gram",
      "application/srgs+xml": "grxml",
      "application/sru+xml": "sru",
      "application/ssml+xml": "ssml",
      "application/step": ["step", "stp"],
      "application/streamingmedia": "ssm",
      "application/tei+xml": "tei",
      "application/thraud+xml": "tfi",
      "application/timestamped-data": "tsd",
      "application/toolbook": "tbk",
      "application/vda": "vda",
      "application/vnd.3gpp.pic-bw-large": "plb",
      "application/vnd.3gpp.pic-bw-small": "psb",
      "application/vnd.3gpp.pic-bw-var": "pvb",
      "application/vnd.3gpp2.tcap": "tcap",
      "application/vnd.3m.post-it-notes": "pwn",
      "application/vnd.accpac.simply.aso": "aso",
      "application/vnd.accpac.simply.imp": "imp",
      "application/vnd.acucobol": "acu",
      "application/vnd.acucorp": "atc",
      "application/vnd.adobe.air-application-installer-package+zip": "air",
      "application/vnd.adobe.fxp": "fxp",
      "application/vnd.adobe.xdp+xml": "xdp",
      "application/vnd.adobe.xfdf": "xfdf",
      "application/vnd.ahead.space": "ahead",
      "application/vnd.airzip.filesecure.azf": "azf",
      "application/vnd.airzip.filesecure.azs": "azs",
      "application/vnd.amazon.ebook": "azw",
      "application/vnd.americandynamics.acc": "acc",
      "application/vnd.amiga.ami": "ami",
      "application/vnd.android.package-archive": "apk",
      "application/vnd.anser-web-certificate-issue-initiation": "cii",
      "application/vnd.anser-web-funds-transfer-initiation": "fti",
      "application/vnd.antix.game-component": "atx",
      "application/vnd.apple.installer+xml": "mpkg",
      "application/vnd.apple.mpegurl": "m3u8",
      "application/vnd.aristanetworks.swi": "swi",
      "application/vnd.audiograph": "aep",
      "application/vnd.blueice.multipass": "mpm",
      "application/vnd.bmi": "bmi",
      "application/vnd.businessobjects": "rep",
      "application/vnd.chemdraw+xml": "cdxml",
      "application/vnd.chipnuts.karaoke-mmd": "mmd",
      "application/vnd.cinderella": "cdy",
      "application/vnd.claymore": "cla",
      "application/vnd.cloanto.rp9": "rp9",
      "application/vnd.clonk.c4group": "c4g",
      "application/vnd.cluetrust.cartomobile-config": "c11amc",
      "application/vnd.cluetrust.cartomobile-config-pkg": "c11amz",
      "application/vnd.commonspace": "csp",
      "application/vnd.contact.cmsg": "cdbcmsg",
      "application/vnd.cosmocaller": "cmc",
      "application/vnd.crick.clicker": "clkx",
      "application/vnd.crick.clicker.keyboard": "clkk",
      "application/vnd.crick.clicker.palette": "clkp",
      "application/vnd.crick.clicker.template": "clkt",
      "application/vnd.crick.clicker.wordbank": "clkw",
      "application/vnd.criticaltools.wbs+xml": "wbs",
      "application/vnd.ctc-posml": "pml",
      "application/vnd.cups-ppd": "ppd",
      "application/vnd.curl.car": "car",
      "application/vnd.curl.pcurl": "pcurl",
      "application/vnd.data-vision.rdz": "rdz",
      "application/vnd.denovo.fcselayout-link": "fe_launch",
      "application/vnd.dna": "dna",
      "application/vnd.dolby.mlp": "mlp",
      "application/vnd.dpgraph": "dpg",
      "application/vnd.dreamfactory": "dfac",
      "application/vnd.dvb.ait": "ait",
      "application/vnd.dvb.service": "svc",
      "application/vnd.dynageo": "geo",
      "application/vnd.ecowin.chart": "mag",
      "application/vnd.enliven": "nml",
      "application/vnd.epson.esf": "esf",
      "application/vnd.epson.msf": "msf",
      "application/vnd.epson.quickanime": "qam",
      "application/vnd.epson.salt": "slt",
      "application/vnd.epson.ssf": "ssf",
      "application/vnd.eszigno3+xml": "es3",
      "application/vnd.ezpix-album": "ez2",
      "application/vnd.ezpix-package": "ez3",
      "application/vnd.fdf": "fdf",
      "application/vnd.fdsn.seed": "seed",
      "application/vnd.flographit": "gph",
      "application/vnd.fluxtime.clip": "ftc",
      "application/vnd.framemaker": "fm",
      "application/vnd.frogans.fnc": "fnc",
      "application/vnd.frogans.ltf": "ltf",
      "application/vnd.fsc.weblaunch": "fsc",
      "application/vnd.fujitsu.oasys": "oas",
      "application/vnd.fujitsu.oasys2": "oa2",
      "application/vnd.fujitsu.oasys3": "oa3",
      "application/vnd.fujitsu.oasysgp": "fg5",
      "application/vnd.fujitsu.oasysprs": "bh2",
      "application/vnd.fujixerox.ddd": "ddd",
      "application/vnd.fujixerox.docuworks": "xdw",
      "application/vnd.fujixerox.docuworks.binder": "xbd",
      "application/vnd.fuzzysheet": "fzs",
      "application/vnd.genomatix.tuxedo": "txd",
      "application/vnd.geogebra.file": "ggb",
      "application/vnd.geogebra.tool": "ggt",
      "application/vnd.geometry-explorer": "gex",
      "application/vnd.geonext": "gxt",
      "application/vnd.geoplan": "g2w",
      "application/vnd.geospace": "g3w",
      "application/vnd.gmx": "gmx",
      "application/vnd.google-earth.kml+xml": "kml",
      "application/vnd.google-earth.kmz": "kmz",
      "application/vnd.grafeq": "gqf",
      "application/vnd.groove-account": "gac",
      "application/vnd.groove-help": "ghf",
      "application/vnd.groove-identity-message": "gim",
      "application/vnd.groove-injector": "grv",
      "application/vnd.groove-tool-message": "gtm",
      "application/vnd.groove-tool-template": "tpl",
      "application/vnd.groove-vcard": "vcg",
      "application/vnd.hal+xml": "hal",
      "application/vnd.handheld-entertainment+xml": "zmm",
      "application/vnd.hbci": "hbci",
      "application/vnd.hhe.lesson-player": "les",
      "application/vnd.hp-hpgl": ["hgl", "hpg", "hpgl"],
      "application/vnd.hp-hpid": "hpid",
      "application/vnd.hp-hps": "hps",
      "application/vnd.hp-jlyt": "jlt",
      "application/vnd.hp-pcl": "pcl",
      "application/vnd.hp-pclxl": "pclxl",
      "application/vnd.hydrostatix.sof-data": "sfd-hdstx",
      "application/vnd.hzn-3d-crossword": "x3d",
      "application/vnd.ibm.minipay": "mpy",
      "application/vnd.ibm.modcap": "afp",
      "application/vnd.ibm.rights-management": "irm",
      "application/vnd.ibm.secure-container": "sc",
      "application/vnd.iccprofile": "icc",
      "application/vnd.igloader": "igl",
      "application/vnd.immervision-ivp": "ivp",
      "application/vnd.immervision-ivu": "ivu",
      "application/vnd.insors.igm": "igm",
      "application/vnd.intercon.formnet": "xpw",
      "application/vnd.intergeo": "i2g",
      "application/vnd.intu.qbo": "qbo",
      "application/vnd.intu.qfx": "qfx",
      "application/vnd.ipunplugged.rcprofile": "rcprofile",
      "application/vnd.irepository.package+xml": "irp",
      "application/vnd.is-xpr": "xpr",
      "application/vnd.isac.fcs": "fcs",
      "application/vnd.jam": "jam",
      "application/vnd.jcp.javame.midlet-rms": "rms",
      "application/vnd.jisp": "jisp",
      "application/vnd.joost.joda-archive": "joda",
      "application/vnd.kahootz": "ktz",
      "application/vnd.kde.karbon": "karbon",
      "application/vnd.kde.kchart": "chrt",
      "application/vnd.kde.kformula": "kfo",
      "application/vnd.kde.kivio": "flw",
      "application/vnd.kde.kontour": "kon",
      "application/vnd.kde.kpresenter": "kpr",
      "application/vnd.kde.kspread": "ksp",
      "application/vnd.kde.kword": "kwd",
      "application/vnd.kenameaapp": "htke",
      "application/vnd.kidspiration": "kia",
      "application/vnd.kinar": "kne",
      "application/vnd.koan": "skp",
      "application/vnd.kodak-descriptor": "sse",
      "application/vnd.las.las+xml": "lasxml",
      "application/vnd.llamagraphics.life-balance.desktop": "lbd",
      "application/vnd.llamagraphics.life-balance.exchange+xml": "lbe",
      "application/vnd.lotus-1-2-3": "123",
      "application/vnd.lotus-approach": "apr",
      "application/vnd.lotus-freelance": "pre",
      "application/vnd.lotus-notes": "nsf",
      "application/vnd.lotus-organizer": "org",
      "application/vnd.lotus-screencam": "scm",
      "application/vnd.lotus-wordpro": "lwp",
      "application/vnd.macports.portpkg": "portpkg",
      "application/vnd.mcd": "mcd",
      "application/vnd.medcalcdata": "mc1",
      "application/vnd.mediastation.cdkey": "cdkey",
      "application/vnd.mfer": "mwf",
      "application/vnd.mfmp": "mfm",
      "application/vnd.micrografx.flo": "flo",
      "application/vnd.micrografx.igx": "igx",
      "application/vnd.mif": "mif",
      "application/vnd.mobius.daf": "daf",
      "application/vnd.mobius.dis": "dis",
      "application/vnd.mobius.mbk": "mbk",
      "application/vnd.mobius.mqy": "mqy",
      "application/vnd.mobius.msl": "msl",
      "application/vnd.mobius.plc": "plc",
      "application/vnd.mobius.txf": "txf",
      "application/vnd.mophun.application": "mpn",
      "application/vnd.mophun.certificate": "mpc",
      "application/vnd.mozilla.xul+xml": "xul",
      "application/vnd.ms-artgalry": "cil",
      "application/vnd.ms-cab-compressed": "cab",
      "application/vnd.ms-excel": ["xls", "xla", "xlc", "xlm", "xlt", "xlw", "xlb", "xll"],
      "application/vnd.ms-excel.addin.macroenabled.12": "xlam",
      "application/vnd.ms-excel.sheet.binary.macroenabled.12": "xlsb",
      "application/vnd.ms-excel.sheet.macroenabled.12": "xlsm",
      "application/vnd.ms-excel.template.macroenabled.12": "xltm",
      "application/vnd.ms-fontobject": "eot",
      "application/vnd.ms-htmlhelp": "chm",
      "application/vnd.ms-ims": "ims",
      "application/vnd.ms-lrm": "lrm",
      "application/vnd.ms-officetheme": "thmx",
      "application/vnd.ms-outlook": "msg",
      "application/vnd.ms-pki.certstore": "sst",
      "application/vnd.ms-pki.pko": "pko",
      "application/vnd.ms-pki.seccat": "cat",
      "application/vnd.ms-pki.stl": "stl",
      "application/vnd.ms-pkicertstore": "sst",
      "application/vnd.ms-pkiseccat": "cat",
      "application/vnd.ms-pkistl": "stl",
      "application/vnd.ms-powerpoint": ["ppt", "pot", "pps", "ppa", "pwz"],
      "application/vnd.ms-powerpoint.addin.macroenabled.12": "ppam",
      "application/vnd.ms-powerpoint.presentation.macroenabled.12": "pptm",
      "application/vnd.ms-powerpoint.slide.macroenabled.12": "sldm",
      "application/vnd.ms-powerpoint.slideshow.macroenabled.12": "ppsm",
      "application/vnd.ms-powerpoint.template.macroenabled.12": "potm",
      "application/vnd.ms-project": "mpp",
      "application/vnd.ms-word.document.macroenabled.12": "docm",
      "application/vnd.ms-word.template.macroenabled.12": "dotm",
      "application/vnd.ms-works": ["wks", "wcm", "wdb", "wps"],
      "application/vnd.ms-wpl": "wpl",
      "application/vnd.ms-xpsdocument": "xps",
      "application/vnd.mseq": "mseq",
      "application/vnd.musician": "mus",
      "application/vnd.muvee.style": "msty",
      "application/vnd.neurolanguage.nlu": "nlu",
      "application/vnd.noblenet-directory": "nnd",
      "application/vnd.noblenet-sealer": "nns",
      "application/vnd.noblenet-web": "nnw",
      "application/vnd.nokia.configuration-message": "ncm",
      "application/vnd.nokia.n-gage.data": "ngdat",
      "application/vnd.nokia.n-gage.symbian.install": "n-gage",
      "application/vnd.nokia.radio-preset": "rpst",
      "application/vnd.nokia.radio-presets": "rpss",
      "application/vnd.nokia.ringing-tone": "rng",
      "application/vnd.novadigm.edm": "edm",
      "application/vnd.novadigm.edx": "edx",
      "application/vnd.novadigm.ext": "ext",
      "application/vnd.oasis.opendocument.chart": "odc",
      "application/vnd.oasis.opendocument.chart-template": "otc",
      "application/vnd.oasis.opendocument.database": "odb",
      "application/vnd.oasis.opendocument.formula": "odf",
      "application/vnd.oasis.opendocument.formula-template": "odft",
      "application/vnd.oasis.opendocument.graphics": "odg",
      "application/vnd.oasis.opendocument.graphics-template": "otg",
      "application/vnd.oasis.opendocument.image": "odi",
      "application/vnd.oasis.opendocument.image-template": "oti",
      "application/vnd.oasis.opendocument.presentation": "odp",
      "application/vnd.oasis.opendocument.presentation-template": "otp",
      "application/vnd.oasis.opendocument.spreadsheet": "ods",
      "application/vnd.oasis.opendocument.spreadsheet-template": "ots",
      "application/vnd.oasis.opendocument.text": "odt",
      "application/vnd.oasis.opendocument.text-master": "odm",
      "application/vnd.oasis.opendocument.text-template": "ott",
      "application/vnd.oasis.opendocument.text-web": "oth",
      "application/vnd.olpc-sugar": "xo",
      "application/vnd.oma.dd2+xml": "dd2",
      "application/vnd.openofficeorg.extension": "oxt",
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
      "application/vnd.openxmlformats-officedocument.presentationml.slide": "sldx",
      "application/vnd.openxmlformats-officedocument.presentationml.slideshow": "ppsx",
      "application/vnd.openxmlformats-officedocument.presentationml.template": "potx",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.template": "xltx",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.template": "dotx",
      "application/vnd.osgeo.mapguide.package": "mgp",
      "application/vnd.osgi.dp": "dp",
      "application/vnd.palm": "pdb",
      "application/vnd.pawaafile": "paw",
      "application/vnd.pg.format": "str",
      "application/vnd.pg.osasli": "ei6",
      "application/vnd.picsel": "efif",
      "application/vnd.pmi.widget": "wg",
      "application/vnd.pocketlearn": "plf",
      "application/vnd.powerbuilder6": "pbd",
      "application/vnd.previewsystems.box": "box",
      "application/vnd.proteus.magazine": "mgz",
      "application/vnd.publishare-delta-tree": "qps",
      "application/vnd.pvi.ptid1": "ptid",
      "application/vnd.quark.quarkxpress": "qxd",
      "application/vnd.realvnc.bed": "bed",
      "application/vnd.recordare.musicxml": "mxl",
      "application/vnd.recordare.musicxml+xml": "musicxml",
      "application/vnd.rig.cryptonote": "cryptonote",
      "application/vnd.rim.cod": "cod",
      "application/vnd.rn-realmedia": "rm",
      "application/vnd.rn-realplayer": "rnx",
      "application/vnd.route66.link66+xml": "link66",
      "application/vnd.sailingtracker.track": "st",
      "application/vnd.seemail": "see",
      "application/vnd.sema": "sema",
      "application/vnd.semd": "semd",
      "application/vnd.semf": "semf",
      "application/vnd.shana.informed.formdata": "ifm",
      "application/vnd.shana.informed.formtemplate": "itp",
      "application/vnd.shana.informed.interchange": "iif",
      "application/vnd.shana.informed.package": "ipk",
      "application/vnd.simtech-mindmapper": "twd",
      "application/vnd.smaf": "mmf",
      "application/vnd.smart.teacher": "teacher",
      "application/vnd.solent.sdkm+xml": "sdkm",
      "application/vnd.spotfire.dxp": "dxp",
      "application/vnd.spotfire.sfs": "sfs",
      "application/vnd.stardivision.calc": "sdc",
      "application/vnd.stardivision.draw": "sda",
      "application/vnd.stardivision.impress": "sdd",
      "application/vnd.stardivision.math": "smf",
      "application/vnd.stardivision.writer": "sdw",
      "application/vnd.stardivision.writer-global": "sgl",
      "application/vnd.stepmania.stepchart": "sm",
      "application/vnd.sun.xml.calc": "sxc",
      "application/vnd.sun.xml.calc.template": "stc",
      "application/vnd.sun.xml.draw": "sxd",
      "application/vnd.sun.xml.draw.template": "std",
      "application/vnd.sun.xml.impress": "sxi",
      "application/vnd.sun.xml.impress.template": "sti",
      "application/vnd.sun.xml.math": "sxm",
      "application/vnd.sun.xml.writer": "sxw",
      "application/vnd.sun.xml.writer.global": "sxg",
      "application/vnd.sun.xml.writer.template": "stw",
      "application/vnd.sus-calendar": "sus",
      "application/vnd.svd": "svd",
      "application/vnd.symbian.install": "sis",
      "application/vnd.syncml+xml": "xsm",
      "application/vnd.syncml.dm+wbxml": "bdm",
      "application/vnd.syncml.dm+xml": "xdm",
      "application/vnd.tao.intent-module-archive": "tao",
      "application/vnd.tmobile-livetv": "tmo",
      "application/vnd.trid.tpt": "tpt",
      "application/vnd.triscape.mxs": "mxs",
      "application/vnd.trueapp": "tra",
      "application/vnd.ufdl": "ufd",
      "application/vnd.uiq.theme": "utz",
      "application/vnd.umajin": "umj",
      "application/vnd.unity": "unityweb",
      "application/vnd.uoml+xml": "uoml",
      "application/vnd.vcx": "vcx",
      "application/vnd.visio": "vsd",
      "application/vnd.visionary": "vis",
      "application/vnd.vsf": "vsf",
      "application/vnd.wap.wbxml": "wbxml",
      "application/vnd.wap.wmlc": "wmlc",
      "application/vnd.wap.wmlscriptc": "wmlsc",
      "application/vnd.webturbo": "wtb",
      "application/vnd.wolfram.player": "nbp",
      "application/vnd.wordperfect": "wpd",
      "application/vnd.wqd": "wqd",
      "application/vnd.wt.stf": "stf",
      "application/vnd.xara": ["web", "xar"],
      "application/vnd.xfdl": "xfdl",
      "application/vnd.yamaha.hv-dic": "hvd",
      "application/vnd.yamaha.hv-script": "hvs",
      "application/vnd.yamaha.hv-voice": "hvp",
      "application/vnd.yamaha.openscoreformat": "osf",
      "application/vnd.yamaha.openscoreformat.osfpvg+xml": "osfpvg",
      "application/vnd.yamaha.smaf-audio": "saf",
      "application/vnd.yamaha.smaf-phrase": "spf",
      "application/vnd.yellowriver-custom-menu": "cmp",
      "application/vnd.zul": "zir",
      "application/vnd.zzazz.deck+xml": "zaz",
      "application/vocaltec-media-desc": "vmd",
      "application/vocaltec-media-file": "vmf",
      "application/voicexml+xml": "vxml",
      "application/widget": "wgt",
      "application/winhlp": "hlp",
      "application/wordperfect": ["wp", "wp5", "wp6", "wpd"],
      "application/wordperfect6.0": ["w60", "wp5"],
      "application/wordperfect6.1": "w61",
      "application/wsdl+xml": "wsdl",
      "application/wspolicy+xml": "wspolicy",
      "application/x-123": "wk1",
      "application/x-7z-compressed": "7z",
      "application/x-abiword": "abw",
      "application/x-ace-compressed": "ace",
      "application/x-aim": "aim",
      "application/x-authorware-bin": "aab",
      "application/x-authorware-map": "aam",
      "application/x-authorware-seg": "aas",
      "application/x-bcpio": "bcpio",
      "application/x-binary": "bin",
      "application/x-binhex40": "hqx",
      "application/x-bittorrent": "torrent",
      "application/x-bsh": ["bsh", "sh", "shar"],
      "application/x-bytecode.elisp": "elc",
      "applicaiton/x-bytecode.python": "pyc",
      "application/x-bzip": "bz",
      "application/x-bzip2": ["boz", "bz2"],
      "application/x-cdf": "cdf",
      "application/x-cdlink": "vcd",
      "application/x-chat": ["cha", "chat"],
      "application/x-chess-pgn": "pgn",
      "application/x-cmu-raster": "ras",
      "application/x-cocoa": "cco",
      "application/x-compactpro": "cpt",
      "application/x-compress": "z",
      "application/x-compressed": ["tgz", "gz", "z", "zip"],
      "application/x-conference": "nsc",
      "application/x-cpio": "cpio",
      "application/x-cpt": "cpt",
      "application/x-csh": "csh",
      "application/x-debian-package": "deb",
      "application/x-deepv": "deepv",
      "application/x-director": ["dir", "dcr", "dxr"],
      "application/x-doom": "wad",
      "application/x-dtbncx+xml": "ncx",
      "application/x-dtbook+xml": "dtb",
      "application/x-dtbresource+xml": "res",
      "application/x-dvi": "dvi",
      "application/x-elc": "elc",
      "application/x-envoy": ["env", "evy"],
      "application/x-esrehber": "es",
      "application/x-excel": ["xls", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw"],
      "application/x-font-bdf": "bdf",
      "application/x-font-ghostscript": "gsf",
      "application/x-font-linux-psf": "psf",
      "application/x-font-otf": "otf",
      "application/x-font-pcf": "pcf",
      "application/x-font-snf": "snf",
      "application/x-font-ttf": "ttf",
      "application/x-font-type1": "pfa",
      "application/x-font-woff": "woff",
      "application/x-frame": "mif",
      "application/x-freelance": "pre",
      "application/x-futuresplash": "spl",
      "application/x-gnumeric": "gnumeric",
      "application/x-gsp": "gsp",
      "application/x-gss": "gss",
      "application/x-gtar": "gtar",
      "application/x-gzip": ["gz", "gzip"],
      "application/x-hdf": "hdf",
      "application/x-helpfile": ["help", "hlp"],
      "application/x-httpd-imap": "imap",
      "application/x-ima": "ima",
      "application/x-internet-signup": ["ins", "isp"],
      "application/x-internett-signup": "ins",
      "application/x-inventor": "iv",
      "application/x-ip2": "ip",
      "application/x-iphone": "iii",
      "application/x-java-class": "class",
      "application/x-java-commerce": "jcm",
      "application/x-java-jnlp-file": "jnlp",
      "application/x-javascript": "js",
      "application/x-koan": ["skd", "skm", "skp", "skt"],
      "application/x-ksh": "ksh",
      "application/x-latex": ["latex", "ltx"],
      "application/x-lha": "lha",
      "application/x-lisp": "lsp",
      "application/x-livescreen": "ivy",
      "application/x-lotus": "wq1",
      "application/x-lotusscreencam": "scm",
      "application/x-lzh": "lzh",
      "application/x-lzx": "lzx",
      "application/x-mac-binhex40": "hqx",
      "application/x-macbinary": "bin",
      "application/x-magic-cap-package-1.0": "mc$",
      "application/x-mathcad": "mcd",
      "application/x-meme": "mm",
      "application/x-midi": ["mid", "midi"],
      "application/x-mif": "mif",
      "application/x-mix-transfer": "nix",
      "application/x-mobipocket-ebook": "prc",
      "application/x-mplayer2": "asx",
      "application/x-ms-application": "application",
      "application/x-ms-wmd": "wmd",
      "application/x-ms-wmz": "wmz",
      "application/x-ms-xbap": "xbap",
      "application/x-msaccess": "mdb",
      "application/x-msbinder": "obd",
      "application/x-mscardfile": "crd",
      "application/x-msclip": "clp",
      "application/x-msdownload": ["exe", "dll"],
      "application/x-msexcel": ["xls", "xla", "xlw"],
      "application/x-msmediaview": ["mvb", "m13", "m14"],
      "application/x-msmetafile": "wmf",
      "application/x-msmoney": "mny",
      "application/x-mspowerpoint": "ppt",
      "application/x-mspublisher": "pub",
      "application/x-msschedule": "scd",
      "application/x-msterminal": "trm",
      "application/x-mswrite": "wri",
      "application/x-navi-animation": "ani",
      "application/x-navidoc": "nvd",
      "application/x-navimap": "map",
      "application/x-navistyle": "stl",
      "application/x-netcdf": ["cdf", "nc"],
      "application/x-newton-compatible-pkg": "pkg",
      "application/x-nokia-9000-communicator-add-on-software": "aos",
      "application/x-omc": "omc",
      "application/x-omcdatamaker": "omcd",
      "application/x-omcregerator": "omcr",
      "application/x-pagemaker": ["pm4", "pm5"],
      "application/x-pcl": "pcl",
      "application/x-perfmon": ["pma", "pmc", "pml", "pmr", "pmw"],
      "application/x-pixclscript": "plx",
      "application/x-pkcs10": "p10",
      "application/x-pkcs12": ["p12", "pfx"],
      "application/x-pkcs7-certificates": ["p7b", "spc"],
      "application/x-pkcs7-certreqresp": "p7r",
      "application/x-pkcs7-mime": ["p7m", "p7c"],
      "application/x-pkcs7-signature": ["p7s", "p7a"],
      "application/x-pointplus": "css",
      "application/x-portable-anymap": "pnm",
      "application/x-project": ["mpc", "mpt", "mpv", "mpx"],
      "application/x-qpro": "wb1",
      "application/x-rar-compressed": "rar",
      "application/x-rtf": "rtf",
      "application/x-sdp": "sdp",
      "application/x-sea": "sea",
      "application/x-seelogo": "sl",
      "application/x-sh": "sh",
      "application/x-shar": ["shar", "sh"],
      "application/x-shockwave-flash": "swf",
      "application/x-silverlight-app": "xap",
      "application/x-sit": "sit",
      "application/x-sprite": ["spr", "sprite"],
      "application/x-stuffit": "sit",
      "application/x-stuffitx": "sitx",
      "application/x-sv4cpio": "sv4cpio",
      "application/x-sv4crc": "sv4crc",
      "application/x-tar": "tar",
      "application/x-tbook": ["sbk", "tbk"],
      "application/x-tcl": "tcl",
      "application/x-tex": "tex",
      "application/x-tex-tfm": "tfm",
      "application/x-texinfo": ["texi", "texinfo"],
      "application/x-troff": ["roff", "t", "tr"],
      "application/x-troff-man": "man",
      "application/x-troff-me": "me",
      "application/x-troff-ms": "ms",
      "application/x-troff-msvideo": "avi",
      "application/x-ustar": "ustar",
      "application/x-visio": ["vsd", "vst", "vsw"],
      "application/x-vnd.audioexplosion.mzz": "mzz",
      "application/x-vnd.ls-xpix": "xpix",
      "application/x-vrml": "vrml",
      "application/x-wais-source": ["src", "wsrc"],
      "application/x-winhelp": "hlp",
      "application/x-wintalk": "wtk",
      "application/x-world": ["wrl", "svr"],
      "application/x-wpwin": "wpd",
      "application/x-wri": "wri",
      "application/x-x509-ca-cert": ["cer", "crt", "der"],
      "application/x-x509-user-cert": "crt",
      "application/x-xfig": "fig",
      "application/x-xpinstall": "xpi",
      "application/x-zip-compressed": "zip",
      "application/xcap-diff+xml": "xdf",
      "application/xenc+xml": "xenc",
      "application/xhtml+xml": "xhtml",
      "application/xml": "xml",
      "application/xml-dtd": "dtd",
      "application/xop+xml": "xop",
      "application/xslt+xml": "xslt",
      "application/xspf+xml": "xspf",
      "application/xv+xml": "mxml",
      "application/yang": "yang",
      "application/yin+xml": "yin",
      "application/ynd.ms-pkipko": "pko",
      "application/zip": "zip",
      "audio/adpcm": "adp",
      "audio/aiff": ["aiff", "aif", "aifc"],
      "audio/basic": ["snd", "au"],
      "audio/it": "it",
      "audio/make": ["funk", "my", "pfunk"],
      "audio/make.my.funk": "pfunk",
      "audio/mid": ["mid", "rmi"],
      "audio/midi": ["midi", "kar", "mid"],
      "audio/mod": "mod",
      "audio/mp4": "mp4a",
      "audio/mpeg": ["mpga", "mp3", "m2a", "mp2", "mpa", "mpg"],
      "audio/mpeg3": "mp3",
      "audio/nspaudio": ["la", "lma"],
      "audio/ogg": "oga",
      "audio/s3m": "s3m",
      "audio/tsp-audio": "tsi",
      "audio/tsplayer": "tsp",
      "audio/vnd.dece.audio": "uva",
      "audio/vnd.digital-winds": "eol",
      "audio/vnd.dra": "dra",
      "audio/vnd.dts": "dts",
      "audio/vnd.dts.hd": "dtshd",
      "audio/vnd.lucent.voice": "lvp",
      "audio/vnd.ms-playready.media.pya": "pya",
      "audio/vnd.nuera.ecelp4800": "ecelp4800",
      "audio/vnd.nuera.ecelp7470": "ecelp7470",
      "audio/vnd.nuera.ecelp9600": "ecelp9600",
      "audio/vnd.qcelp": "qcp",
      "audio/vnd.rip": "rip",
      "audio/voc": "voc",
      "audio/voxware": "vox",
      "audio/wav": "wav",
      "audio/webm": "weba",
      "audio/x-aac": "aac",
      "audio/x-adpcm": "snd",
      "audio/x-aiff": ["aiff", "aif", "aifc"],
      "audio/x-au": "au",
      "audio/x-gsm": ["gsd", "gsm"],
      "audio/x-jam": "jam",
      "audio/x-liveaudio": "lam",
      "audio/x-mid": ["mid", "midi"],
      "audio/x-midi": ["midi", "mid"],
      "audio/x-mod": "mod",
      "audio/x-mpeg": "mp2",
      "audio/x-mpeg-3": "mp3",
      "audio/x-mpegurl": "m3u",
      "audio/x-mpequrl": "m3u",
      "audio/x-ms-wax": "wax",
      "audio/x-ms-wma": "wma",
      "audio/x-nspaudio": ["la", "lma"],
      "audio/x-pn-realaudio": ["ra", "ram", "rm", "rmm", "rmp"],
      "audio/x-pn-realaudio-plugin": ["ra", "rmp", "rpm"],
      "audio/x-psid": "sid",
      "audio/x-realaudio": "ra",
      "audio/x-twinvq": "vqf",
      "audio/x-twinvq-plugin": ["vqe", "vql"],
      "audio/x-vnd.audioexplosion.mjuicemediafile": "mjf",
      "audio/x-voc": "voc",
      "audio/x-wav": "wav",
      "audio/xm": "xm",
      "chemical/x-cdx": "cdx",
      "chemical/x-cif": "cif",
      "chemical/x-cmdf": "cmdf",
      "chemical/x-cml": "cml",
      "chemical/x-csml": "csml",
      "chemical/x-pdb": ["pdb", "xyz"],
      "chemical/x-xyz": "xyz",
      "drawing/x-dwf": "dwf",
      "i-world/i-vrml": "ivr",
      "image/bmp": ["bmp", "bm"],
      "image/cgm": "cgm",
      "image/cis-cod": "cod",
      "image/cmu-raster": ["ras", "rast"],
      "image/fif": "fif",
      "image/florian": ["flo", "turbot"],
      "image/g3fax": "g3",
      "image/gif": "gif",
      "image/ief": ["ief", "iefs"],
      "image/jpeg": ["jpeg", "jpe", "jpg", "jfif", "jfif-tbnl"],
      "image/jutvision": "jut",
      "image/ktx": "ktx",
      "image/naplps": ["nap", "naplps"],
      "image/pict": ["pic", "pict"],
      "image/pipeg": "jfif",
      "image/pjpeg": ["jfif", "jpe", "jpeg", "jpg"],
      "image/png": ["png", "x-png"],
      "image/prs.btif": "btif",
      "image/svg+xml": "svg",
      "image/tiff": ["tif", "tiff"],
      "image/vasa": "mcf",
      "image/vnd.adobe.photoshop": "psd",
      "image/vnd.dece.graphic": "uvi",
      "image/vnd.djvu": "djvu",
      "image/vnd.dvb.subtitle": "sub",
      "image/vnd.dwg": ["dwg", "dxf", "svf"],
      "image/vnd.dxf": "dxf",
      "image/vnd.fastbidsheet": "fbs",
      "image/vnd.fpx": "fpx",
      "image/vnd.fst": "fst",
      "image/vnd.fujixerox.edmics-mmr": "mmr",
      "image/vnd.fujixerox.edmics-rlc": "rlc",
      "image/vnd.ms-modi": "mdi",
      "image/vnd.net-fpx": ["fpx", "npx"],
      "image/vnd.rn-realflash": "rf",
      "image/vnd.rn-realpix": "rp",
      "image/vnd.wap.wbmp": "wbmp",
      "image/vnd.xiff": "xif",
      "image/webp": "webp",
      "image/x-cmu-raster": "ras",
      "image/x-cmx": "cmx",
      "image/x-dwg": ["dwg", "dxf", "svf"],
      "image/x-freehand": "fh",
      "image/x-icon": "ico",
      "image/x-jg": "art",
      "image/x-jps": "jps",
      "image/x-niff": ["niff", "nif"],
      "image/x-pcx": "pcx",
      "image/x-pict": ["pct", "pic"],
      "image/x-portable-anymap": "pnm",
      "image/x-portable-bitmap": "pbm",
      "image/x-portable-graymap": "pgm",
      "image/x-portable-greymap": "pgm",
      "image/x-portable-pixmap": "ppm",
      "image/x-quicktime": ["qif", "qti", "qtif"],
      "image/x-rgb": "rgb",
      "image/x-tiff": ["tif", "tiff"],
      "image/x-windows-bmp": "bmp",
      "image/x-xbitmap": "xbm",
      "image/x-xbm": "xbm",
      "image/x-xpixmap": ["xpm", "pm"],
      "image/x-xwd": "xwd",
      "image/x-xwindowdump": "xwd",
      "image/xbm": "xbm",
      "image/xpm": "xpm",
      "message/rfc822": ["eml", "mht", "mhtml", "nws", "mime"],
      "model/iges": ["iges", "igs"],
      "model/mesh": "msh",
      "model/vnd.collada+xml": "dae",
      "model/vnd.dwf": "dwf",
      "model/vnd.gdl": "gdl",
      "model/vnd.gtw": "gtw",
      "model/vnd.mts": "mts",
      "model/vnd.vtu": "vtu",
      "model/vrml": ["vrml", "wrl", "wrz"],
      "model/x-pov": "pov",
      "multipart/x-gzip": "gzip",
      "multipart/x-ustar": "ustar",
      "multipart/x-zip": "zip",
      "music/crescendo": ["mid", "midi"],
      "music/x-karaoke": "kar",
      "paleovu/x-pv": "pvu",
      "text/asp": "asp",
      "text/calendar": "ics",
      "text/css": "css",
      "text/csv": "csv",
      "text/ecmascript": "js",
      "text/h323": "323",
      "text/html": ["html", "htm", "stm", "acgi", "htmls", "htx", "shtml"],
      "text/iuls": "uls",
      "text/javascript": "js",
      "text/mcf": "mcf",
      "text/n3": "n3",
      "text/pascal": "pas",
      "text/plain": [
        "txt",
        "bas",
        "c",
        "h",
        "c++",
        "cc",
        "com",
        "conf",
        "cxx",
        "def",
        "f",
        "f90",
        "for",
        "g",
        "hh",
        "idc",
        "jav",
        "java",
        "list",
        "log",
        "lst",
        "m",
        "mar",
        "pl",
        "sdml",
        "text"
      ],
      "text/plain-bas": "par",
      "text/prs.lines.tag": "dsc",
      "text/richtext": ["rtx", "rt", "rtf"],
      "text/scriplet": "wsc",
      "text/scriptlet": "sct",
      "text/sgml": ["sgm", "sgml"],
      "text/tab-separated-values": "tsv",
      "text/troff": "t",
      "text/turtle": "ttl",
      "text/uri-list": ["uni", "unis", "uri", "uris"],
      "text/vnd.abc": "abc",
      "text/vnd.curl": "curl",
      "text/vnd.curl.dcurl": "dcurl",
      "text/vnd.curl.mcurl": "mcurl",
      "text/vnd.curl.scurl": "scurl",
      "text/vnd.fly": "fly",
      "text/vnd.fmi.flexstor": "flx",
      "text/vnd.graphviz": "gv",
      "text/vnd.in3d.3dml": "3dml",
      "text/vnd.in3d.spot": "spot",
      "text/vnd.rn-realtext": "rt",
      "text/vnd.sun.j2me.app-descriptor": "jad",
      "text/vnd.wap.wml": "wml",
      "text/vnd.wap.wmlscript": "wmls",
      "text/webviewhtml": "htt",
      "text/x-asm": ["asm", "s"],
      "text/x-audiosoft-intra": "aip",
      "text/x-c": ["c", "cc", "cpp"],
      "text/x-component": "htc",
      "text/x-fortran": ["for", "f", "f77", "f90"],
      "text/x-h": ["h", "hh"],
      "text/x-java-source": ["java", "jav"],
      "text/x-java-source,java": "java",
      "text/x-la-asf": "lsx",
      "text/x-m": "m",
      "text/x-pascal": "p",
      "text/x-script": "hlb",
      "text/x-script.csh": "csh",
      "text/x-script.elisp": "el",
      "text/x-script.guile": "scm",
      "text/x-script.ksh": "ksh",
      "text/x-script.lisp": "lsp",
      "text/x-script.perl": "pl",
      "text/x-script.perl-module": "pm",
      "text/x-script.phyton": "py",
      "text/x-script.rexx": "rexx",
      "text/x-script.scheme": "scm",
      "text/x-script.sh": "sh",
      "text/x-script.tcl": "tcl",
      "text/x-script.tcsh": "tcsh",
      "text/x-script.zsh": "zsh",
      "text/x-server-parsed-html": ["shtml", "ssi"],
      "text/x-setext": "etx",
      "text/x-sgml": ["sgm", "sgml"],
      "text/x-speech": ["spc", "talk"],
      "text/x-uil": "uil",
      "text/x-uuencode": ["uu", "uue"],
      "text/x-vcalendar": "vcs",
      "text/x-vcard": "vcf",
      "text/xml": "xml",
      "video/3gpp": "3gp",
      "video/3gpp2": "3g2",
      "video/animaflex": "afl",
      "video/avi": "avi",
      "video/avs-video": "avs",
      "video/dl": "dl",
      "video/fli": "fli",
      "video/gl": "gl",
      "video/h261": "h261",
      "video/h263": "h263",
      "video/h264": "h264",
      "video/jpeg": "jpgv",
      "video/jpm": "jpm",
      "video/mj2": "mj2",
      "video/mp4": "mp4",
      "video/mpeg": ["mpeg", "mp2", "mpa", "mpe", "mpg", "mpv2", "m1v", "m2v", "mp3"],
      "video/msvideo": "avi",
      "video/ogg": "ogv",
      "video/quicktime": ["mov", "qt", "moov"],
      "video/vdo": "vdo",
      "video/vivo": ["viv", "vivo"],
      "video/vnd.dece.hd": "uvh",
      "video/vnd.dece.mobile": "uvm",
      "video/vnd.dece.pd": "uvp",
      "video/vnd.dece.sd": "uvs",
      "video/vnd.dece.video": "uvv",
      "video/vnd.fvt": "fvt",
      "video/vnd.mpegurl": "mxu",
      "video/vnd.ms-playready.media.pyv": "pyv",
      "video/vnd.rn-realvideo": "rv",
      "video/vnd.uvvu.mp4": "uvu",
      "video/vnd.vivo": ["viv", "vivo"],
      "video/vosaic": "vos",
      "video/webm": "webm",
      "video/x-amt-demorun": "xdr",
      "video/x-amt-showrun": "xsr",
      "video/x-atomic3d-feature": "fmf",
      "video/x-dl": "dl",
      "video/x-dv": ["dif", "dv"],
      "video/x-f4v": "f4v",
      "video/x-fli": "fli",
      "video/x-flv": "flv",
      "video/x-gl": "gl",
      "video/x-isvideo": "isu",
      "video/x-la-asf": ["lsf", "lsx"],
      "video/x-m4v": "m4v",
      "video/x-motion-jpeg": "mjpg",
      "video/x-mpeg": ["mp3", "mp2"],
      "video/x-mpeq2a": "mp2",
      "video/x-ms-asf": ["asf", "asr", "asx"],
      "video/x-ms-asf-plugin": "asx",
      "video/x-ms-wm": "wm",
      "video/x-ms-wmv": "wmv",
      "video/x-ms-wmx": "wmx",
      "video/x-ms-wvx": "wvx",
      "video/x-msvideo": "avi",
      "video/x-qtc": "qtc",
      "video/x-scm": "scm",
      "video/x-sgi-movie": ["movie", "mv"],
      "windows/metafile": "wmf",
      "www/mime": "mime",
      "x-conference/x-cooltalk": "ice",
      "x-music/x-midi": ["mid", "midi"],
      "x-world/x-3dmf": ["3dm", "3dmf", "qd3", "qd3d"],
      "x-world/x-svr": "svr",
      "x-world/x-vrml": ["flr", "vrml", "wrl", "wrz", "xaf", "xof"],
      "x-world/x-vrt": "vrt",
      "xgl/drawing": "xgz",
      "xgl/movie": "xmz"
    },
    extensions: {
      "*": "application/octet-stream",
      "123": "application/vnd.lotus-1-2-3",
      "323": "text/h323",
      "3dm": "x-world/x-3dmf",
      "3dmf": "x-world/x-3dmf",
      "3dml": "text/vnd.in3d.3dml",
      "3g2": "video/3gpp2",
      "3gp": "video/3gpp",
      "7z": "application/x-7z-compressed",
      a: "application/octet-stream",
      aab: "application/x-authorware-bin",
      aac: "audio/x-aac",
      aam: "application/x-authorware-map",
      aas: "application/x-authorware-seg",
      abc: "text/vnd.abc",
      abw: "application/x-abiword",
      ac: "application/pkix-attr-cert",
      acc: "application/vnd.americandynamics.acc",
      ace: "application/x-ace-compressed",
      acgi: "text/html",
      acu: "application/vnd.acucobol",
      acx: "application/internet-property-stream",
      adp: "audio/adpcm",
      aep: "application/vnd.audiograph",
      afl: "video/animaflex",
      afp: "application/vnd.ibm.modcap",
      ahead: "application/vnd.ahead.space",
      ai: "application/postscript",
      aif: ["audio/aiff", "audio/x-aiff"],
      aifc: ["audio/aiff", "audio/x-aiff"],
      aiff: ["audio/aiff", "audio/x-aiff"],
      aim: "application/x-aim",
      aip: "text/x-audiosoft-intra",
      air: "application/vnd.adobe.air-application-installer-package+zip",
      ait: "application/vnd.dvb.ait",
      ami: "application/vnd.amiga.ami",
      ani: "application/x-navi-animation",
      aos: "application/x-nokia-9000-communicator-add-on-software",
      apk: "application/vnd.android.package-archive",
      application: "application/x-ms-application",
      apr: "application/vnd.lotus-approach",
      aps: "application/mime",
      arc: "application/octet-stream",
      arj: ["application/arj", "application/octet-stream"],
      art: "image/x-jg",
      asf: "video/x-ms-asf",
      asm: "text/x-asm",
      aso: "application/vnd.accpac.simply.aso",
      asp: "text/asp",
      asr: "video/x-ms-asf",
      asx: ["video/x-ms-asf", "application/x-mplayer2", "video/x-ms-asf-plugin"],
      atc: "application/vnd.acucorp",
      atomcat: "application/atomcat+xml",
      atomsvc: "application/atomsvc+xml",
      atx: "application/vnd.antix.game-component",
      au: ["audio/basic", "audio/x-au"],
      avi: ["video/avi", "video/msvideo", "application/x-troff-msvideo", "video/x-msvideo"],
      avs: "video/avs-video",
      aw: "application/applixware",
      axs: "application/olescript",
      azf: "application/vnd.airzip.filesecure.azf",
      azs: "application/vnd.airzip.filesecure.azs",
      azw: "application/vnd.amazon.ebook",
      bas: "text/plain",
      bcpio: "application/x-bcpio",
      bdf: "application/x-font-bdf",
      bdm: "application/vnd.syncml.dm+wbxml",
      bed: "application/vnd.realvnc.bed",
      bh2: "application/vnd.fujitsu.oasysprs",
      bin: ["application/octet-stream", "application/mac-binary", "application/macbinary", "application/x-macbinary", "application/x-binary"],
      bm: "image/bmp",
      bmi: "application/vnd.bmi",
      bmp: ["image/bmp", "image/x-windows-bmp"],
      boo: "application/book",
      book: "application/book",
      box: "application/vnd.previewsystems.box",
      boz: "application/x-bzip2",
      bsh: "application/x-bsh",
      btif: "image/prs.btif",
      bz: "application/x-bzip",
      bz2: "application/x-bzip2",
      c: ["text/plain", "text/x-c"],
      "c++": "text/plain",
      c11amc: "application/vnd.cluetrust.cartomobile-config",
      c11amz: "application/vnd.cluetrust.cartomobile-config-pkg",
      c4g: "application/vnd.clonk.c4group",
      cab: "application/vnd.ms-cab-compressed",
      car: "application/vnd.curl.car",
      cat: ["application/vnd.ms-pkiseccat", "application/vnd.ms-pki.seccat"],
      cc: ["text/plain", "text/x-c"],
      ccad: "application/clariscad",
      cco: "application/x-cocoa",
      ccxml: "application/ccxml+xml,",
      cdbcmsg: "application/vnd.contact.cmsg",
      cdf: ["application/cdf", "application/x-cdf", "application/x-netcdf"],
      cdkey: "application/vnd.mediastation.cdkey",
      cdmia: "application/cdmi-capability",
      cdmic: "application/cdmi-container",
      cdmid: "application/cdmi-domain",
      cdmio: "application/cdmi-object",
      cdmiq: "application/cdmi-queue",
      cdx: "chemical/x-cdx",
      cdxml: "application/vnd.chemdraw+xml",
      cdy: "application/vnd.cinderella",
      cer: ["application/pkix-cert", "application/x-x509-ca-cert"],
      cgm: "image/cgm",
      cha: "application/x-chat",
      chat: "application/x-chat",
      chm: "application/vnd.ms-htmlhelp",
      chrt: "application/vnd.kde.kchart",
      cif: "chemical/x-cif",
      cii: "application/vnd.anser-web-certificate-issue-initiation",
      cil: "application/vnd.ms-artgalry",
      cla: "application/vnd.claymore",
      class: ["application/octet-stream", "application/java", "application/java-byte-code", "application/java-vm", "application/x-java-class"],
      clkk: "application/vnd.crick.clicker.keyboard",
      clkp: "application/vnd.crick.clicker.palette",
      clkt: "application/vnd.crick.clicker.template",
      clkw: "application/vnd.crick.clicker.wordbank",
      clkx: "application/vnd.crick.clicker",
      clp: "application/x-msclip",
      cmc: "application/vnd.cosmocaller",
      cmdf: "chemical/x-cmdf",
      cml: "chemical/x-cml",
      cmp: "application/vnd.yellowriver-custom-menu",
      cmx: "image/x-cmx",
      cod: ["image/cis-cod", "application/vnd.rim.cod"],
      com: ["application/octet-stream", "text/plain"],
      conf: "text/plain",
      cpio: "application/x-cpio",
      cpp: "text/x-c",
      cpt: ["application/mac-compactpro", "application/x-compactpro", "application/x-cpt"],
      crd: "application/x-mscardfile",
      crl: ["application/pkix-crl", "application/pkcs-crl"],
      crt: ["application/pkix-cert", "application/x-x509-user-cert", "application/x-x509-ca-cert"],
      cryptonote: "application/vnd.rig.cryptonote",
      csh: ["text/x-script.csh", "application/x-csh"],
      csml: "chemical/x-csml",
      csp: "application/vnd.commonspace",
      css: ["text/css", "application/x-pointplus"],
      csv: "text/csv",
      cu: "application/cu-seeme",
      curl: "text/vnd.curl",
      cww: "application/prs.cww",
      cxx: "text/plain",
      dae: "model/vnd.collada+xml",
      daf: "application/vnd.mobius.daf",
      davmount: "application/davmount+xml",
      dcr: "application/x-director",
      dcurl: "text/vnd.curl.dcurl",
      dd2: "application/vnd.oma.dd2+xml",
      ddd: "application/vnd.fujixerox.ddd",
      deb: "application/x-debian-package",
      deepv: "application/x-deepv",
      def: "text/plain",
      der: "application/x-x509-ca-cert",
      dfac: "application/vnd.dreamfactory",
      dif: "video/x-dv",
      dir: "application/x-director",
      dis: "application/vnd.mobius.dis",
      djvu: "image/vnd.djvu",
      dl: ["video/dl", "video/x-dl"],
      dll: "application/x-msdownload",
      dms: "application/octet-stream",
      dna: "application/vnd.dna",
      doc: "application/msword",
      docm: "application/vnd.ms-word.document.macroenabled.12",
      docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      dot: "application/msword",
      dotm: "application/vnd.ms-word.template.macroenabled.12",
      dotx: "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
      dp: ["application/commonground", "application/vnd.osgi.dp"],
      dpg: "application/vnd.dpgraph",
      dra: "audio/vnd.dra",
      drw: "application/drafting",
      dsc: "text/prs.lines.tag",
      dssc: "application/dssc+der",
      dtb: "application/x-dtbook+xml",
      dtd: "application/xml-dtd",
      dts: "audio/vnd.dts",
      dtshd: "audio/vnd.dts.hd",
      dump: "application/octet-stream",
      dv: "video/x-dv",
      dvi: "application/x-dvi",
      dwf: ["model/vnd.dwf", "drawing/x-dwf"],
      dwg: ["application/acad", "image/vnd.dwg", "image/x-dwg"],
      dxf: ["application/dxf", "image/vnd.dwg", "image/vnd.dxf", "image/x-dwg"],
      dxp: "application/vnd.spotfire.dxp",
      dxr: "application/x-director",
      ecelp4800: "audio/vnd.nuera.ecelp4800",
      ecelp7470: "audio/vnd.nuera.ecelp7470",
      ecelp9600: "audio/vnd.nuera.ecelp9600",
      edm: "application/vnd.novadigm.edm",
      edx: "application/vnd.novadigm.edx",
      efif: "application/vnd.picsel",
      ei6: "application/vnd.pg.osasli",
      el: "text/x-script.elisp",
      elc: ["application/x-elc", "application/x-bytecode.elisp"],
      eml: "message/rfc822",
      emma: "application/emma+xml",
      env: "application/x-envoy",
      eol: "audio/vnd.digital-winds",
      eot: "application/vnd.ms-fontobject",
      eps: "application/postscript",
      epub: "application/epub+zip",
      es: ["application/ecmascript", "application/x-esrehber"],
      es3: "application/vnd.eszigno3+xml",
      esf: "application/vnd.epson.esf",
      etx: "text/x-setext",
      evy: ["application/envoy", "application/x-envoy"],
      exe: ["application/octet-stream", "application/x-msdownload"],
      exi: "application/exi",
      ext: "application/vnd.novadigm.ext",
      ez2: "application/vnd.ezpix-album",
      ez3: "application/vnd.ezpix-package",
      f: ["text/plain", "text/x-fortran"],
      f4v: "video/x-f4v",
      f77: "text/x-fortran",
      f90: ["text/plain", "text/x-fortran"],
      fbs: "image/vnd.fastbidsheet",
      fcs: "application/vnd.isac.fcs",
      fdf: "application/vnd.fdf",
      fe_launch: "application/vnd.denovo.fcselayout-link",
      fg5: "application/vnd.fujitsu.oasysgp",
      fh: "image/x-freehand",
      fif: ["application/fractals", "image/fif"],
      fig: "application/x-xfig",
      fli: ["video/fli", "video/x-fli"],
      flo: ["image/florian", "application/vnd.micrografx.flo"],
      flr: "x-world/x-vrml",
      flv: "video/x-flv",
      flw: "application/vnd.kde.kivio",
      flx: "text/vnd.fmi.flexstor",
      fly: "text/vnd.fly",
      fm: "application/vnd.framemaker",
      fmf: "video/x-atomic3d-feature",
      fnc: "application/vnd.frogans.fnc",
      for: ["text/plain", "text/x-fortran"],
      fpx: ["image/vnd.fpx", "image/vnd.net-fpx"],
      frl: "application/freeloader",
      fsc: "application/vnd.fsc.weblaunch",
      fst: "image/vnd.fst",
      ftc: "application/vnd.fluxtime.clip",
      fti: "application/vnd.anser-web-funds-transfer-initiation",
      funk: "audio/make",
      fvt: "video/vnd.fvt",
      fxp: "application/vnd.adobe.fxp",
      fzs: "application/vnd.fuzzysheet",
      g: "text/plain",
      g2w: "application/vnd.geoplan",
      g3: "image/g3fax",
      g3w: "application/vnd.geospace",
      gac: "application/vnd.groove-account",
      gdl: "model/vnd.gdl",
      geo: "application/vnd.dynageo",
      gex: "application/vnd.geometry-explorer",
      ggb: "application/vnd.geogebra.file",
      ggt: "application/vnd.geogebra.tool",
      ghf: "application/vnd.groove-help",
      gif: "image/gif",
      gim: "application/vnd.groove-identity-message",
      gl: ["video/gl", "video/x-gl"],
      gmx: "application/vnd.gmx",
      gnumeric: "application/x-gnumeric",
      gph: "application/vnd.flographit",
      gqf: "application/vnd.grafeq",
      gram: "application/srgs",
      grv: "application/vnd.groove-injector",
      grxml: "application/srgs+xml",
      gsd: "audio/x-gsm",
      gsf: "application/x-font-ghostscript",
      gsm: "audio/x-gsm",
      gsp: "application/x-gsp",
      gss: "application/x-gss",
      gtar: "application/x-gtar",
      gtm: "application/vnd.groove-tool-message",
      gtw: "model/vnd.gtw",
      gv: "text/vnd.graphviz",
      gxt: "application/vnd.geonext",
      gz: ["application/x-gzip", "application/x-compressed"],
      gzip: ["multipart/x-gzip", "application/x-gzip"],
      h: ["text/plain", "text/x-h"],
      h261: "video/h261",
      h263: "video/h263",
      h264: "video/h264",
      hal: "application/vnd.hal+xml",
      hbci: "application/vnd.hbci",
      hdf: "application/x-hdf",
      help: "application/x-helpfile",
      hgl: "application/vnd.hp-hpgl",
      hh: ["text/plain", "text/x-h"],
      hlb: "text/x-script",
      hlp: ["application/winhlp", "application/hlp", "application/x-helpfile", "application/x-winhelp"],
      hpg: "application/vnd.hp-hpgl",
      hpgl: "application/vnd.hp-hpgl",
      hpid: "application/vnd.hp-hpid",
      hps: "application/vnd.hp-hps",
      hqx: [
        "application/mac-binhex40",
        "application/binhex",
        "application/binhex4",
        "application/mac-binhex",
        "application/x-binhex40",
        "application/x-mac-binhex40"
      ],
      hta: "application/hta",
      htc: "text/x-component",
      htke: "application/vnd.kenameaapp",
      htm: "text/html",
      html: "text/html",
      htmls: "text/html",
      htt: "text/webviewhtml",
      htx: "text/html",
      hvd: "application/vnd.yamaha.hv-dic",
      hvp: "application/vnd.yamaha.hv-voice",
      hvs: "application/vnd.yamaha.hv-script",
      i2g: "application/vnd.intergeo",
      icc: "application/vnd.iccprofile",
      ice: "x-conference/x-cooltalk",
      ico: "image/x-icon",
      ics: "text/calendar",
      idc: "text/plain",
      ief: "image/ief",
      iefs: "image/ief",
      ifm: "application/vnd.shana.informed.formdata",
      iges: ["application/iges", "model/iges"],
      igl: "application/vnd.igloader",
      igm: "application/vnd.insors.igm",
      igs: ["application/iges", "model/iges"],
      igx: "application/vnd.micrografx.igx",
      iif: "application/vnd.shana.informed.interchange",
      iii: "application/x-iphone",
      ima: "application/x-ima",
      imap: "application/x-httpd-imap",
      imp: "application/vnd.accpac.simply.imp",
      ims: "application/vnd.ms-ims",
      inf: "application/inf",
      ins: ["application/x-internet-signup", "application/x-internett-signup"],
      ip: "application/x-ip2",
      ipfix: "application/ipfix",
      ipk: "application/vnd.shana.informed.package",
      irm: "application/vnd.ibm.rights-management",
      irp: "application/vnd.irepository.package+xml",
      isp: "application/x-internet-signup",
      isu: "video/x-isvideo",
      it: "audio/it",
      itp: "application/vnd.shana.informed.formtemplate",
      iv: "application/x-inventor",
      ivp: "application/vnd.immervision-ivp",
      ivr: "i-world/i-vrml",
      ivu: "application/vnd.immervision-ivu",
      ivy: "application/x-livescreen",
      jad: "text/vnd.sun.j2me.app-descriptor",
      jam: ["application/vnd.jam", "audio/x-jam"],
      jar: "application/java-archive",
      jav: ["text/plain", "text/x-java-source"],
      java: ["text/plain", "text/x-java-source,java", "text/x-java-source"],
      jcm: "application/x-java-commerce",
      jfif: ["image/pipeg", "image/jpeg", "image/pjpeg"],
      "jfif-tbnl": "image/jpeg",
      jisp: "application/vnd.jisp",
      jlt: "application/vnd.hp-jlyt",
      jnlp: "application/x-java-jnlp-file",
      joda: "application/vnd.joost.joda-archive",
      jpe: ["image/jpeg", "image/pjpeg"],
      jpeg: ["image/jpeg", "image/pjpeg"],
      jpg: ["image/jpeg", "image/pjpeg"],
      jpgv: "video/jpeg",
      jpm: "video/jpm",
      jps: "image/x-jps",
      js: ["application/javascript", "application/ecmascript", "text/javascript", "text/ecmascript", "application/x-javascript"],
      json: "application/json",
      jut: "image/jutvision",
      kar: ["audio/midi", "music/x-karaoke"],
      karbon: "application/vnd.kde.karbon",
      kfo: "application/vnd.kde.kformula",
      kia: "application/vnd.kidspiration",
      kml: "application/vnd.google-earth.kml+xml",
      kmz: "application/vnd.google-earth.kmz",
      kne: "application/vnd.kinar",
      kon: "application/vnd.kde.kontour",
      kpr: "application/vnd.kde.kpresenter",
      ksh: ["application/x-ksh", "text/x-script.ksh"],
      ksp: "application/vnd.kde.kspread",
      ktx: "image/ktx",
      ktz: "application/vnd.kahootz",
      kwd: "application/vnd.kde.kword",
      la: ["audio/nspaudio", "audio/x-nspaudio"],
      lam: "audio/x-liveaudio",
      lasxml: "application/vnd.las.las+xml",
      latex: "application/x-latex",
      lbd: "application/vnd.llamagraphics.life-balance.desktop",
      lbe: "application/vnd.llamagraphics.life-balance.exchange+xml",
      les: "application/vnd.hhe.lesson-player",
      lha: ["application/octet-stream", "application/lha", "application/x-lha"],
      lhx: "application/octet-stream",
      link66: "application/vnd.route66.link66+xml",
      list: "text/plain",
      lma: ["audio/nspaudio", "audio/x-nspaudio"],
      log: "text/plain",
      lrm: "application/vnd.ms-lrm",
      lsf: "video/x-la-asf",
      lsp: ["application/x-lisp", "text/x-script.lisp"],
      lst: "text/plain",
      lsx: ["video/x-la-asf", "text/x-la-asf"],
      ltf: "application/vnd.frogans.ltf",
      ltx: "application/x-latex",
      lvp: "audio/vnd.lucent.voice",
      lwp: "application/vnd.lotus-wordpro",
      lzh: ["application/octet-stream", "application/x-lzh"],
      lzx: ["application/lzx", "application/octet-stream", "application/x-lzx"],
      m: ["text/plain", "text/x-m"],
      m13: "application/x-msmediaview",
      m14: "application/x-msmediaview",
      m1v: "video/mpeg",
      m21: "application/mp21",
      m2a: "audio/mpeg",
      m2v: "video/mpeg",
      m3u: ["audio/x-mpegurl", "audio/x-mpequrl"],
      m3u8: "application/vnd.apple.mpegurl",
      m4v: "video/x-m4v",
      ma: "application/mathematica",
      mads: "application/mads+xml",
      mag: "application/vnd.ecowin.chart",
      man: "application/x-troff-man",
      map: "application/x-navimap",
      mar: "text/plain",
      mathml: "application/mathml+xml",
      mbd: "application/mbedlet",
      mbk: "application/vnd.mobius.mbk",
      mbox: "application/mbox",
      mc$: "application/x-magic-cap-package-1.0",
      mc1: "application/vnd.medcalcdata",
      mcd: ["application/mcad", "application/vnd.mcd", "application/x-mathcad"],
      mcf: ["image/vasa", "text/mcf"],
      mcp: "application/netmc",
      mcurl: "text/vnd.curl.mcurl",
      mdb: "application/x-msaccess",
      mdi: "image/vnd.ms-modi",
      me: "application/x-troff-me",
      meta4: "application/metalink4+xml",
      mets: "application/mets+xml",
      mfm: "application/vnd.mfmp",
      mgp: "application/vnd.osgeo.mapguide.package",
      mgz: "application/vnd.proteus.magazine",
      mht: "message/rfc822",
      mhtml: "message/rfc822",
      mid: ["audio/mid", "audio/midi", "music/crescendo", "x-music/x-midi", "audio/x-midi", "application/x-midi", "audio/x-mid"],
      midi: ["audio/midi", "music/crescendo", "x-music/x-midi", "audio/x-midi", "application/x-midi", "audio/x-mid"],
      mif: ["application/vnd.mif", "application/x-mif", "application/x-frame"],
      mime: ["message/rfc822", "www/mime"],
      mj2: "video/mj2",
      mjf: "audio/x-vnd.audioexplosion.mjuicemediafile",
      mjpg: "video/x-motion-jpeg",
      mlp: "application/vnd.dolby.mlp",
      mm: ["application/base64", "application/x-meme"],
      mmd: "application/vnd.chipnuts.karaoke-mmd",
      mme: "application/base64",
      mmf: "application/vnd.smaf",
      mmr: "image/vnd.fujixerox.edmics-mmr",
      mny: "application/x-msmoney",
      mod: ["audio/mod", "audio/x-mod"],
      mods: "application/mods+xml",
      moov: "video/quicktime",
      mov: "video/quicktime",
      movie: "video/x-sgi-movie",
      mp2: ["video/mpeg", "audio/mpeg", "video/x-mpeg", "audio/x-mpeg", "video/x-mpeq2a"],
      mp3: ["audio/mpeg", "audio/mpeg3", "video/mpeg", "audio/x-mpeg-3", "video/x-mpeg"],
      mp4: ["video/mp4", "application/mp4"],
      mp4a: "audio/mp4",
      mpa: ["video/mpeg", "audio/mpeg"],
      mpc: ["application/vnd.mophun.certificate", "application/x-project"],
      mpe: "video/mpeg",
      mpeg: "video/mpeg",
      mpg: ["video/mpeg", "audio/mpeg"],
      mpga: "audio/mpeg",
      mpkg: "application/vnd.apple.installer+xml",
      mpm: "application/vnd.blueice.multipass",
      mpn: "application/vnd.mophun.application",
      mpp: "application/vnd.ms-project",
      mpt: "application/x-project",
      mpv: "application/x-project",
      mpv2: "video/mpeg",
      mpx: "application/x-project",
      mpy: "application/vnd.ibm.minipay",
      mqy: "application/vnd.mobius.mqy",
      mrc: "application/marc",
      mrcx: "application/marcxml+xml",
      ms: "application/x-troff-ms",
      mscml: "application/mediaservercontrol+xml",
      mseq: "application/vnd.mseq",
      msf: "application/vnd.epson.msf",
      msg: "application/vnd.ms-outlook",
      msh: "model/mesh",
      msl: "application/vnd.mobius.msl",
      msty: "application/vnd.muvee.style",
      mts: "model/vnd.mts",
      mus: "application/vnd.musician",
      musicxml: "application/vnd.recordare.musicxml+xml",
      mv: "video/x-sgi-movie",
      mvb: "application/x-msmediaview",
      mwf: "application/vnd.mfer",
      mxf: "application/mxf",
      mxl: "application/vnd.recordare.musicxml",
      mxml: "application/xv+xml",
      mxs: "application/vnd.triscape.mxs",
      mxu: "video/vnd.mpegurl",
      my: "audio/make",
      mzz: "application/x-vnd.audioexplosion.mzz",
      "n-gage": "application/vnd.nokia.n-gage.symbian.install",
      n3: "text/n3",
      nap: "image/naplps",
      naplps: "image/naplps",
      nbp: "application/vnd.wolfram.player",
      nc: "application/x-netcdf",
      ncm: "application/vnd.nokia.configuration-message",
      ncx: "application/x-dtbncx+xml",
      ngdat: "application/vnd.nokia.n-gage.data",
      nif: "image/x-niff",
      niff: "image/x-niff",
      nix: "application/x-mix-transfer",
      nlu: "application/vnd.neurolanguage.nlu",
      nml: "application/vnd.enliven",
      nnd: "application/vnd.noblenet-directory",
      nns: "application/vnd.noblenet-sealer",
      nnw: "application/vnd.noblenet-web",
      npx: "image/vnd.net-fpx",
      nsc: "application/x-conference",
      nsf: "application/vnd.lotus-notes",
      nvd: "application/x-navidoc",
      nws: "message/rfc822",
      o: "application/octet-stream",
      oa2: "application/vnd.fujitsu.oasys2",
      oa3: "application/vnd.fujitsu.oasys3",
      oas: "application/vnd.fujitsu.oasys",
      obd: "application/x-msbinder",
      oda: "application/oda",
      odb: "application/vnd.oasis.opendocument.database",
      odc: "application/vnd.oasis.opendocument.chart",
      odf: "application/vnd.oasis.opendocument.formula",
      odft: "application/vnd.oasis.opendocument.formula-template",
      odg: "application/vnd.oasis.opendocument.graphics",
      odi: "application/vnd.oasis.opendocument.image",
      odm: "application/vnd.oasis.opendocument.text-master",
      odp: "application/vnd.oasis.opendocument.presentation",
      ods: "application/vnd.oasis.opendocument.spreadsheet",
      odt: "application/vnd.oasis.opendocument.text",
      oga: "audio/ogg",
      ogv: "video/ogg",
      ogx: "application/ogg",
      omc: "application/x-omc",
      omcd: "application/x-omcdatamaker",
      omcr: "application/x-omcregerator",
      onetoc: "application/onenote",
      opf: "application/oebps-package+xml",
      org: "application/vnd.lotus-organizer",
      osf: "application/vnd.yamaha.openscoreformat",
      osfpvg: "application/vnd.yamaha.openscoreformat.osfpvg+xml",
      otc: "application/vnd.oasis.opendocument.chart-template",
      otf: "application/x-font-otf",
      otg: "application/vnd.oasis.opendocument.graphics-template",
      oth: "application/vnd.oasis.opendocument.text-web",
      oti: "application/vnd.oasis.opendocument.image-template",
      otp: "application/vnd.oasis.opendocument.presentation-template",
      ots: "application/vnd.oasis.opendocument.spreadsheet-template",
      ott: "application/vnd.oasis.opendocument.text-template",
      oxt: "application/vnd.openofficeorg.extension",
      p: "text/x-pascal",
      p10: ["application/pkcs10", "application/x-pkcs10"],
      p12: ["application/pkcs-12", "application/x-pkcs12"],
      p7a: "application/x-pkcs7-signature",
      p7b: "application/x-pkcs7-certificates",
      p7c: ["application/pkcs7-mime", "application/x-pkcs7-mime"],
      p7m: ["application/pkcs7-mime", "application/x-pkcs7-mime"],
      p7r: "application/x-pkcs7-certreqresp",
      p7s: ["application/pkcs7-signature", "application/x-pkcs7-signature"],
      p8: "application/pkcs8",
      par: "text/plain-bas",
      part: "application/pro_eng",
      pas: "text/pascal",
      paw: "application/vnd.pawaafile",
      pbd: "application/vnd.powerbuilder6",
      pbm: "image/x-portable-bitmap",
      pcf: "application/x-font-pcf",
      pcl: ["application/vnd.hp-pcl", "application/x-pcl"],
      pclxl: "application/vnd.hp-pclxl",
      pct: "image/x-pict",
      pcurl: "application/vnd.curl.pcurl",
      pcx: "image/x-pcx",
      pdb: ["application/vnd.palm", "chemical/x-pdb"],
      pdf: "application/pdf",
      pfa: "application/x-font-type1",
      pfr: "application/font-tdpfr",
      pfunk: ["audio/make", "audio/make.my.funk"],
      pfx: "application/x-pkcs12",
      pgm: ["image/x-portable-graymap", "image/x-portable-greymap"],
      pgn: "application/x-chess-pgn",
      pgp: "application/pgp-signature",
      pic: ["image/pict", "image/x-pict"],
      pict: "image/pict",
      pkg: "application/x-newton-compatible-pkg",
      pki: "application/pkixcmp",
      pkipath: "application/pkix-pkipath",
      pko: ["application/ynd.ms-pkipko", "application/vnd.ms-pki.pko"],
      pl: ["text/plain", "text/x-script.perl"],
      plb: "application/vnd.3gpp.pic-bw-large",
      plc: "application/vnd.mobius.plc",
      plf: "application/vnd.pocketlearn",
      pls: "application/pls+xml",
      plx: "application/x-pixclscript",
      pm: ["text/x-script.perl-module", "image/x-xpixmap"],
      pm4: "application/x-pagemaker",
      pm5: "application/x-pagemaker",
      pma: "application/x-perfmon",
      pmc: "application/x-perfmon",
      pml: ["application/vnd.ctc-posml", "application/x-perfmon"],
      pmr: "application/x-perfmon",
      pmw: "application/x-perfmon",
      png: "image/png",
      pnm: ["application/x-portable-anymap", "image/x-portable-anymap"],
      portpkg: "application/vnd.macports.portpkg",
      pot: ["application/vnd.ms-powerpoint", "application/mspowerpoint"],
      potm: "application/vnd.ms-powerpoint.template.macroenabled.12",
      potx: "application/vnd.openxmlformats-officedocument.presentationml.template",
      pov: "model/x-pov",
      ppa: "application/vnd.ms-powerpoint",
      ppam: "application/vnd.ms-powerpoint.addin.macroenabled.12",
      ppd: "application/vnd.cups-ppd",
      ppm: "image/x-portable-pixmap",
      pps: ["application/vnd.ms-powerpoint", "application/mspowerpoint"],
      ppsm: "application/vnd.ms-powerpoint.slideshow.macroenabled.12",
      ppsx: "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
      ppt: ["application/vnd.ms-powerpoint", "application/mspowerpoint", "application/powerpoint", "application/x-mspowerpoint"],
      pptm: "application/vnd.ms-powerpoint.presentation.macroenabled.12",
      pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
      ppz: "application/mspowerpoint",
      prc: "application/x-mobipocket-ebook",
      pre: ["application/vnd.lotus-freelance", "application/x-freelance"],
      prf: "application/pics-rules",
      prt: "application/pro_eng",
      ps: "application/postscript",
      psb: "application/vnd.3gpp.pic-bw-small",
      psd: ["application/octet-stream", "image/vnd.adobe.photoshop"],
      psf: "application/x-font-linux-psf",
      pskcxml: "application/pskc+xml",
      ptid: "application/vnd.pvi.ptid1",
      pub: "application/x-mspublisher",
      pvb: "application/vnd.3gpp.pic-bw-var",
      pvu: "paleovu/x-pv",
      pwn: "application/vnd.3m.post-it-notes",
      pwz: "application/vnd.ms-powerpoint",
      py: "text/x-script.phyton",
      pya: "audio/vnd.ms-playready.media.pya",
      pyc: "applicaiton/x-bytecode.python",
      pyv: "video/vnd.ms-playready.media.pyv",
      qam: "application/vnd.epson.quickanime",
      qbo: "application/vnd.intu.qbo",
      qcp: "audio/vnd.qcelp",
      qd3: "x-world/x-3dmf",
      qd3d: "x-world/x-3dmf",
      qfx: "application/vnd.intu.qfx",
      qif: "image/x-quicktime",
      qps: "application/vnd.publishare-delta-tree",
      qt: "video/quicktime",
      qtc: "video/x-qtc",
      qti: "image/x-quicktime",
      qtif: "image/x-quicktime",
      qxd: "application/vnd.quark.quarkxpress",
      ra: ["audio/x-realaudio", "audio/x-pn-realaudio", "audio/x-pn-realaudio-plugin"],
      ram: "audio/x-pn-realaudio",
      rar: "application/x-rar-compressed",
      ras: ["image/cmu-raster", "application/x-cmu-raster", "image/x-cmu-raster"],
      rast: "image/cmu-raster",
      rcprofile: "application/vnd.ipunplugged.rcprofile",
      rdf: "application/rdf+xml",
      rdz: "application/vnd.data-vision.rdz",
      rep: "application/vnd.businessobjects",
      res: "application/x-dtbresource+xml",
      rexx: "text/x-script.rexx",
      rf: "image/vnd.rn-realflash",
      rgb: "image/x-rgb",
      rif: "application/reginfo+xml",
      rip: "audio/vnd.rip",
      rl: "application/resource-lists+xml",
      rlc: "image/vnd.fujixerox.edmics-rlc",
      rld: "application/resource-lists-diff+xml",
      rm: ["application/vnd.rn-realmedia", "audio/x-pn-realaudio"],
      rmi: "audio/mid",
      rmm: "audio/x-pn-realaudio",
      rmp: ["audio/x-pn-realaudio-plugin", "audio/x-pn-realaudio"],
      rms: "application/vnd.jcp.javame.midlet-rms",
      rnc: "application/relax-ng-compact-syntax",
      rng: ["application/ringing-tones", "application/vnd.nokia.ringing-tone"],
      rnx: "application/vnd.rn-realplayer",
      roff: "application/x-troff",
      rp: "image/vnd.rn-realpix",
      rp9: "application/vnd.cloanto.rp9",
      rpm: "audio/x-pn-realaudio-plugin",
      rpss: "application/vnd.nokia.radio-presets",
      rpst: "application/vnd.nokia.radio-preset",
      rq: "application/sparql-query",
      rs: "application/rls-services+xml",
      rsd: "application/rsd+xml",
      rt: ["text/richtext", "text/vnd.rn-realtext"],
      rtf: ["application/rtf", "text/richtext", "application/x-rtf"],
      rtx: ["text/richtext", "application/rtf"],
      rv: "video/vnd.rn-realvideo",
      s: "text/x-asm",
      s3m: "audio/s3m",
      saf: "application/vnd.yamaha.smaf-audio",
      saveme: "application/octet-stream",
      sbk: "application/x-tbook",
      sbml: "application/sbml+xml",
      sc: "application/vnd.ibm.secure-container",
      scd: "application/x-msschedule",
      scm: ["application/vnd.lotus-screencam", "video/x-scm", "text/x-script.guile", "application/x-lotusscreencam", "text/x-script.scheme"],
      scq: "application/scvp-cv-request",
      scs: "application/scvp-cv-response",
      sct: "text/scriptlet",
      scurl: "text/vnd.curl.scurl",
      sda: "application/vnd.stardivision.draw",
      sdc: "application/vnd.stardivision.calc",
      sdd: "application/vnd.stardivision.impress",
      sdkm: "application/vnd.solent.sdkm+xml",
      sdml: "text/plain",
      sdp: ["application/sdp", "application/x-sdp"],
      sdr: "application/sounder",
      sdw: "application/vnd.stardivision.writer",
      sea: ["application/sea", "application/x-sea"],
      see: "application/vnd.seemail",
      seed: "application/vnd.fdsn.seed",
      sema: "application/vnd.sema",
      semd: "application/vnd.semd",
      semf: "application/vnd.semf",
      ser: "application/java-serialized-object",
      set: "application/set",
      setpay: "application/set-payment-initiation",
      setreg: "application/set-registration-initiation",
      "sfd-hdstx": "application/vnd.hydrostatix.sof-data",
      sfs: "application/vnd.spotfire.sfs",
      sgl: "application/vnd.stardivision.writer-global",
      sgm: ["text/sgml", "text/x-sgml"],
      sgml: ["text/sgml", "text/x-sgml"],
      sh: ["application/x-shar", "application/x-bsh", "application/x-sh", "text/x-script.sh"],
      shar: ["application/x-bsh", "application/x-shar"],
      shf: "application/shf+xml",
      shtml: ["text/html", "text/x-server-parsed-html"],
      sid: "audio/x-psid",
      sis: "application/vnd.symbian.install",
      sit: ["application/x-stuffit", "application/x-sit"],
      sitx: "application/x-stuffitx",
      skd: "application/x-koan",
      skm: "application/x-koan",
      skp: ["application/vnd.koan", "application/x-koan"],
      skt: "application/x-koan",
      sl: "application/x-seelogo",
      sldm: "application/vnd.ms-powerpoint.slide.macroenabled.12",
      sldx: "application/vnd.openxmlformats-officedocument.presentationml.slide",
      slt: "application/vnd.epson.salt",
      sm: "application/vnd.stepmania.stepchart",
      smf: "application/vnd.stardivision.math",
      smi: ["application/smil", "application/smil+xml"],
      smil: "application/smil",
      snd: ["audio/basic", "audio/x-adpcm"],
      snf: "application/x-font-snf",
      sol: "application/solids",
      spc: ["text/x-speech", "application/x-pkcs7-certificates"],
      spf: "application/vnd.yamaha.smaf-phrase",
      spl: ["application/futuresplash", "application/x-futuresplash"],
      spot: "text/vnd.in3d.spot",
      spp: "application/scvp-vp-response",
      spq: "application/scvp-vp-request",
      spr: "application/x-sprite",
      sprite: "application/x-sprite",
      src: "application/x-wais-source",
      sru: "application/sru+xml",
      srx: "application/sparql-results+xml",
      sse: "application/vnd.kodak-descriptor",
      ssf: "application/vnd.epson.ssf",
      ssi: "text/x-server-parsed-html",
      ssm: "application/streamingmedia",
      ssml: "application/ssml+xml",
      sst: ["application/vnd.ms-pkicertstore", "application/vnd.ms-pki.certstore"],
      st: "application/vnd.sailingtracker.track",
      stc: "application/vnd.sun.xml.calc.template",
      std: "application/vnd.sun.xml.draw.template",
      step: "application/step",
      stf: "application/vnd.wt.stf",
      sti: "application/vnd.sun.xml.impress.template",
      stk: "application/hyperstudio",
      stl: ["application/vnd.ms-pkistl", "application/sla", "application/vnd.ms-pki.stl", "application/x-navistyle"],
      stm: "text/html",
      stp: "application/step",
      str: "application/vnd.pg.format",
      stw: "application/vnd.sun.xml.writer.template",
      sub: "image/vnd.dvb.subtitle",
      sus: "application/vnd.sus-calendar",
      sv4cpio: "application/x-sv4cpio",
      sv4crc: "application/x-sv4crc",
      svc: "application/vnd.dvb.service",
      svd: "application/vnd.svd",
      svf: ["image/vnd.dwg", "image/x-dwg"],
      svg: "image/svg+xml",
      svr: ["x-world/x-svr", "application/x-world"],
      swf: "application/x-shockwave-flash",
      swi: "application/vnd.aristanetworks.swi",
      sxc: "application/vnd.sun.xml.calc",
      sxd: "application/vnd.sun.xml.draw",
      sxg: "application/vnd.sun.xml.writer.global",
      sxi: "application/vnd.sun.xml.impress",
      sxm: "application/vnd.sun.xml.math",
      sxw: "application/vnd.sun.xml.writer",
      t: ["text/troff", "application/x-troff"],
      talk: "text/x-speech",
      tao: "application/vnd.tao.intent-module-archive",
      tar: "application/x-tar",
      tbk: ["application/toolbook", "application/x-tbook"],
      tcap: "application/vnd.3gpp2.tcap",
      tcl: ["text/x-script.tcl", "application/x-tcl"],
      tcsh: "text/x-script.tcsh",
      teacher: "application/vnd.smart.teacher",
      tei: "application/tei+xml",
      tex: "application/x-tex",
      texi: "application/x-texinfo",
      texinfo: "application/x-texinfo",
      text: ["application/plain", "text/plain"],
      tfi: "application/thraud+xml",
      tfm: "application/x-tex-tfm",
      tgz: ["application/gnutar", "application/x-compressed"],
      thmx: "application/vnd.ms-officetheme",
      tif: ["image/tiff", "image/x-tiff"],
      tiff: ["image/tiff", "image/x-tiff"],
      tmo: "application/vnd.tmobile-livetv",
      torrent: "application/x-bittorrent",
      tpl: "application/vnd.groove-tool-template",
      tpt: "application/vnd.trid.tpt",
      tr: "application/x-troff",
      tra: "application/vnd.trueapp",
      trm: "application/x-msterminal",
      tsd: "application/timestamped-data",
      tsi: "audio/tsp-audio",
      tsp: ["application/dsptype", "audio/tsplayer"],
      tsv: "text/tab-separated-values",
      ttf: "application/x-font-ttf",
      ttl: "text/turtle",
      turbot: "image/florian",
      twd: "application/vnd.simtech-mindmapper",
      txd: "application/vnd.genomatix.tuxedo",
      txf: "application/vnd.mobius.txf",
      txt: "text/plain",
      ufd: "application/vnd.ufdl",
      uil: "text/x-uil",
      uls: "text/iuls",
      umj: "application/vnd.umajin",
      uni: "text/uri-list",
      unis: "text/uri-list",
      unityweb: "application/vnd.unity",
      unv: "application/i-deas",
      uoml: "application/vnd.uoml+xml",
      uri: "text/uri-list",
      uris: "text/uri-list",
      ustar: ["application/x-ustar", "multipart/x-ustar"],
      utz: "application/vnd.uiq.theme",
      uu: ["application/octet-stream", "text/x-uuencode"],
      uue: "text/x-uuencode",
      uva: "audio/vnd.dece.audio",
      uvh: "video/vnd.dece.hd",
      uvi: "image/vnd.dece.graphic",
      uvm: "video/vnd.dece.mobile",
      uvp: "video/vnd.dece.pd",
      uvs: "video/vnd.dece.sd",
      uvu: "video/vnd.uvvu.mp4",
      uvv: "video/vnd.dece.video",
      vcd: "application/x-cdlink",
      vcf: "text/x-vcard",
      vcg: "application/vnd.groove-vcard",
      vcs: "text/x-vcalendar",
      vcx: "application/vnd.vcx",
      vda: "application/vda",
      vdo: "video/vdo",
      vew: "application/groupwise",
      vis: "application/vnd.visionary",
      viv: ["video/vivo", "video/vnd.vivo"],
      vivo: ["video/vivo", "video/vnd.vivo"],
      vmd: "application/vocaltec-media-desc",
      vmf: "application/vocaltec-media-file",
      voc: ["audio/voc", "audio/x-voc"],
      vos: "video/vosaic",
      vox: "audio/voxware",
      vqe: "audio/x-twinvq-plugin",
      vqf: "audio/x-twinvq",
      vql: "audio/x-twinvq-plugin",
      vrml: ["model/vrml", "x-world/x-vrml", "application/x-vrml"],
      vrt: "x-world/x-vrt",
      vsd: ["application/vnd.visio", "application/x-visio"],
      vsf: "application/vnd.vsf",
      vst: "application/x-visio",
      vsw: "application/x-visio",
      vtu: "model/vnd.vtu",
      vxml: "application/voicexml+xml",
      w60: "application/wordperfect6.0",
      w61: "application/wordperfect6.1",
      w6w: "application/msword",
      wad: "application/x-doom",
      wav: ["audio/wav", "audio/x-wav"],
      wax: "audio/x-ms-wax",
      wb1: "application/x-qpro",
      wbmp: "image/vnd.wap.wbmp",
      wbs: "application/vnd.criticaltools.wbs+xml",
      wbxml: "application/vnd.wap.wbxml",
      wcm: "application/vnd.ms-works",
      wdb: "application/vnd.ms-works",
      web: "application/vnd.xara",
      weba: "audio/webm",
      webm: "video/webm",
      webp: "image/webp",
      wg: "application/vnd.pmi.widget",
      wgt: "application/widget",
      wiz: "application/msword",
      wk1: "application/x-123",
      wks: "application/vnd.ms-works",
      wm: "video/x-ms-wm",
      wma: "audio/x-ms-wma",
      wmd: "application/x-ms-wmd",
      wmf: ["windows/metafile", "application/x-msmetafile"],
      wml: "text/vnd.wap.wml",
      wmlc: "application/vnd.wap.wmlc",
      wmls: "text/vnd.wap.wmlscript",
      wmlsc: "application/vnd.wap.wmlscriptc",
      wmv: "video/x-ms-wmv",
      wmx: "video/x-ms-wmx",
      wmz: "application/x-ms-wmz",
      woff: "application/x-font-woff",
      word: "application/msword",
      wp: "application/wordperfect",
      wp5: ["application/wordperfect", "application/wordperfect6.0"],
      wp6: "application/wordperfect",
      wpd: ["application/wordperfect", "application/vnd.wordperfect", "application/x-wpwin"],
      wpl: "application/vnd.ms-wpl",
      wps: "application/vnd.ms-works",
      wq1: "application/x-lotus",
      wqd: "application/vnd.wqd",
      wri: ["application/mswrite", "application/x-wri", "application/x-mswrite"],
      wrl: ["model/vrml", "x-world/x-vrml", "application/x-world"],
      wrz: ["model/vrml", "x-world/x-vrml"],
      wsc: "text/scriplet",
      wsdl: "application/wsdl+xml",
      wspolicy: "application/wspolicy+xml",
      wsrc: "application/x-wais-source",
      wtb: "application/vnd.webturbo",
      wtk: "application/x-wintalk",
      wvx: "video/x-ms-wvx",
      "x-png": "image/png",
      x3d: "application/vnd.hzn-3d-crossword",
      xaf: "x-world/x-vrml",
      xap: "application/x-silverlight-app",
      xar: "application/vnd.xara",
      xbap: "application/x-ms-xbap",
      xbd: "application/vnd.fujixerox.docuworks.binder",
      xbm: ["image/xbm", "image/x-xbm", "image/x-xbitmap"],
      xdf: "application/xcap-diff+xml",
      xdm: "application/vnd.syncml.dm+xml",
      xdp: "application/vnd.adobe.xdp+xml",
      xdr: "video/x-amt-demorun",
      xdssc: "application/dssc+xml",
      xdw: "application/vnd.fujixerox.docuworks",
      xenc: "application/xenc+xml",
      xer: "application/patch-ops-error+xml",
      xfdf: "application/vnd.adobe.xfdf",
      xfdl: "application/vnd.xfdl",
      xgz: "xgl/drawing",
      xhtml: "application/xhtml+xml",
      xif: "image/vnd.xiff",
      xl: "application/excel",
      xla: ["application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel"],
      xlam: "application/vnd.ms-excel.addin.macroenabled.12",
      xlb: ["application/excel", "application/vnd.ms-excel", "application/x-excel"],
      xlc: ["application/vnd.ms-excel", "application/excel", "application/x-excel"],
      xld: ["application/excel", "application/x-excel"],
      xlk: ["application/excel", "application/x-excel"],
      xll: ["application/excel", "application/vnd.ms-excel", "application/x-excel"],
      xlm: ["application/vnd.ms-excel", "application/excel", "application/x-excel"],
      xls: ["application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel"],
      xlsb: "application/vnd.ms-excel.sheet.binary.macroenabled.12",
      xlsm: "application/vnd.ms-excel.sheet.macroenabled.12",
      xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      xlt: ["application/vnd.ms-excel", "application/excel", "application/x-excel"],
      xltm: "application/vnd.ms-excel.template.macroenabled.12",
      xltx: "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
      xlv: ["application/excel", "application/x-excel"],
      xlw: ["application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel"],
      xm: "audio/xm",
      xml: ["application/xml", "text/xml", "application/atom+xml", "application/rss+xml"],
      xmz: "xgl/movie",
      xo: "application/vnd.olpc-sugar",
      xof: "x-world/x-vrml",
      xop: "application/xop+xml",
      xpi: "application/x-xpinstall",
      xpix: "application/x-vnd.ls-xpix",
      xpm: ["image/xpm", "image/x-xpixmap"],
      xpr: "application/vnd.is-xpr",
      xps: "application/vnd.ms-xpsdocument",
      xpw: "application/vnd.intercon.formnet",
      xslt: "application/xslt+xml",
      xsm: "application/vnd.syncml+xml",
      xspf: "application/xspf+xml",
      xsr: "video/x-amt-showrun",
      xul: "application/vnd.mozilla.xul+xml",
      xwd: ["image/x-xwd", "image/x-xwindowdump"],
      xyz: ["chemical/x-xyz", "chemical/x-pdb"],
      yang: "application/yang",
      yin: "application/yin+xml",
      z: ["application/x-compressed", "application/x-compress"],
      zaz: "application/vnd.zzazz.deck+xml",
      zip: ["application/zip", "multipart/x-zip", "application/x-zip-compressed", "application/x-compressed"],
      zir: "application/vnd.zul",
      zmm: "application/vnd.handheld-entertainment+xml",
      zoo: "application/octet-stream",
      zsh: "text/x-script.zsh"
    }
  };
  return mimetypes;
}
var hasRequiredLibmime;
function requireLibmime() {
  if (hasRequiredLibmime) return libmime.exports;
  hasRequiredLibmime = 1;
  const { Buffer } = require$$0;
  const libcharset = /* @__PURE__ */ requireCharset();
  const libbase64 = /* @__PURE__ */ requireLibbase64();
  const libqp = /* @__PURE__ */ requireLibqp();
  const mimetypes2 = /* @__PURE__ */ requireMimetypes();
  const STAGE_KEY = 4097;
  const STAGE_VALUE = 4098;
  class Libmime {
    constructor(config) {
      this.config = config || {};
    }
    /**
     * Checks if a value is plaintext string (uses only printable 7bit chars)
     *
     * @param {String} value String to be tested
     * @returns {Boolean} true if it is a plaintext string
     */
    isPlainText(value) {
      if (typeof value !== "string" || /[\x00-\x08\x0b\x0c\x0e-\x1f\u0080-\uFFFF]/.test(value)) {
        return false;
      } else {
        return true;
      }
    }
    /**
     * Checks if a multi line string containes lines longer than the selected value.
     *
     * Useful when detecting if a mail message needs any processing at all –
     * if only plaintext characters are used and lines are short, then there is
     * no need to encode the values in any way. If the value is plaintext but has
     * longer lines then allowed, then use format=flowed
     *
     * @param {Number} lineLength Max line length to check for
     * @returns {Boolean} Returns true if there is at least one line longer than lineLength chars
     */
    hasLongerLines(str, lineLength) {
      return new RegExp("^.{" + (lineLength + 1) + ",}", "m").test(str);
    }
    /**
     * Decodes a string from a format=flowed soft wrapping.
     *
     * @param {String} str Plaintext string with format=flowed to decode
     * @param {Boolean} [delSp] If true, delete leading spaces (delsp=yes)
     * @return {String} Mime decoded string
     */
    decodeFlowed(str, delSp) {
      str = (str || "").toString();
      let lines = str.split(/\r?\n/);
      let result = [], buffer = null;
      for (let i = 0; i < lines.length; i++) {
        let line = lines[i];
        let isSoftBreak = buffer !== null && / $/.test(buffer) && !/(^|\n)-- $/.test(buffer);
        if (isSoftBreak) {
          if (delSp) {
            buffer = buffer.slice(0, -1) + line;
          } else {
            buffer += line;
          }
        } else {
          if (buffer !== null) {
            result.push(buffer);
          }
          buffer = line;
        }
      }
      if (buffer) {
        result.push(buffer);
      }
      return result.join("\n").replace(/^ /gm, "");
    }
    /**
     * Adds soft line breaks to content marked with format=flowed to
     * ensure that no line in the message is never longer than lineLength
     *
     * @param {String} str Plaintext string that requires wrapping
     * @param {Number} [lineLength=76] Maximum length of a line
     * @return {String} String with forced line breaks
     */
    encodeFlowed(str, lineLength) {
      lineLength = lineLength || 76;
      let flowed = [];
      str.split(/\r?\n/).forEach((line) => {
        flowed.push(
          this.foldLines(
            line.replace(/^( |From|>)/gim, " $1"),
            lineLength,
            true
          )
        );
      });
      return flowed.join("\r\n");
    }
    /**
     * Encodes a string or an Buffer to an UTF-8 MIME Word (rfc2047)
     *
     * @param {String|Buffer} data String to be encoded
     * @param {String} mimeWordEncoding='Q' Encoding for the mime word, either Q or B
     * @param {Number} [maxLength=0] If set, split mime words into several chunks if needed
     * @return {String} Single or several mime words joined together
     */
    encodeWord(data, mimeWordEncoding, maxLength) {
      mimeWordEncoding = (mimeWordEncoding || "Q").toString().toUpperCase().trim().charAt(0);
      maxLength = maxLength || 0;
      let encodedStr;
      let toCharset = "UTF-8";
      if (maxLength && maxLength > 7 + toCharset.length) {
        maxLength -= 7 + toCharset.length;
      }
      if (mimeWordEncoding === "Q") {
        encodedStr = libqp.encode(data).replace(/[^a-z0-9!*+\-/=]/gi, (chr) => {
          let ord = chr.charCodeAt(0).toString(16).toUpperCase();
          if (chr === " ") {
            return "_";
          } else {
            return "=" + (ord.length === 1 ? "0" + ord : ord);
          }
        });
      } else if (mimeWordEncoding === "B") {
        encodedStr = typeof data === "string" ? data : libbase64.encode(data);
        maxLength = maxLength ? Math.max(3, (maxLength - maxLength % 4) / 4 * 3) : 0;
      }
      if (maxLength && (mimeWordEncoding !== "B" ? encodedStr : libbase64.encode(data)).length > maxLength) {
        if (mimeWordEncoding === "Q") {
          encodedStr = this.splitMimeEncodedString(encodedStr, maxLength).join("?= =?" + toCharset + "?" + mimeWordEncoding + "?");
        } else {
          let parts = [];
          let lpart = "";
          for (let i = 0, len = encodedStr.length; i < len; i++) {
            let chr = encodedStr.charAt(i);
            if (/[\ud83c\ud83d\ud83e]/.test(chr) && i < len - 1) {
              chr += encodedStr.charAt(++i);
            }
            if (Buffer.byteLength(lpart + chr) <= maxLength || i === 0) {
              lpart += chr;
            } else {
              parts.push(libbase64.encode(lpart));
              lpart = chr;
            }
          }
          if (lpart) {
            parts.push(libbase64.encode(lpart));
          }
          if (parts.length > 1) {
            encodedStr = parts.join("?= =?" + toCharset + "?" + mimeWordEncoding + "?");
          } else {
            encodedStr = parts.join("");
          }
        }
      } else if (mimeWordEncoding === "B") {
        encodedStr = libbase64.encode(data);
      }
      return "=?" + toCharset + "?" + mimeWordEncoding + "?" + encodedStr + (encodedStr.substr(-2) === "?=" ? "" : "?=");
    }
    /**
     * Decode a complete mime word encoded string
     *
     * @param {String} str Mime word encoded string
     * @return {String} Decoded unicode string
     */
    decodeWord(charset2, encoding, str) {
      let splitPos = charset2.indexOf("*");
      if (splitPos >= 0) {
        charset2 = charset2.substr(0, splitPos);
      }
      charset2 = libcharset.normalizeCharset(charset2);
      encoding = encoding.toUpperCase();
      if (encoding === "Q") {
        str = str.replace(/=\s+([0-9a-fA-F])/g, "=$1").replace(/[_\s]/g, " ");
        let buf = Buffer.from(str);
        let bytes = [];
        for (let i = 0, len = buf.length; i < len; i++) {
          let c = buf[i];
          if (i <= len - 2 && c === 61) {
            let c1 = this.getHex(buf[i + 1]);
            let c2 = this.getHex(buf[i + 2]);
            if (c1 && c2) {
              let c3 = parseInt(c1 + c2, 16);
              bytes.push(c3);
              i += 2;
              continue;
            }
          }
          bytes.push(c);
        }
        str = Buffer.from(bytes);
      } else if (encoding === "B") {
        str = Buffer.concat(
          str.split("=").filter((s) => s !== "").map((str2) => Buffer.from(str2, "base64"))
        );
      } else {
        str = Buffer.from(str);
      }
      return libcharset.decode(str, charset2);
    }
    /**
     * Finds word sequences with non ascii text and converts these to mime words
     *
     * @param {String|Buffer} data String to be encoded
     * @param {String} mimeWordEncoding='Q' Encoding for the mime word, either Q or B
     * @param {Number} [maxLength=0] If set, split mime words into several chunks if needed
     * @param {String} [fromCharset='UTF-8'] Source sharacter set
     * @return {String} String with possible mime words
     */
    encodeWords(data, mimeWordEncoding, maxLength, fromCharset) {
      if (!fromCharset && typeof maxLength === "string" && !maxLength.match(/^[0-9]+$/)) {
        fromCharset = maxLength;
        maxLength = void 0;
      }
      maxLength = maxLength || 0;
      let decodedValue = libcharset.decode(libcharset.convert(data || "", fromCharset));
      let encodedValue;
      let firstMatch = decodedValue.match(/(?:^|\s)([^\s]*[\u0080-\uFFFF])/);
      if (!firstMatch) {
        return decodedValue;
      }
      let lastMatch = decodedValue.match(/([\u0080-\uFFFF][^\s]*)[^\u0080-\uFFFF]*$/);
      if (!lastMatch) {
        return decodedValue;
      }
      let startIndex = firstMatch.index + (firstMatch[0].match(/[^\s]/) || {
        index: 0
      }).index;
      let endIndex = lastMatch.index + (lastMatch[1] || "").length;
      encodedValue = (startIndex ? decodedValue.substr(0, startIndex) : "") + this.encodeWord(decodedValue.substring(startIndex, endIndex), mimeWordEncoding || "Q", maxLength) + (endIndex < decodedValue.length ? decodedValue.substr(endIndex) : "");
      return encodedValue;
    }
    /**
     * Decode a string that might include one or several mime words
     *
     * @param {String} str String including some mime words that will be encoded
     * @return {String} Decoded unicode string
     */
    decodeWords(str) {
      return (str || "").toString().replace(/(=\?([^?]+)\?[Bb]\?[^?]*\?=)\s*(?==\?([^?]+)\?[Bb]\?[^?]*\?=)/g, (match, left, chLeft, chRight) => {
        if (libcharset.normalizeCharset(chLeft || "") === libcharset.normalizeCharset(chRight || "")) {
          return left + "__\0JOIN\0__";
        }
        return match;
      }).replace(/(=\?([^?]+)\?[Qq]\?[^?]*\?=)\s*(?==\?([^?]+)\?[Qq]\?[^?]*\?=)/g, (match, left, chLeft, chRight) => {
        if (libcharset.normalizeCharset(chLeft || "") === libcharset.normalizeCharset(chRight || "")) {
          return left + "__\0JOIN\0__";
        }
        return match;
      }).replace(/(\?=)?__\x00JOIN\x00__(=\?([^?]+)\?[QqBb]\?)?/g, "").replace(/(=\?[^?]+\?[QqBb]\?[^?]*\?=)\s+(?==\?[^?]+\?[QqBb]\?[^?]*\?=)/g, "$1").replace(/=\?([\w_\-*]+)\?([QqBb])\?([^?]*)\?=/g, (m, charset2, encoding, text) => this.decodeWord(charset2, encoding, text));
    }
    getHex(c) {
      if (c >= 48 && c <= 57 || c >= 97 && c <= 102 || c >= 65 && c <= 70) {
        return String.fromCharCode(c);
      }
      return false;
    }
    /**
     * Splits a string by :
     * The result is not mime word decoded, you need to do your own decoding based
     * on the rules for the specific header key
     *
     * @param {String} headerLine Single header line, might include linebreaks as well if folded
     * @return {Object} And object of {key, value}
     */
    decodeHeader(headerLine) {
      let line = (headerLine || "").toString().replace(/(?:\r?\n|\r)[ \t]*/g, " ").trim(), match = line.match(/^\s*([^:]+):(.*)$/), key = (match && match[1] || "").trim().toLowerCase(), value = (match && match[2] || "").trim();
      return {
        key,
        value
      };
    }
    /**
     * Parses a block of header lines. Does not decode mime words as every
     * header might have its own rules (eg. formatted email addresses and such)
     *
     * @param {String} headers Headers string
     * @return {Object} An object of headers, where header keys are object keys. NB! Several values with the same key make up an Array
     */
    decodeHeaders(headers) {
      let lines = headers.split(/\r?\n|\r/), headersObj = {}, header, i, len;
      for (i = lines.length - 1; i >= 0; i--) {
        if (i && lines[i].match(/^\s/)) {
          lines[i - 1] += "\r\n" + lines[i];
          lines.splice(i, 1);
        }
      }
      for (i = 0, len = lines.length; i < len; i++) {
        header = this.decodeHeader(lines[i]);
        if (!headersObj[header.key]) {
          headersObj[header.key] = [header.value];
        } else {
          headersObj[header.key].push(header.value);
        }
      }
      return headersObj;
    }
    /**
     * Joins parsed header value together as 'value; param1=value1; param2=value2'
     * PS: We are following RFC 822 for the list of special characters that we need to keep in quotes.
     *      Refer: https://www.w3.org/Protocols/rfc1341/4_Content-Type.html
     * @param {Object} structured Parsed header value
     * @return {String} joined header value
     */
    buildHeaderValue(structured) {
      let paramsArray = [];
      Object.keys(structured.params || {}).forEach((param) => {
        let value = structured.params[param];
        if (!this.isPlainText(value) || value.length >= 75) {
          this.buildHeaderParam(param, value, 50).forEach((encodedParam) => {
            if (!/[\s"\\;:/=(),<>@[\]?]|^[-']|'$/.test(encodedParam.value) || encodedParam.key.substr(-1) === "*") {
              paramsArray.push(encodedParam.key + "=" + encodedParam.value);
            } else {
              paramsArray.push(encodedParam.key + "=" + JSON.stringify(encodedParam.value));
            }
          });
        } else if (/[\s'"\\;:/=(),<>@[\]?]|^-/.test(value)) {
          paramsArray.push(param + "=" + JSON.stringify(value));
        } else {
          paramsArray.push(param + "=" + value);
        }
      });
      return structured.value + (paramsArray.length ? "; " + paramsArray.join("; ") : "");
    }
    /**
     * Parses a header value with key=value arguments into a structured
     * object.
     *
     *   parseHeaderValue('content-type: text/plain; CHARSET='UTF-8'') ->
     *   {
     *     'value': 'text/plain',
     *     'params': {
     *       'charset': 'UTF-8'
     *     }
     *   }
     *
     * @param {String} str Header value
     * @return {Object} Header value as a parsed structure
     */
    parseHeaderValue(str) {
      let response = {
        value: false,
        params: {}
      };
      let key = false;
      let value = "";
      let stage = STAGE_VALUE;
      let quote = false;
      let escaped = false;
      let chr;
      for (let i = 0, len = str.length; i < len; i++) {
        chr = str.charAt(i);
        switch (stage) {
          case STAGE_KEY:
            if (chr === "=") {
              key = value.trim().toLowerCase();
              stage = STAGE_VALUE;
              value = "";
              break;
            }
            value += chr;
            break;
          case STAGE_VALUE:
            if (escaped) {
              value += chr;
            } else if (chr === "\\") {
              escaped = true;
              continue;
            } else if (quote && chr === quote) {
              quote = false;
            } else if (!quote && chr === '"') {
              quote = chr;
            } else if (!quote && chr === ";") {
              if (key === false) {
                response.value = value.trim();
              } else {
                response.params[key] = value.trim();
              }
              stage = STAGE_KEY;
              value = "";
            } else {
              value += chr;
            }
            escaped = false;
            break;
        }
      }
      value = value.trim();
      if (stage === STAGE_VALUE) {
        if (key === false) {
          response.value = value;
        } else {
          response.params[key] = value;
        }
      } else if (value) {
        response.params[value.toLowerCase()] = "";
      }
      Object.keys(response.params).forEach((key2) => {
        let actualKey;
        let nr;
        let value2;
        let match = key2.match(/\*((\d+)\*?)?$/);
        if (!match) {
          return;
        }
        actualKey = key2.substr(0, match.index).toLowerCase();
        nr = Number(match[2]) || 0;
        if (!response.params[actualKey] || typeof response.params[actualKey] !== "object") {
          response.params[actualKey] = {
            charset: false,
            values: []
          };
        }
        value2 = response.params[key2];
        if (nr === 0 && match[0].charAt(match[0].length - 1) === "*" && (match = value2.match(/^([^']*)'[^']*'(.*)$/))) {
          response.params[actualKey].charset = match[1] || "utf-8";
          value2 = match[2];
        }
        response.params[actualKey].values.push({ nr, value: value2 });
        delete response.params[key2];
      });
      Object.keys(response.params).forEach((key2) => {
        let value2;
        if (response.params[key2] && Array.isArray(response.params[key2].values)) {
          value2 = response.params[key2].values.sort((a, b) => a.nr - b.nr).map((val) => val && val.value || "").join("");
          if (response.params[key2].charset) {
            response.params[key2] = this.decodeWords(
              "=?" + response.params[key2].charset + "?Q?" + value2.replace(/[=?_\s]/g, (s) => {
                let c = s.charCodeAt(0).toString(16);
                if (s === " ") {
                  return "_";
                } else {
                  return "%" + (c.length < 2 ? "0" : "") + c;
                }
              }).replace(/%/g, "=") + "?="
            );
          } else {
            response.params[key2] = this.decodeWords(value2);
          }
        }
      });
      return response;
    }
    /**
     * Encodes a string or an Buffer to an UTF-8 Parameter Value Continuation encoding (rfc2231)
     * Useful for splitting long parameter values.
     *
     * For example
     *      title="unicode string"
     * becomes
     *     title*0*=utf-8''unicode
     *     title*1*=%20string
     *
     * @param {String|Buffer} data String to be encoded
     * @param {Number} [maxLength=50] Max length for generated chunks
     * @param {String} [fromCharset='UTF-8'] Source sharacter set
     * @return {Array} A list of encoded keys and headers
     */
    buildHeaderParam(key, data, maxLength, fromCharset) {
      let list = [];
      let encodedStr = typeof data === "string" ? data : this.decode(data, fromCharset);
      let encodedStrArr;
      let chr, ord;
      let line;
      let startPos = 0;
      let isEncoded = false;
      let i, len;
      maxLength = maxLength || 50;
      if (this.isPlainText(data)) {
        if (encodedStr.length <= maxLength) {
          return [
            {
              key,
              value: encodedStr
            }
          ];
        }
        encodedStr = encodedStr.replace(new RegExp(".{" + maxLength + "}", "g"), (str) => {
          list.push({
            line: str
          });
          return "";
        });
        if (encodedStr) {
          list.push({
            line: encodedStr
          });
        }
      } else {
        if (/[\uD800-\uDBFF]/.test(encodedStr)) {
          encodedStrArr = [];
          for (i = 0, len = encodedStr.length; i < len; i++) {
            chr = encodedStr.charAt(i);
            ord = chr.charCodeAt(0);
            if (ord >= 55296 && ord <= 56319 && i < len - 1) {
              chr += encodedStr.charAt(i + 1);
              encodedStrArr.push(chr);
              i++;
            } else {
              encodedStrArr.push(chr);
            }
          }
          encodedStr = encodedStrArr;
        }
        line = "utf-8''";
        isEncoded = true;
        startPos = 0;
        for (i = 0, len = encodedStr.length; i < len; i++) {
          chr = encodedStr[i];
          if (isEncoded) {
            chr = this.safeEncodeURIComponent(chr);
          } else {
            chr = chr === " " ? chr : this.safeEncodeURIComponent(chr);
            if (chr !== encodedStr[i]) {
              if ((this.safeEncodeURIComponent(line) + chr).length >= maxLength) {
                list.push({
                  line,
                  encoded: isEncoded
                });
                line = "";
                startPos = i - 1;
              } else {
                isEncoded = true;
                i = startPos;
                line = "";
                continue;
              }
            }
          }
          if ((line + chr).length >= maxLength) {
            list.push({
              line,
              encoded: isEncoded
            });
            line = chr = encodedStr[i] === " " ? " " : this.safeEncodeURIComponent(encodedStr[i]);
            if (chr === encodedStr[i]) {
              isEncoded = false;
              startPos = i - 1;
            } else {
              isEncoded = true;
            }
          } else {
            line += chr;
          }
        }
        if (line) {
          list.push({
            line,
            encoded: isEncoded
          });
        }
      }
      return list.map((item, i2) => ({
        // encoded lines: {name}*{part}*
        // unencoded lines: {name}*{part}
        // if any line needs to be encoded then the first line (part==0) is always encoded
        key: key + "*" + i2 + (item.encoded ? "*" : ""),
        value: item.line
      }));
    }
    /**
     * Returns file extension for a content type string. If no suitable extensions
     * are found, 'bin' is used as the default extension
     *
     * @param {String} mimeType Content type to be checked for
     * @return {String} File extension
     */
    detectExtension(mimeType) {
      mimeType = (mimeType || "").toString().toLowerCase().replace(/\s/g, "");
      if (!(mimeType in mimetypes2.list)) {
        return "bin";
      }
      if (typeof mimetypes2.list[mimeType] === "string") {
        return mimetypes2.list[mimeType];
      }
      let mimeParts = mimeType.split("/");
      for (let i = 0, len = mimetypes2.list[mimeType].length; i < len; i++) {
        if (mimeParts[1] === mimetypes2.list[mimeType][i]) {
          return mimetypes2.list[mimeType][i];
        }
      }
      return mimetypes2.list[mimeType][0] !== "*" ? mimetypes2.list[mimeType][0] : "bin";
    }
    /**
     * Returns content type for a file extension. If no suitable content types
     * are found, 'application/octet-stream' is used as the default content type
     *
     * @param {String} extension Extension to be checked for
     * @return {String} File extension
     */
    detectMimeType(extension) {
      extension = (extension || "").toString().toLowerCase().replace(/\s/g, "").replace(/^\./g, "").split(".").pop();
      if (!(extension in mimetypes2.extensions)) {
        return "application/octet-stream";
      }
      if (typeof mimetypes2.extensions[extension] === "string") {
        return mimetypes2.extensions[extension];
      }
      let mimeParts;
      for (let i = 0, len = mimetypes2.extensions[extension].length; i < len; i++) {
        mimeParts = mimetypes2.extensions[extension][i].split("/");
        if (mimeParts[1] === extension) {
          return mimetypes2.extensions[extension][i];
        }
      }
      return mimetypes2.extensions[extension][0];
    }
    /**
     * Folds long lines, useful for folding header lines (afterSpace=false) and
     * flowed text (afterSpace=true)
     *
     * @param {String} str String to be folded
     * @param {Number} [lineLength=76] Maximum length of a line
     * @param {Boolean} afterSpace If true, leave a space in th end of a line
     * @return {String} String with folded lines
     */
    foldLines(str, lineLength, afterSpace) {
      str = (str || "").toString();
      lineLength = lineLength || 76;
      let pos = 0, len = str.length, result = "", line, match;
      while (pos < len) {
        line = str.substr(pos, lineLength);
        if (line.length < lineLength) {
          result += line;
          break;
        }
        if (match = line.match(/^[^\n\r]*(\r?\n|\r)/)) {
          line = match[0];
          result += line;
          pos += line.length;
          continue;
        } else if ((match = line.match(/(\s+)[^\s]*$/)) && match[0].length - (afterSpace ? (match[1] || "").length : 0) < line.length) {
          line = line.substr(0, line.length - (match[0].length - (afterSpace ? (match[1] || "").length : 0)));
        } else if (match = str.substr(pos + line.length).match(/^[^\s]+(\s*)/)) {
          line = line + match[0].substr(0, match[0].length - (!afterSpace ? (match[1] || "").length : 0));
        }
        result += line;
        pos += line.length;
        if (pos < len) {
          result += "\r\n";
        }
      }
      return result;
    }
    /**
     * Splits a mime encoded string. Needed for dividing mime words into smaller chunks
     *
     * @param {String} str Mime encoded string to be split up
     * @param {Number} maxlen Maximum length of characters for one part (minimum 12)
     * @return {Array} Split string
     */
    splitMimeEncodedString(str, maxlen) {
      let curLine, match, chr, done, lines = [];
      maxlen = Math.max(maxlen || 0, 12);
      while (str.length) {
        curLine = str.substr(0, maxlen);
        if (match = curLine.match(/[=][0-9A-F]?$/i)) {
          curLine = curLine.substr(0, match.index);
        }
        done = false;
        while (!done) {
          done = true;
          if (match = str.substr(curLine.length).match(/^[=]([0-9A-F]{2})/i)) {
            chr = parseInt(match[1], 16);
            if (chr < 194 && chr > 127) {
              curLine = curLine.substr(0, curLine.length - 3);
              done = false;
            }
          }
        }
        if (curLine.length) {
          lines.push(curLine);
        }
        str = str.substr(curLine.length);
      }
      return lines;
    }
    encodeURICharComponent(chr) {
      let res = "";
      let ord = chr.charCodeAt(0).toString(16).toUpperCase();
      if (ord.length % 2) {
        ord = "0" + ord;
      }
      if (ord.length > 2) {
        for (let i = 0, len = ord.length / 2; i < len; i++) {
          res += "%" + ord.substr(i, 2);
        }
      } else {
        res += "%" + ord;
      }
      return res;
    }
    safeEncodeURIComponent(str) {
      str = (str || "").toString();
      try {
        str = encodeURIComponent(str);
      } catch (E) {
        return str.replace(/[^\x00-\x1F *'()<>@,;:\\"[\]?=\u007F-\uFFFF]+/g, "");
      }
      return str.replace(/[\x00-\x1F *'()<>@,;:\\"[\]?=\u007F-\uFFFF]/g, (chr) => this.encodeURICharComponent(chr));
    }
  }
  libmime.exports = new Libmime();
  libmime.exports.Libmime = Libmime;
  return libmime.exports;
}
export {
  requireLibmime as r
};
