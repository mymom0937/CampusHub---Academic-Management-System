const n=()=>null;export{n as component};
