import{c as r,d as a,Z as o,e as t}from"./schemas-BcIHWAcj.js";function c(e){return a(o,e)}function d(e){return r(t,e)}export{d,c as n};
