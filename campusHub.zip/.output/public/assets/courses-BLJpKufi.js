import{j as t,O as o}from"./main-DioSj27d.js";const n=()=>t.jsx(o,{});export{n as component};
